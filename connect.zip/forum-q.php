<?php
error_reporting(0);

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
 // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e){
    exit($e->getMessage());
}
$username = $_POST['username'];


$question = $_POST['question'];



$ip = $_SERVER['REMOTE_ADDR'];


//Verifcation 
if (empty($username) || empty($question)){
    $error = "Complete all fields";
}


 //Securly insert into database
    $sql = "insert into forum_question (username, question)
  VALUES ('$username', '$question')";
   $query = $conn->prepare($sql);

    $query->execute(array(

    ':username' => $username,
    ':question' => $question,
    
    
    ':ip' => $ip

    ));
header("Location:/forum.php");


?>