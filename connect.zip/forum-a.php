<?php
error_reporting(0);

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $ausername, $answer);
 // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e){
    exit($e->getMessage());
}
$ausername = $_POST['ausername'];


$answer = $_POST['answer'];



$ip = $_SERVER['REMOTE_ADDR'];


//Verifcation 
if (empty($ausername) || empty($answer)){
    $error = "Complete all fields";
}


 //Securly insert into database
    $sql = "insert into forum_answer (ausername, answer)
  VALUES ('$ausername', '$answer')";
   $query = $conn->prepare($sql);

    $query->execute(array(

    ':ausername' => $ausername,
    ':answer' => $answer,
    
    
    ':ip' => $ip

    ));
header("Location:/forum.php");


?>