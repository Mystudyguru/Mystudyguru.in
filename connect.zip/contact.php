<?php
error_reporting(0);

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
 // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e){
    exit($e->getMessage());
}
$name = $_POST['name'];
$email = $_POST['email'];

$message = $_POST['message'];



$ip = $_SERVER['REMOTE_ADDR'];


//Verifcation 
if (empty($name) || empty($email) || empty($message)){
    $error = "Complete all fields";
}


 //Securly insert into database
    $sql = "insert into contactus (name, email, message)
  VALUES ('$name', '$email', '$message ')";
   $query = $conn->prepare($sql);

    $query->execute(array(

    ':name' => $name,
    ':email' => $email,
    ':message' => $message,
    
    ':ip' => $ip

    ));
header("Location:/contact.php");


?>