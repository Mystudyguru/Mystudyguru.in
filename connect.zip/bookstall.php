<?php
error_reporting(0);

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
 // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e){
    exit($e->getMessage());
}
$bname = $_POST['bname'];
$sname = $_POST['sname'];
$sphone = $_POST['sphone'];
$sadd = $_POST['sadd'];
$bprice = $_POST['bprice'];

/*
$bpic = $_FILES["bpic"]["name"];
$tempname1 = $_FILES["bpic"]["tmp_name"];
$bpic = "bpic/".$bpic;
move_uploaded_file($tempname1,$bpic);
*/

$bpic = $_FILES["bpic"]["name"];
$tempname = $_FILES["bpic"]["tmp_name"];
$bpic = "bpic/".$bpic;
move_uploaded_file($tempname,$bpic);





$ip = $_SERVER['REMOTE_ADDR'];


//Verifcation 
if (empty($bname) || empty($sname) || empty($sphone) || empty($sadd) || empty($bprice) || empty($bpic)){
    $error = "Complete all fields";
}


 //Securly insert into database
    $sql = "insert into bookstall (bname, sname, sphone, sadd, bprice, bpic)
  VALUES ('$bname', '$sname', '$sphone', '$sadd', '$bprice', '$bpic')";
   $query = $conn->prepare($sql);

    $query->execute(array(

    ':bname' => $bname,
    ':sname' => $sname,
    ':sphone' => $sphone,
    ':sadd' => $sadd,
    ':bprice' => $bprice,
    ':bpic' => $bpic,
    
    ':ip' => $ip

    ));
header("Location:\msg2/book.php");


?>