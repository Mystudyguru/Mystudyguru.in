<?php
error_reporting(0);

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
 // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e){
    exit($e->getMessage());
}

$email = $_POST['email'];

$complement = $_POST['complement'];



$ip = $_SERVER['REMOTE_ADDR'];


//Verifcation 
if (empty($email) || empty($complement)){
    $error = "Complete all fields";
}


 //Securly insert into database
    $sql = "insert into comment_detail (email, complement)
  VALUES ('$email', '$complement ')";
   $query = $conn->prepare($sql);

    $query->execute(array(

    
    ':email' => $email,
    ':complement' => $complement,
    
    ':ip' => $ip

    ));
header("Location:..\blog.php");


?>