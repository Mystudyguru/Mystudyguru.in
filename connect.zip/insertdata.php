<!--?php
$uname = $_POST['uname'];
$uemail = $_POST['uemail'];

$upass = $_POST['upass'];


$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "insert into user_registration (uname, uemail,upass)
  VALUES ('$uname', '$uemail', '$upass ')";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
  header("location:home.php");
  session_destory();
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?-->

<?php
error_reporting(0);

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
 // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $e){
    exit($e->getMessage());
}
$uname = $_POST['uname'];
$uemail = $_POST['uemail'];

$upass = $_POST['upass'];



$ip = $_SERVER['REMOTE_ADDR'];


//Verifcation 
if (empty($uname) || empty($uemail) || empty($upass)){
    $error = "Complete all fields";
}

// Password match
if ($upass != $upass){
    $error = "Passwords don't match";
}

// Email validation

if (!filter_var($uemail, FILTER_VALIDATE_EMAIL)){
    $error = "Enter a  valid email";
}


if(!isset($error)){
//no error
$stconn = $conn->prepare("SELECT uname FROM user_registration WHERE uname = :uname");
$stconn->bindParam(':uname', $uname);
$stconn->execute();

if($stconn->rowCount() > 0){
	error_reporting(0);
	//$message = '<label>Username exist</label>';
	//echo '<script>alert("$message");</script>';
	//echo '<label class="text-danger">'.$message.'</label>';

    echo "Username exists! Please use another Username";
	echo '<br><a href="\msg2\home.php"><button>Signup Again</button></a>';
	//header("location:\msg2\home.php");
} else {
    //Securly insert into database
    $sql = "insert into user_registration (uname, uemail, upass)
  VALUES ('$uname', '$uemail', '$upass ')";
   $query = $conn->prepare($sql);

    $query->execute(array(

    ':uname' => $uname,
    ':uemail' => $uemail,
    ':upass' => $upass,
    
    ':ip' => $ip

    ));
    }
	//header("Location:msg2/home.php");
}else{
    echo "error occured: ".$error;
    exit();
}
?>




