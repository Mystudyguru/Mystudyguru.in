<?php


$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $pdodbcon = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);

  $pdodbcon->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);
 
} catch(PDOException $error) {
  $error->getMessage();
  echo '<h1>Database Failed To Connect</h1>';
}

/* $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);*/
 
  // set the PDO error mode to exception
?>