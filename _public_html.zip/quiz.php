<?php
include 'Head_Foot/header.html'; 
?>
 <!doctype html>
 <html>
     <head>
    <title> Quiz </title>
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
   <style>

         *{
      margin:0;
      padding:0;
      }
      .alia{
      background-color:white;
      font-family:'Georgia',serif;
      }
      .flip-card {
  background-color: transparent;
  width: 300px;
  height: 400px;
  perspective: 1000px; /* Remove this if you don't want the 3D effect */


}

/* This container is needed to position the front and back side */
.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;

  transition: transform 0.8s;
  transform-style: preserve-3d;
}

/* Do an horizontal flip when you move the mouse over the flip box container */
.flip-card:hover .flip-card-inner {
  transform: rotateX(180deg);
}

/* Position the front and back side */
.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;

  -webkit-backface-visibility: hidden; /* Safari */
  backface-visibility: hidden;
}

/* Style the front side (fallback if image is missing) */
.flip-card-front {
  background-color: #bbb;
  color: black;
    border: 15px outset #8b62c7;
  border-radius: 20px;

}

/* Style the back side */
.flip-card-back {
 height:400px;
  background-color: white;
  color: black;
  border: 15px inset red;
  border-radius: 20px;
  transform: rotateX(180deg);
}
     
.btn{

        border: 3px solid  #8b62c7;;
        border-radius:24px;
        }
        .btn:hover{
        width:200px;
        background:white;
        border-color:tomato;
        }
           .btn:focus{
        background:#8b62c7;
        border-color:white;
        }	
btn1{
background-color:#8b62c7;
}
		</style>

</head>

<body class="alia">
    <section>
      
          <h1 class="display-3 text-center text-capitalize text-white" style="background-color:#8b62c7;">Quiz!</h1>
       <hr class="w-25 mx-auto bg-danger"></hr>
    <div class="container-fluid pb-3">
       <div class="row text-center pt-4 " >
           <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <h1 class="display-4 text-center" style="font-family: Georgia, serif;">
            <strong>Quiz 1</strong></h1>
<center><img src="images/G.k-Quiz.png" alt="bulb" class="img-fluid"></center>   
	</div>
    <div class="flip-card-back">
      <h1>G.K.<hr></h1>
      <p>No. of Question: 10</p>
	  <p>Each question is of 2 Marks.</p>
      <a href="quiz/quiz1.html"><button class="btn btn1 btn-lg mt-4 mb-2 pl-5 pr-5 pt-1 pb-1">Click</button></a>
    </div>
  </div>
</div>  </div>


<div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <h1 class="display-4 text-center" style="font-family: Georgia, serif;">
            <strong>Quiz 2</strong></h1>
<center><img src="images/G.k-Quiz.png" alt="bulb" class="img-fluid"></center>   
	</div>
    <div class="flip-card-back">
      <h1>G.K.<hr></h1>
      <p>No. of Question: 25</p>
	  <p>Each question is of 2 Marks.</p>
      <a href="quiz/quiz2.html"><button class="btn btn1 btn-lg mt-4 mb-2 pl-5 pr-5 pt-1 pb-1">Click</button></a>
    </div>
  </div>
</div>  </div>




<div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <h1 class="display-4 text-center" style="font-family: Georgia, serif;">
            <strong>Quiz 3</strong></h1>
<center><img src="images/G.k-Quiz.png" alt="bulb" class="img-fluid"></center>   
	</div>
    <div class="flip-card-back">
      <h1>G.K.<hr></h1>
      <p>No. of Question: 25</p>
	  <p>Each question is of 2 Marks.</p>
      <a href="quiz/quiz3.html"><button class="btn btn1 btn-lg mt-4 mb-2 pl-5 pr-5 pt-1 pb-1">Click</button></a>
    </div>
  </div>
</div>  </div>
<div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <h1 class="display-4 text-center" style="font-family: Georgia, serif;">
            <strong>Quiz 4</strong></h1>
<center><img src="images/G.k-Quiz.png" alt="bulb" class="img-fluid"></center>   
	</div>
    <div class="flip-card-back">
      <h1>G.K.<hr></h1>
      <p>No. of Question: 10</p>
	  <p>Each question is of 2 Marks.</p>
      <a href="quiz/quiz4.html"><button class="btn btn1 btn-lg mt-4 mb-2 pl-5 pr-5 pt-1 pb-1">Click</button></a>
    </div>
  </div>
</div>  </div>

               <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <h1 class="display-4 text-center" style="font-family: Georgia, serif;">
            <strong>Quiz 5</strong></h1>
<center><img src="images/G.k-Quiz.png" alt="bulb" class="img-fluid"></center>   
	</div>
    <div class="flip-card-back">
      <h1>G.K.<hr></h1>
      <p>No. of Question: 10</p>
	  <p>Each question is of 2 Marks.</p>
      <a href="quiz/quiz5.html"><button class="btn btn1 btn-lg mt-4 mb-2 pl-5 pr-5 pt-1 pb-1">Click</button></a>
    </div>
  </div>
</div>  </div>

<div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <h1 class="display-4 text-center" style="font-family: Georgia, serif;">
            <strong>Quiz 6</strong></h1>
<center><img src="images/G.k-Quiz.png" alt="bulb" class="img-fluid"></center>   
	</div>
    <div class="flip-card-back">
      <h1>G.K.<hr></h1>
      <p>No. of Question: 10</p>
	  <p>Each question is of 2 Marks.</p>
      <a href="quiz/quiz6.html"><button class="btn btn1 btn-lg mt-4 mb-2 pl-5 pr-5 pt-1 pb-1">Click</button></a>
    </div>
  </div>
</div>  </div>

               </div>

               </div>  
			   
			   </div>

               </div>

               </div>
		  
               </div>
               </div>
               </div>
               </div>
</section>





          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</body>

</html>
<?php
include 'Head_Foot/footer.html'; 
?>