<?php
include 'Head_Foot/header.html'; 
?>
<!DOCTYPE>
<html>
<head>
<style>
.ac{
background-color:#8b62c7;

}
a{ font-family:georgia;
 
}
a:hover{ 
       font-size:21px;
	   text-decoration:
}
.as{
    background-color:#D0D3D4;
	height:500px;
}
li{font-size:20px;
  text-shadow:1px 1px 1px black;
}
</style>
 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="robots" content="index,follow"/>
<meta name="keywords" content="upsc mains syllabus,upsc previous papers,upsc motivations,upsc notification 2020">
<meta name="description" content="Totally free amazing study material for upsc preparation">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


<title>UPSC Preparation free with mystudyguru</title>
</head>
<body style="background-color:#F8EBFF;">


<div class="container-fluid border border-info  ac">
<div class="row color-section pt-2 m-0">
        <div class="col text-white ">
<h1 class="display-5"  align="center"; style="font-family:georgia, serif; color:white; "> <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-book" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.214 1.072C4.813.752 6.916.71 8.354 2.146A.5.5 0 0 1 8.5 2.5v11a.5.5 0 0 1-.854.354c-.843-.844-2.115-1.059-3.47-.92-1.344.14-2.66.617-3.452 1.013A.5.5 0 0 1 0 13.5v-11a.5.5 0 0 1 .276-.447L.5 2.5l-.224-.447.002-.001.004-.002.013-.006a5.017 5.017 0 0 1 .22-.103 12.958 12.958 0 0 1 2.7-.869zM1 2.82v9.908c.846-.343 1.944-.672 3.074-.788 1.143-.118 2.387-.023 3.426.56V2.718c-1.063-.929-2.631-.956-4.09-.664A11.958 11.958 0 0 0 1 2.82z"/>
  <path fill-rule="evenodd" d="M12.786 1.072C11.188.752 9.084.71 7.646 2.146A.5.5 0 0 0 7.5 2.5v11a.5.5 0 0 0 .854.354c.843-.844 2.115-1.059 3.47-.92 1.344.14 2.66.617 3.452 1.013A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.276-.447L15.5 2.5l.224-.447-.002-.001-.004-.002-.013-.006-.047-.023a12.582 12.582 0 0 0-.799-.34 12.96 12.96 0 0 0-2.073-.609zM15 2.82v9.908c-.846-.343-1.944-.672-3.074-.788-1.143-.118-2.387-.023-3.426.56V2.718c1.063-.929 2.631-.956 4.09-.664A11.956 11.956 0 0 1 15 2.82z"/>
</svg><br/>All UPSC Study Material  </</h2></br>
</div>
</div>
</div>
<div class="container as overflow-auto ">
<br>
<ul>


<!--UPSC FOLDER CONTENT-->
<li> UPSC-ancient-history-IAS <a href="pdfs/upsc/UPSC-ancient-history-IAS.pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-Medival-History <a href="pdfs/upsc/UPSC-IAS-Medival-History.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-Mideval-History(part-1 of 2) <a href="pdfs/upsc/UPSC-IAS-Mideval-history(part 1of2).pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-Mideval-History(part-2 of 2) <a href="pdfs/upsc/UPSC-IAS-Mideval-History(part-2 of 2).pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-Modern-History(part 1 0f 2) <a href="pdfs/upsc/UPSC-IAS-Modern-History(part 1 0f 2).pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-Modern-History(part 2 0f 2) <a href="pdfs/upsc/UPSC-IAS-Modern-History(part 1 0f 2).pdf" target="_blank">Click here</a></li><br/>
<li>  UPSC-IAS-Indian_geography(notes) <a href="pdfs/upsc/UPSC-IAS-Indian_geography(notes).pdf" target="_blank">Click here</a></li><br/>
<li>  UPSC-geography-imp-question <a href="pdfs/upsc/UPSC-geography-imp-question.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-Geography (2)-imp-question <a href="pdfs/upsc/UPSC-Geography (2)-imp-question.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-Indian-Economics <a href="pdfs/upsc/UPSC-IAS-Indian-Economics.pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-ipc-Law <a href="pdfs/upsc/UPSC-IAS-ipc-Law.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-constitution <a href="pdfs/upsc/ UPSC-IAS-constitution.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-oneliner <a href="pdfs/upsc/UPSC-IAS-oneliner.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-Multinational-projects-in-India(notes) <a href="pdfs/upsc/UPSC-IAS-Multinational-projects-in-India(notes).pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-gk-bio-IAS <a href="pdfs/upsc/UPSC-gk-bio-IAS.pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-Politics-India <a href="pdfs/upsc/UPSC-IAS-Politics-India.pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-Indian-Polity <a href="pdfs/upsc/UPSC-IAS-Indian-Polity.pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-psycho <a href="pdfs/upsc/UPSC-IAS-psycho.pdf" target="_blank">Click here</a></li><br/>
<li>  499+GS-UPSC-IAS <a href="pdfs/upsc/ 499+GS-UPSC-IAS.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-8999+GS-IAS<a href="pdfs/upsc/UPSC-8999+GS-IAS.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-Important-Dates-IAS <a href="pdfs/upsc/UPSC-Important-Dates-IAS.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-gktrick <a href="pdfs/upsc/UPSC-IAS-gktrick.pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-crpc(hindi) <a href="pdfs/upsc/UPSC-IAS-crpc(hindi).pdf" target="_blank">Click here</a></li><br/>
<li> UPSC-IAS-imp-question <a href="pdfs/upsc/UPSC-IAS-imp-question.pdf" target="_blank">Click here</a></li><br/>
<li>UPSC-IAS-imp-question(2) <a href="pdfs/upsc/UPSC-IAS-imp-question(2).pdf" target="_blank">Click here</a></li><br/>
 

<!--END OF UPSC FOLDER CONTENT-->
</ul></div>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
</body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>