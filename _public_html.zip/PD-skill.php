<?php
include 'Head_Foot/header.html';

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="robots" content="index,follow"/>
        <meta name="keywords" content="Personality Development topics,Personality development skills traning,IAS Personality,personality development articles ">
        <meta name="description" content="Strategies for developing and retaining excellent Persoanlity">


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Need for Persoanlity Development?</title>
    <script>
         var data = document.getElementById('text') ;
        function submit(){
           
            console.log(data);
        }

    </script>
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 40vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: Arial, Helvetica, sans-serif;
    font-size:22px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }
      hr{
          height: 15px;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
       .height-60{
           min-height: 60vh;
       }
       .text-success-1{
           color:#6930c3;
       }
       
       
       .height-60{
           min-height:80vh;
      
       }
       
       .height-40{
           min-height: 50vh;
           
       }
       
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
      

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            
            <!-- ../images/blog/ -->
            <div class="row">
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8"> <h1 class="text-success-1 mt-4 ml-4 text-uppercase text-left" 
                    style="font-weight:800;">Personality Development!
                </h1>
                    <p class="text-success mr-5 mt-5 ml-2  display mr-4 text-left" style="font-weight:700;">
                        How to attract people/<br>
                        Be an inspiring personality.
                </p></div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-primary m-4"><h4><a href="..." class="text-primary">by Achal Gupta</a>-  20/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3 text-uppercase">PERSONALITY DEVELOPMENT</h1>
                   <p class="paragraph">  <b> Definition:  </b> Personality development is the sum of qualities, 
                    behavior, characteristics, understanding, attitude, beliefs and psychological traits that works
                      together to make you distinctive.<br>Thus, personality development involves, working all over round in all aspects of life. Personality development covers all the activities that improves awareness, develop skills, talent, potential, human capabilities which all around aims at enhancing the quality of life.
                   </p>
                    
                    
                    
            
                    
                       <p class="paragraph">  Personality development takes place over the course of life,
                            a human personality, start developing from the day he is born and continues till death.
                             A lot of factors such as heredity, environment, family,
                              friends and social conditions are involved in evolving one's personality.<br>Therefore, one would pay much attention on all these area to develop well-rounded personality.

                        <br></p>
                       
                    
                    
                            <div class="container my-5"  id="">
                                <img src="8.jpg" class="img-fluid">
                                <img src="../images/blog/PERSONALITY-DEVELOPMENT-DEFINATION.jpg" alt="PERSONALITY DEVELOPMENT DEFINATION" class="img-fluid">
                                
                                <div class="row height-">
                                    <div class="col"> 
        
        
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mt-5 diplay-4">WHY TO DEVELOP PERSONALITY ?</h2>
                    <p class="paragraph"> 
                       
                             
                            <p class="paragraph mt-4"> A important question that arise is "why to develop personality", 
                                I hope next few listed point might help you understanding the need to develop a good healthy personality.
                        </p> <ul class="paragraph">
                        <li><b>Increase Self Awareness</b> - Personality development aims at finding one's weakness, 
                            and qualities which help a person, to look-in clearly, so as one can work over weakness, and enhance qualities.<br> 
                            It also enables you to choose what YOU need from life and how to accomplish them.</li><br>
                            <li><b>Increases Self Confidence</b>Personality development works on developing confidence, 
                                you must have encounter a person who speak so confidently over stage and at the same time when you look 
                                towards yourself, you cannot even utter your name clearly, 
                                Personalty development works all around developing stage confidence and stage manners.</li><br>
                            <li><b>Enhances your personality</b>-Who doesn't love to be Mr./Ms. Greta Thunberg? 
                                Yes, by personality development courses, one can enhance one's personality. 
                                <br>A personality development course will assist you, to improve your character, 
                                and make it more attractive.  
                            </li> <br>
                            <li><b>Improves Communication Skills</b>- This is probably the most demanding skill in 21 century, 
                                if one have to rule the world, our communication skills should be juggernaut.</li><br>
                            <li><b>To deal with Anxiety and Stress</b>- When you put effort in something, and if effort doesn't yield result, that may cause stress and anxiety,
                                 for which personality development works all around, on developing stress management skills.</li><br>
                            <li><b>To gain true Happiness.</b></li><br>
                            <li><b>To take a step towards goals.</b></li>

                    </ul> </p>
                    <hr>
                    <p class="paragraph  ">If, you watch the movie, "The Shawshank redemption" then you can realize the need of personality.
                         The lead character "Andy Duframe" shows how having good personality affects your life.
                    </p> 
                    <div class="container"  id="filler">
                        <div class="row height">
                            <div class="col"> 
                                <img src="9.jpg" class="img-fluid">
                                <img src="../images/blog/PERSONALITY-DEVELOPMENT-IN-CHILDHOOD.jpg" alt="PERSONALITY DEVELOPMENT IN CHILDHOOD" class="img-fluid">

                            </div>
                        </div>
                    </div> 
                   <hr class="mt-5"> 
                    
                      <h1 class="display-5 mt-5"> HOW TO DEVELOP PERSONALITY? </h1>
                      <p class="paragraph">    well, there are a lot of personality development courses, out in market which you can join, 
                          to enhance your personality, and can learn a more than this blog post but let me take you through a overview.<br>
                          Key points in Personality Development are:- </p>
                          <ul class="paragraph">
                              <li>Personality doesn't have to deal with looks.</li>
                              <li>Dress up well.</li>
                              <li>Be confident.</li>
                              <li>Be optimistic.</li>
                              <li>Learn Social Skills.</li>
                              <li>Do not copy anyone.</li>
                              <li>Get out of comfort zone.</li>
                              <li>Don't fear Failure.</li>
                              <li>Don't give up.</li>
                              <li>Be consistent.</li>
                              <li>Be funny and don't be always serious.</li>
                 


                          </ul>
                          <div class="container"  id="filler3">
                            <div class="row height-">
                                <div class="col"> 
                                    <img src="10.jpg" class="img-fluid">
                                    <img src="../images/blog/Personality-development-tips.jpg" alt="Personality development tips"class="img-fluid">
    
                                </div>
                            </div>
                        </div>
                      
                           </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col">  
                    <p class="paragraph">

                       
                        
                        
                        
    
                                 
                        
                         
                          
                        <h2 class="  display-5 my-4">    </h2>
                        
                         
                        
                        
                        
                        </p>
                        <h1 class="display-5">Quote:</h1> 
                        <p class="paragraph"> 
                        </p>
                        <p class="paragraph">”You try, you fail,<br>
                             You try, you fail,<br>
                            The real failure is when you stop trying!”<br>  
                            -quote by: team@mystudyguru.in
                            </p>


                     <br>
                          
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>
<?php
include 'bl/commententry.php';
?>


   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 









<?php
include 'bl/section.html';

?>
        
        
<?php
include 'bl/commentshow.php';

?>                 
         
    
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
      </body>
    </html>
<?php
include 'Head_Foot/footer.html';

?>    
    