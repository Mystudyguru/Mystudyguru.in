<?php
include 'Head_Foot/header.html'; 
?>
<!DOCTYPE>
<html>
<head>
<style>
.ac{
background-color:#8b62c7;

}
a{ font-family:georgia;
 
}
a:hover{ 
       font-size:21px;
	   text-decoration:
}
.as{
    background-color:#D0D3D4;
	height:500px;
}
li{font-size:20px;
  text-shadow:1px 1px 1px black;
}
</style>
 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="robots" content="index,follow"/>
<meta name="keywords" content="up tet exam,super tet exam,c tet exam,tgt pgt exam">
<meta name="description" content="all teaching jobs preparation free best study material ">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


<title>Up-TET|C-TET|Super-TET|mystudyguru</title>
</head>
<body style="background-color:#F8EBFF;">


<div class="container-fluid border border-info  ac">
<div class="row color-section pt-2 m-0">
        <div class="col text-white ">
<h1 class="display-5"  align="center"; style="font-family:georgia, serif; color:white; "> <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-book" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.214 1.072C4.813.752 6.916.71 8.354 2.146A.5.5 0 0 1 8.5 2.5v11a.5.5 0 0 1-.854.354c-.843-.844-2.115-1.059-3.47-.92-1.344.14-2.66.617-3.452 1.013A.5.5 0 0 1 0 13.5v-11a.5.5 0 0 1 .276-.447L.5 2.5l-.224-.447.002-.001.004-.002.013-.006a5.017 5.017 0 0 1 .22-.103 12.958 12.958 0 0 1 2.7-.869zM1 2.82v9.908c.846-.343 1.944-.672 3.074-.788 1.143-.118 2.387-.023 3.426.56V2.718c-1.063-.929-2.631-.956-4.09-.664A11.958 11.958 0 0 0 1 2.82z"/>
  <path fill-rule="evenodd" d="M12.786 1.072C11.188.752 9.084.71 7.646 2.146A.5.5 0 0 0 7.5 2.5v11a.5.5 0 0 0 .854.354c.843-.844 2.115-1.059 3.47-.92 1.344.14 2.66.617 3.452 1.013A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.276-.447L15.5 2.5l.224-.447-.002-.001-.004-.002-.013-.006-.047-.023a12.582 12.582 0 0 0-.799-.34 12.96 12.96 0 0 0-2.073-.609zM15 2.82v9.908c-.846-.343-1.944-.672-3.074-.788-1.143-.118-2.387-.023-3.426.56V2.718c1.063-.929 2.631-.956 4.09-.664A11.956 11.956 0 0 1 15 2.82z"/>
</svg><br/>All UP-Tet,C-Tet & S-Tet Study Material </h2></br>
</div>
</div>
</div>
<div class="container as overflow-auto ">
<br>
<ul>
<li>Hindi-1 <a href="pdfs/uptet/Download-pdf-Uptet-hindi 1.pdf" target="_blank" >Click here</a></li><br/>
<li>Hindi-2 <a href="pdfs/uptet/Download-pdf-Uptet-hindi-2.pdf" target="_blank" >Click here</a></li><br/>
<li>Sankrit-1 <a href="pdfs/uptet/Sanskrit-all-teaching-courses-1.pdf" target="_blank"> Click here</a></li><br/>
<li>Sanskrit-2 <a href="pdfs/uptet/Sanskrit-all-teaching-courses-2.pdf" target="_blank" >Click here</a></li><br/>
<li>Sanskrit-3<a href="pdfs/uptet/Sanskrit-all-teaching-courses-3.pdf" target="_blank" >Click here</a></li><br/>
<li>Download-E.V.S-1 <a href="pdfs/uptet/Download-E.V.S-1.pdf" target="_blank">Click here</a></li><br/>
<li>Download-E.V.S-2 <a href="pdfs/uptet/download-evs-2.pdf" target="_blank">Click here</a></li><br/>
<li>Environment-Hand-Written-Notes <a href="pdfs/uptet/Environment-Hand-Written-Notes ctetstudymaterial.in.pdf" target="_blank" >Click here</a></li><br/>
<li>Mathematic_Pedagogy_Part_2_Study_Material (1) <a href="pdfs/uptet/Mathematic_Pedagogy_Part_2_Study_Material (1).pdf" target="_blank" >Click here</a></li><br/>
<li>uptet-ctet-stet-mcq-1 <a href="pdfs/uptet/uptet-ctet-stet-mcq-1.pdf" target="_blank">Click here</a></li><br/>
<li>uptet-ctet-stet-mcq-2 <a href="pdfs/uptet/uptet-ctet-stet-mcq-2.pdf" target="_blank">Click here</a></li><br/>
<li>Alphabet_test.pdf <a href="pdfs/uptet/Alphabet_test.pdff" target="_blank">Click here</a></li><br/>
<li>Cups and Trophies <a href="pdfs/uptet/ssc1.pdf" target="_blank">Click here</a></li><br/>
<li>MCQs General Science <a href="pdfs/uptet/rrbgk.pdf" target="_blank" >Click here</a><l/i><br/>
<li>G.S Important Dates <a href="pdfs/uptet/important dates.pdf" target="_blank" >Click here </a></li><br/>
<li>G.S One Liner <a href="pdfs/uptet/oneliner.pdf" target="_blank" >Click here</a></li><br/>
<li>100+ Important Questions <a href="pdfs/uptet/rrb100.pdf" target="_blank" >Click here</a></li><br/>
<li>G.S 500+ Important Question <a href="pdfs/uptet/gs500.pdf" target="_blank" >Click here </a></li><br/>
<li>G.S 1000+ Important Questions <a href="pdfs/uptet/ssc1000.pdf" target="_blank" >Click here</a></li><br/>
<li>G.S 9000+ Important Questions <a href="pdfs/upsc/9000gs.pdf" target="_blank">Click here</a></li><br/>

  <ul>
                    <h1 class="display-5 p-2">Full-MATHS-Concept</h1>
                    <li>Maths <a href="pdfs/rrb/profit-loss.pdf" target="_blank">Click here</a></li><br/>
                    
                    <li>1. NUMBERS  <a href="pdfs/maths/1. NUMBERS.pdf" target="_blank">Click here</a></li><br/>
                    <li>2. H.C.F. AND L.C.M. OF NUMBERS <a href="pdfs/maths/2. H.C.F. AND L.C.M. OF NUMBERS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 3. DECIMAL FRACTIONS <a href="pdfs/maths/3. DECIMAL FRACTIONS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 4. SIMPLIFICATION <a href="pdfs/maths/4. SIMPLIFICATION.pdf" target="_blank">Click here</a></li><br/>
                    <li> 5.SQUARE ROOTS AND CUBE ROOTS <a href="pdfs/maths/ 5.SQUARE ROOTS AND CUBE ROOTS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 6.AVERAGE <a href="pdfs/maths/ 6.AVERAGE.pdf" target="_blank">Click here</a></li><br/>
                    <li> 7 Problems on numbers <a href="pdfs/maths/7 Problems on numbers.pdf" target="_blank">Click here</a></li><br/>
                    <li> 8 Problems on ages <a href="pdfs/maths/8 Problems on ages.pdf" target="_blank">Click here</a></li><br/>
                    <li> 9 surds and indices .<a href="pdfs/maths/9 surds and indices.pdf" target="_blank">Click here</a></li><br/>
                    <li> 10 percentage<a href="pdfs/maths/10 percentage.pdf" target="_blank">Click here</a></li><br/>
                    <li> 11 profit and loss. <a href="pdfs/maths/11 profit and loss..pdf" target="_blank">Click here</a></li><br/>
                    <li> 12. RATIO AND PROPORTION <a href="pdfs/maths/12. RATIO AND PROPORTION.pdf" target="_blank">Click here</a></li><br/>
                    <li> 13. PARTNERSHIP <a href="pdfs/maths/13. PARTNERSHIP.pdf" target="_blank">Click here</a></li><br/>
                    <li> 14. CHAIN RULE <a href="pdfs/maths/14. CHAIN RULE.pdf" target="_blank">Click here</a></li><br/>
                    <li> 15. TIME AND WORK <a href="pdfs/maths/15. TIME AND WORK.pdf" target="_blank">Click here</a></li><br/>
                    <li> 16. PIPES AND CISTERNS <a href="pdfs/maths/16. PIPES AND CISTERNS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 17. TIME AND DISTANCE <a href="pdfs/maths/17. TIME AND DISTANCE.pdf" target="_blank">Click here</a></li><br/>
                    <li> 19.BOATS AND STREAMS <a href="pdfs/maths/19.BOATS AND STREAMS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 20. ALLIGATION OR MIXTURE <a href="pdfs/maths/20. ALLIGATION OR MIXTURE.pdf" target="_blank">Click here</a></li><br/>
                    <li>21. SIMPLE INTEREST <a href="pdfs/maths/21. SIMPLE INTEREST.pdf" target="_blank">Click here</a></li><br/>
                    <li> 22.COMPOUND INTEREST <a href="pdfs/maths/22.COMPOUND INTEREST.pdf" target="_blank">Click here</a></li><br/>
                    <li> 23. LOGARITHMS <a href="pdfs/maths/23. LOGARITHMS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 24 .AREA <a href="pdfs/maths/24 .AREA.pdf" target="_blank">Click here</a></li><br/>
                    <li> 25.VOLUME AND SURFACE AREA <a href="pdfs/maths/ 25.VOLUME AND SURFACE AREA.pdf" target="_blank">Click here</a></li><br/>
                    <li> 26. RACES AND GAMES .<a href="pdfs/maths/math1.pdf" target="_blank">Click here</a></li><br/>
                    <li> 27. CALENDAR <a href="pdfs/maths/27. CALENDAR.pdf" target="_blank">Click here</a></li><br/>
                    <li> 28. CLOCKS <a href="pdfs/maths/28. CLOCKS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 29. STOCKS AND SHARES <a href="pdfs/maths/29. STOCKS AND SHARES.pdf" target="_blank">Click here</a></li><br/>
                    <li> 30. PERMUTATIONS AND COMBINATIONS <a href="pdfs/maths/30. PERMUTATIONS AND COMBINATIONS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 31. PROBABILITY <a href="pdfs/maths/31. PROBABILITY.pdf" target="_blank">Click here</a></li><br/>
                    <li> 32. TRUE DISCOUNT <a href="pdfs/maths/32. TRUE DISCOUNT.pdf" target="_blank">Click here</a></li><br/>
                    <li> 33. BANKER'S DISCOUNT <a href="pdfs/maths/33. BANKER'S DISCOUNT.pdf" target="_blank">Click here</a></li><br/>
                    <li> 34. HEIGHTS AND DISTANCES <a href="pdfs/maths/34. HEIGHTS AND DISTANCES.pdf" target="_blank">Click here</a></li><br/>
                    <li> 35. TABULATION <a href="pdfs/maths/35. TABULATION.pdf" target="_blank">Click here</a></li><br/>
                    <li> 36.BAR GRAPHS <a href="pdfs/maths/36.BAR GRAPHS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 37. PIE-CHARTS <a href="pdfs/maths/37. PIE-CHARTS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 38.LINE-GRAPHS <a href="pdfs/maths/38.LINE-GRAPHS.pdf" target="_blank">Click here</a></li><br/>
                    <li> Algebra <a href="pdfs/maths/Algebra.pdf" target="_blank">Click here</a></li><br/>
                    <li> Geometry <a href="pdfs/maths/Geometry.pdf" target="_blank">Click here</a></li><br/>
                    <li> IA-07trigonometric-functions37-40 <a href="pdfs/maths/IA-07trigonometric-functions37-40.pdf" target="_blank">Click here</a></li><br/>
                    <li> IA-15propeties-of-triangles69-78 <a href="pdfs/maths/IA-15propeties-of-triangles69-78.pdf" target="_blank">Click here</a></li><br/>
                    <li> IA-16heights_distances79-85 <a href="pdfs/maths/IA-16heights_distances79-85.pdf" target="_blank">Click here</a></li><br/>
                    <li> Mensuration <a href="pdfs/maths/Mensuratiom.pdf" target="_blank">Click here</a></li><br/>
                    <li> Number System. <a href="pdfs/maths/Number System..pdf" target="_blank">Click here</a></li><br/>
                    <li> Percentage <a href="pdfs/maths/Percentage.pdf" target="_blank">Click here</a></li><br/>
                    <li> Ratio and Proportion <a href="pdfs/maths/Ratio and Proportion.pdf" target="_blank">Click here</a></li><br/>
                    <li> Time & Work <a href="pdfs/maths/Time & Work.pdf" target="_blank">Click here</a></li><br/>
                    <li> trignomnty <a href="pdfs/maths/trignomnty.pdf" target="_blank">Click here</a></li><br/>
                   

           </ul>
</ul></div>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
</body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>