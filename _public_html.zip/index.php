<?php
 session_start();
 $servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $connect = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if(isset($_POST["login"]))
	
    {
      if(empty($_POST["uemail"])  || empty($_POST["upass"]))
     {
      $message = '<label>All field is required</lable>';
     }
     else
	 {
       $query = "SELECT * FROM user_registration WHERE uemail = :uemail AND upass = :upass";
       $statement = $connect->prepare($query);
       $statement->execute(
              array(

                     'uemail'   =>   $_POST["uemail"],

                     'upass'   =>    $_POST["upass"]

                     )

          );

          $count = $statement->rowCount();

          if($count > 0)

          {

              $_SESSION["uemail"] = $_POST["uemail"];
			  
              header("location:service.php");
              
			 
  
    

          }

          else
             {

            $message = '<label>Email id OR Password is wrong</label>';
			 }
	 }
	}
  }
  catch(PDOException $error)
    {
		$message =$error->getMessage();
 }
?>
<!doctype html>
 <html>
     <head>
    <title>Great Free learning|Un-school|Mystudyguru - </title>
    
       <meta charset='utf-8'>
 <meta name="description" content="Get free best study material and audiobook for UPSC,SSC,RRB,ctet, super tet uptet and all other competitive exams|also buy and sell old books free.">
<meta name="keywords" content="current affairs 2020,current affair today,ssc cgl 2020,up board result 2020,upsc result 2020,sarkari,sarkari result,free audiobook">
<meta name="author" content="Harshvardhan Siddhartha">
<meta name="robots" content="index, follow"/>
<meta name="googlebot" content="index, follow"/>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=East+Sea+Dokdo&family=Langar&family=Ranchers&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css\h-style.css">
  <link rel="stylesheet" type="text/js" href="style.js">
  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
         <script src="https://www.googleoptimize.com/optimize.js?id=OPT-P6FPBS8"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-168225307-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-168225307-1');
</script>
  
     </head> 
<body>
<nav class="navbar navbar-expand-sm navbar-dark bg sticky-top">

<a href="#" class="navbar-brand text-white"><img src="images/Mystudyguru-logo.jpg" alt="mystudyguru logo" class="img-responsive rounded-circle" style="width:70px;"/><label style="font-family: 'Ranchers', cursive;">  My Study Guru</label></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
   <div class="collapse navbar-collapse" id="navbarNavDropdown">
<ul class="navbar-nav mr-auto w-100 justify-content-end">

  <li class="nav-item active">
          <a class="nav-link text-white" href="log.php"><span class="glyphicon glyphicon-home"></span><br class="hidden-xs"><label style="font-family: 'Ranchers', cursive;"> Sign In</label></a>
        </li>
		<li class="nav-item">
          <a class="nav-link text-white" href="#get-started"><span class="glyphicon glyphicon-comment"></span><br class="hidden-xs"><label style="font-family: 'Ranchers', cursive;"  >Get Started !</label></a>
        </li>
			<li class="nav-item">
          <a class="nav-link text-white" href="https://mystudyguru.in/about%20us.php"><span class="glyphicon glyphicon-comment"></span><br class="hidden-xs"><label style="font-family: 'Ranchers', cursive;"  data-trigger="focus" data-target="#get-started" >About us</label></a>
        </li>
        
        	<li class="nav-item">
          <a class="nav-link text-white" href="https://mystudyguru.in/contact.php"><span class="glyphicon glyphicon-comment"></span><br class="hidden-xs"><label style="font-family: 'Ranchers', cursive;"  data-trigger="focus" data-target="#get-started" >Contact us</label></a>
        </li>
   </ul></div>
</nav>
<img src="images/Website.png" alt="msg iphone image" class="img-fluid">

<section class="fixed"  >
<div class="container" id="get-started">
<div class="col ">
<h1 align="center" class="display-5" style="font-family: 'Ranchers', cursive;">Get In for free! </h1>
<div class="container-fluid bdr">
<div class="container  col-12 col-md-8 ctn">
<center><a href=""><img src="images/get inside.png" alt="free upsc coaching" class="img-fluid" style="width:220px; height: 220px;"></a></center>
<center><a class="login-btn" href="https://accounts.google.com/o/oauth2/auth?response_type=code&access_type=online&client_id=1019390744291-too8ht14o2ua988hmf1nc4aj48kvlmd1.apps.googleusercontent.com&redirect_uri=http%3A%2F%2Fmystudyguru.in%2Fglogin.php&state&scope=email%20profile&approval_prompt=auto"><button class="btn btn-primary"><img src="images/google.png" alt="goole-login image" style="width:35px; height: 35px; class=" img-fluid">Login with Google</button></a></center>
<br/>
<center>
<form method="post">
<input type="email" class="un" name="uemail" class="form-control" placeholder="Enter E-mail" />
<br />
<input type="password" class="un" name="upass" class="form-control" placeholder="Enter Password" /><br/>
<br><input type="submit" name="login" class="btn btn-primary btn1" value="Login" />
</form><br><br>
<div><center><p><font size="5px">Create an Account? <a href="#" data-toggle="modal" data-target="#exampleModal">SignUp</a></font></p></center></div>
</center>
</div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="container-fluid">
<div class="container ctn1 rounded">
<h1 align="center" style="font-family:Georgia;">Join Us</h1>
<form action="insertdata.php" method="post">
<div class="form-group">
<label for="exampleInputPassword1">Username</label>
<input type="text" name="uname" class="form-control un" id="exampleInputPassword1" placeholder="Username">
</div>
<div class="form-group">
<label for="exampleInputEmail1">Email address</label>
<input type="email" name="uemail" class="form-control un" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
</div>
<div class="form-group">
<label for="exampleInputPassword1">Password</label>
<input type="password" name="upass" class="form-control un" id="exampleInputPassword1" placeholder="Password">
</div>
<div class="form-check">
<input type="checkbox" class="form-check-input" id="exampleCheck1">
<label class="form-check-label" for="exampleCheck1">Check me out</label>
</div>
<button type="submit" name="insert" class="btn btn-primary">SignUp</button>
<div class="spinner-grow" role="status">
<span class="sr-only">Loading...</span>
</div>
</form>
</div>
</div></div></div></div>

</div></div>
</section>


<section>
<div class="container-fluid">
<div  class="row">

<div class="col-3 harsh">
<p>
<b>Free Study Material</b><br>
<i> 10000+ Free most important and to the point minified notes.</i>
</p>
</div>
<div class="col-3 harsh">
<p>
<b>Learn Anytime Anywhere</b><br>
<i> Total free learning in less time with new technique of learning by listening with Audiobooks.</i>
</p>
</div>
<div class="col-3 harsh">
<p>
<b>Learn free Earn Free</b><br>
<i> Now your old book no more scrap.Sell and buy old book and earn money</i>
</p>
</div>
<div class="col-3 harsh">
<p>
<b>Practice and Revise</b><br>
<i>Learning is not limited upto reading,try our quiz and previous year papers.</i>
</p>
</div>
</div>
</div>
</section><br/>

<br/><section>
<div class="container border">
<a href="log.php"><button class="btn btn-primary">Start Learning</button></a>
<p> <ol class="list-inline">
<b>Popular Goals :</b>
<li class="list-inline-item">UPSC</li>
<li class="list-inline-item">SSC</li>
<li class="list-inline-item">RRB</li>
<li class="list-inline-item">Bank Exams</li>
<li class="list-inline-item">State Exams</li>
</ol></p>


  <section>
  <div class="container msg_track ">
  <ul>
  <li class=""><img src="images/track-images/register.png" alt="get register msg" class="img-fluid" >
<br/><i class="fa text-white fa-check"></i>  
  <p>Register</p>
  </li>
  <li class=""><img src="images/track-images/learn.png" alt="free learning courses" class="img-fluid">
<br/>  <i class="fa text-white fa-adjust"></i>
  <p>Start-Learning</p>
  </li>
  <li class=""><img src="images/track-images/exam.png" alt="exam time preparation" class="img-fluid" >
  <br/><i class="fa text-white fa-adjust"></i>
  <p>Quiz!</p>
  </li>
  <li class=""><img src="images/track-images/finish.png" alt="successful life" class="img-fluid">
  <br/><i class="fa text-white fa-circle"></i>
  <p>Success</p>
  </li>
  </ul>
  </div>
  </section>

</div>
</section>

<br/>


<section>
<div class="container">
<div class="containter  float-center">
<h1>Education <p><i class="text-muted">"Your door to the future"</i></p></h1>
<p class="text-justify " style="font-family:'Langar', cursive;">Here,you can get the best Free Study Material,Audiobook,Syllabus,Preceding Years ExamPapers,Current Affairs,G.K tricks and Quizzes for Competition Exam preparations like:-UPSC,SSC,RRB,TET/C-TET/S-TET,BANK,POLICE,ARMY and other state level exams.<br>Also, now you can SELL and BUY Books. Moreover,you can DONATE Books for the needy.</p>
</div></div></section>
<br>
<section>
<div class="container">
<h2><i class="text-muted">"Learn on the go"</i></p></h2>
<p style="font-family:'Langar', cursive;" class="text-justify">
This is necessary information for the preparation Of Bank, SSC, Railways, PSC Exams, and other competitive exams and most importantly General Knowledge which is incredibly helpful for many exams.<br>
 If you had the chance to participate in any competitive exam,<br> you must have seen there were a lot of questions related to General Knowledge and current affairs. <br>
 Many a time it happens, the questions of mathematics, reasoning ability couldn't be solved <br> but if you have a good knowledge of GK and affairs, you can make an easy guess to get those points.<br>
 So considering these points, We have designed the best and point-to-point study material which is adequate and guarantee you that exam questions would be included from it.<br>
 The best thing about our sophisticated study material is that it's completely free and competes with any paid courses available in the market.<br>
 Our study material is constructed after deeply analysing various remarkable coaching <br>institute's study material and previous question paper patterns.<br>
 Enroll for free and start learning NOW! <br> Soon we are going to launch a test series for all competitive exams. It would cover frequent and important questions asked in such exams.<br> 
 You will also be awarded an e-certificate after successfully completing and scoring in the test series.<br> This certificate would be a measure of your General Knowledge and affairs and would also be an advantage in further interviews.
 So What are you waiting for! <br>
<br> <label class="text-danger">HURRY UP!!</label> 
 <br>Join MyStudyGuru for free learning.
</p>
</div></section>

<footer>
<div class="curved">

                </p>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#8b62c7" fill-opacity="1" d="M0,32L48,53.3C96,75,192,117,288,138.7C384,160,480,160,576,144C672,128,768,96,864,69.3C960,43,1056,21,1152,21.3C1248,21,1344,43,1392,53.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
</svg>
</div>
<div class="container-fluid bg">
<div  class=" row text-white">
<div class="col-5 ">
                <a href="index.php">
                    <img src="images/Mystudyguru-logo.jpg" class="img-fluid rounded" alt="msg logo" 
                        style="width:95px; height: 95px; padding-bottom: 8px; margin-right:10px; "></a>
						<br>
					<p class="msg_font">Is this website helpful to you? Please stay tuned and do share.</p>
</div>
<div align ="center" class="col-3">
<p >
<a href="https://mystudyguru.in/about%20us.php" class="text-white msg_font">About us</a><br/>
<a href="https://mystudyguru.in/contact.php" class="text-white msg_font">Contact us</a><br/>
<a href="blog.php" class="text-white msg_font">Blogs</a><br/>
<a href="https://www.privacypolicygenerator.info/live.php?token=a7qj4V7IIjUtLDkot1BeUS7vmhYgnClI" class="text-white msg_font">Privacy Policy</a><br>
<a href="https://www.disclaimergenerator.net/live.php?token=vJ7RmauJUrxKHxUArHQRpys6ugqTkmrF" class="text-white msg_font">Disclaimer</a><br>
<a href="https://mystudyguru.in/sitemap.xml" class="text-white msg_font">Sitemap</a>
</p>
</div>
<div align ="center" class="col-3">
<p class="text-white msg_font">Community</p>
	<div class="socials text-white">
                 <a href="https://www.facebook.com/FreeEducationGuru/" class="fa fa-facebook"></a>
				 <a href="https://www.youtube.com/channel/UCpPvXbbksbXZzfah3vEziUw?view_as=subscriber" class="fa fa-youtube"></a>
<a href="https://twitter.com/9mystudyguru" class="fa fa-twitter"></a>
<a href="https://www.linkedin.com/company/mystudyguru.in/" class="fa fa-linkedin"></a>
<a href="https://www.instagram.com/mystudyguru.in/" class="fa fa-instagram"></a>
                </div>
</div>
</div></div>
</footer>
<p align ="center" class="msg_font">All rights are reserved. ©2020| My Studyguru Ltd.</p>
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
   </body>

 </html>