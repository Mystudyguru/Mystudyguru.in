<?php
include 'Head_Foot/header.html'; 
?>
<!DOCTYPE>
<html>
<head>
<style>
.ac{
background-color:#8b62c7;

}
a{ font-family:georgia;
 
}
a:hover{ 
       font-size:21px;
	   text-decoration:none;
}
.as{
    background-color:#D0D3D4;
	height:500px;
}
li{font-size:20px;
  text-shadow:1px 1px 1px black;
}
.cbox{
background-color:#8b62c7;
border-radius:5px;
margin:20px;}
.ctn{
height:250px;
padding:20px;
background-color:#D0D3D4;
border-radius:5px;}
</style>
 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<meta name="keywords" content="rrb-ntpc syllabus download,rrb groupd syllabus,rrb ntpc admit card 2020,groupd admit card 2020,rrb ntpc groupd exam,rrb ntpc groupd previous year papers">
<meta name="robots" content="index, follow" />
<meta name="googlebot" content="index, follow" />
<meta http-equiv='X-UA-Compatible' content='IE=edge'>
<title>RRB-NTPC Group-D Exam(2020)</title>
</head>
<body style="background-color:#F8EBFF;">


<div class="container-fluid border border-info  ac">
<div class="row color-section pt-2 m-0">
        <div class="col text-white ">
<h1 class="display-5"  align="center"; style="font-family:georgia, serif; color:white; "> <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-book" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.214 1.072C4.813.752 6.916.71 8.354 2.146A.5.5 0 0 1 8.5 2.5v11a.5.5 0 0 1-.854.354c-.843-.844-2.115-1.059-3.47-.92-1.344.14-2.66.617-3.452 1.013A.5.5 0 0 1 0 13.5v-11a.5.5 0 0 1 .276-.447L.5 2.5l-.224-.447.002-.001.004-.002.013-.006a5.017 5.017 0 0 1 .22-.103 12.958 12.958 0 0 1 2.7-.869zM1 2.82v9.908c.846-.343 1.944-.672 3.074-.788 1.143-.118 2.387-.023 3.426.56V2.718c-1.063-.929-2.631-.956-4.09-.664A11.958 11.958 0 0 0 1 2.82z"/>
  <path fill-rule="evenodd" d="M12.786 1.072C11.188.752 9.084.71 7.646 2.146A.5.5 0 0 0 7.5 2.5v11a.5.5 0 0 0 .854.354c.843-.844 2.115-1.059 3.47-.92 1.344.14 2.66.617 3.452 1.013A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.276-.447L15.5 2.5l.224-.447-.002-.001-.004-.002-.013-.006-.047-.023a12.582 12.582 0 0 0-.799-.34 12.96 12.96 0 0 0-2.073-.609zM15 2.82v9.908c-.846-.343-1.944-.672-3.074-.788-1.143-.118-2.387-.023-3.426.56V2.718c1.063-.929 2.631-.956 4.09-.664A11.956 11.956 0 0 1 15 2.82z"/>
</svg><br/>Railway Special Express</h2></br>
</div>
</div>
</div>
<div class="container-fluid border border-dark">
<div class="jumbotron jumbotron-fluid">
 <p style="font-family:'Galada',Cursive; font-size:20px">It's time to grab the career opportunity. Because RRB(Railway Recruitment Board) has announced a total of 1.40 lakh vacancies..<p>In which railway secured 103769 vacancies for the post of Group-D 2020</p><p>RRB-NTPC(Non-Technical Popular categories) has 35208 vacancies including 24605 Graduate level post and 10603 Undergraduate posts across which more then 1.26 crore form has been submitted that by competition level gone a high</p> So let get started with some knowledge about the RRB-NTPC and Group-D examination which gone held on <label class="text-primary">15th december 2020</label> and its admit card will be released on<label class="text-primary"> 22nd November 2020</label>.So firstly download syllabus of exam then set up your stopwatch and solve  each paper in a fixed time.
 Here are some free quiz practice for you related to latest pattern of exam and also latest daily current affairs</p>
<center> <b><p style="font-family:georgia; font-size:28px">ALL THE BEST  <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-hand-thumbs-up" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M6.956 1.745C7.021.81 7.908.087 8.864.325l.261.066c.463.116.874.456 1.012.965.22.816.533 2.511.062 4.51a9.84 9.84 0 0 1 .443-.051c.713-.065 1.669-.072 2.516.21.518.173.994.681 1.2 1.273.184.532.16 1.162-.234 1.733.058.119.103.242.138.363.077.27.113.567.113.856 0 .289-.036.586-.113.856-.039.135-.09.273-.16.404.169.387.107.819-.003 1.148a3.163 3.163 0 0 1-.488.901c.054.152.076.312.076.465 0 .305-.089.625-.253.912C13.1 15.522 12.437 16 11.5 16v-1c.563 0 .901-.272 1.066-.56a.865.865 0 0 0 .121-.416c0-.12-.035-.165-.04-.17l-.354-.354.353-.354c.202-.201.407-.511.505-.804.104-.312.043-.441-.005-.488l-.353-.354.353-.354c.043-.042.105-.14.154-.315.048-.167.075-.37.075-.581 0-.211-.027-.414-.075-.581-.05-.174-.111-.273-.154-.315L12.793 9l.353-.354c.353-.352.373-.713.267-1.02-.122-.35-.396-.593-.571-.652-.653-.217-1.447-.224-2.11-.164a8.907 8.907 0 0 0-1.094.171l-.014.003-.003.001a.5.5 0 0 1-.595-.643 8.34 8.34 0 0 0 .145-4.726c-.03-.111-.128-.215-.288-.255l-.262-.065c-.306-.077-.642.156-.667.518-.075 1.082-.239 2.15-.482 2.85-.174.502-.603 1.268-1.238 1.977-.637.712-1.519 1.41-2.614 1.708-.394.108-.62.396-.62.65v4.002c0 .26.22.515.553.55 1.293.137 1.936.53 2.491.868l.04.025c.27.164.495.296.776.393.277.095.63.163 1.14.163h3.5v1H8c-.605 0-1.07-.081-1.466-.218a4.82 4.82 0 0 1-.97-.484l-.048-.03c-.504-.307-.999-.609-2.068-.722C2.682 14.464 2 13.846 2 13V9c0-.85.685-1.432 1.357-1.615.849-.232 1.574-.787 2.132-1.41.56-.627.914-1.28 1.039-1.639.199-.575.356-1.539.428-2.59z"/>
</svg></p></b></center>
</div>
</div>
 <div class="container content ban1" id="welcome" style="background-color:#00cc92;">
    <h2 style="font-family:Georgia;" align="center">Syllabus & Features</h2>
<a  style="text-decoration:none" href="pdfs/rrb/RRB-ntpc-syllabus(2020).pdf"><center><button type="button"  class="btn btn-sm btn-light">NTPC syllabus</button></a>
<a href="pdfs/rrb/rrb group-d-syllabus(2020).pdf"><button type="button"  class="btn btn-sm btn-light">Group-D syllabus</button></a>
	<a href="https://mystudyguru.in/current-affairs.php"><button type="button"  class="btn btn-sm btn-light">Latest Current Affairs</button></a>
	<a href="https://mystudyguru.in/quiz.php"><button type="button"  class="btn btn-sm btn-light">Quiz!</button></a>
		</center>
  </div><br>
<h2 align="center">Railway Study-Material</h2>
<div class="container as overflow-auto ">
<br>
<ul>
<li>General Science in hindi<a href="pdfs/rrb/gerenal-science(hindi)2.pdf" target="_blank" >Click here</a></li><br/>
<li>General Science 2 <a href="pdfs/rrb/gerenal-science(hindi)2.pdf" target="_blank" >Click here</a></li><br/>
<li>General Science 3 <a href="pdfs/rrb/RRB-1-GK-SSC-SCI.pdf" target="_blank"> Click here</a></li><br/>
<li>General Science 4 <a href="pdfs/rrb/RRB-G-K-CHEM(hindi).pdf" target="_blank" >Click here</a></li><br/>
<li>General Science 5 <a href="pdfs/rrb/99+RRB-NTPC-NOTES.pdf" target="_blank" >Click here</a></li><br/>
<li>General Science <a href="pdfs/upsc/999+rrb-one-word-answer.pdf" target="_blank" >Click here</a></li><br/>
<li>General phyiscs <a href="pdfs/railway/RRB-G-K-CHEM(hindi).pdf" target="_blank">Click here</a></li><br/>
<li>General chemistry <a href="pdfs/rrb/rrb-gs-bio-chem(hindi).pdf" target="_blank" >Click here</a></li><br/>
<li>General Bio <a href="pdfs/upsc/gkbio.pdf" target="_blank" >Click here</a></li><br/>
<li>General Science solved MCQ's<a href="pdfs/rrb/99+MCQ-RRB-GK.pdf" target="_blank" >Click here</a></li><br/>
<li>General Science in hindi<a href="pdfs/rrb/499+RRB-GS-Short-Answer1.pdf" target="_blank" >Click here</a></li><br/>
<li>Cups and Trophies <a href="pdfs/ssc/ssc1.pdf" target="_blank">Click here</a></li><br/>
<li>MCQs General Science <a href="pdfs/rrb/rrb-gs-bio-chem(hindi).pdf" target="_blank" >Click here</a><l/i><br/>
<li>G.S Important Dates <a href="pdfs/upsc/important dates.pdf" target="_blank" >Click here </a></li><br/>
<li>G.S One Liner <a href="pdfs/upsc/One-Liner-gk.pdf" target="_blank" >Click here</a></li><br/>
<li>99+ Important Questions <a href="pdfs/rrb/99+RRB-G-K-short-anwers.pdf" target="_blank" >Click here</a></li><br/>
<li>G.S 500+ Important Question <a href="pdfs/rrb/499+RRB-GS-Short-Answer.pdf" target="_blank" >Click here </a></li><br/>
<li>G.S 1000+ Important Questions <a href="pdfs/ssc/ssc1000.pdf" target="_blank" >Click here</a></li><br/>
<li>G.S 9000+ Important Questions <a href="pdfs/rrb/8999+RRB-GS-short-Answers(hindi).pdf" target="_blank">Click here</a></li><br/>
 
<hr>
</ul>
<!--MATHS COOMIN FOR ALL SUBJECTS-->
 
             <ul>
                    <h1 class="display-5 p-2">MATHS</h1>
                    <li>Maths <a href="pdfs/rrb/profit-loss.pdf" target="_blank">Click here</a></li><br/>
                    
                    <li>1. NUMBERS  <a href="pdfs/maths/1. NUMBERS.pdf" target="_blank">Click here</a></li><br/>
                    <li>2. H.C.F. AND L.C.M. OF NUMBERS <a href="pdfs/maths/2. H.C.F. AND L.C.M. OF NUMBERS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 3. DECIMAL FRACTIONS <a href="pdfs/maths/3. DECIMAL FRACTIONS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 4. SIMPLIFICATION <a href="pdfs/maths/4. SIMPLIFICATION.pdf" target="_blank">Click here</a></li><br/>
                    <li> 5.SQUARE ROOTS AND CUBE ROOTS <a href="pdfs/maths/ 5.SQUARE ROOTS AND CUBE ROOTS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 6.AVERAGE <a href="pdfs/maths/ 6.AVERAGE.pdf" target="_blank">Click here</a></li><br/>
                    <li> 7 Problems on numbers <a href="pdfs/maths/7 Problems on numbers.pdf" target="_blank">Click here</a></li><br/>
                    <li> 8 Problems on ages <a href="pdfs/maths/8 Problems on ages.pdf" target="_blank">Click here</a></li><br/>
                    <li> 9 surds and indices .<a href="pdfs/maths/9 surds and indices.pdf" target="_blank">Click here</a></li><br/>
                    <li> 10 percentage<a href="pdfs/maths/10 percentage.pdf" target="_blank">Click here</a></li><br/>
                    <li> 11 profit and loss. <a href="pdfs/maths/11 profit and loss..pdf" target="_blank">Click here</a></li><br/>
                    <li> 12. RATIO AND PROPORTION <a href="pdfs/maths/12. RATIO AND PROPORTION.pdf" target="_blank">Click here</a></li><br/>
                    <li> 13. PARTNERSHIP <a href="pdfs/maths/13. PARTNERSHIP.pdf" target="_blank">Click here</a></li><br/>
                    <li> 14. CHAIN RULE <a href="pdfs/maths/14. CHAIN RULE.pdf" target="_blank">Click here</a></li><br/>
                    <li> 15. TIME AND WORK <a href="pdfs/maths/15. TIME AND WORK.pdf" target="_blank">Click here</a></li><br/>
                    <li> 16. PIPES AND CISTERNS <a href="pdfs/maths/16. PIPES AND CISTERNS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 17. TIME AND DISTANCE <a href="pdfs/maths/17. TIME AND DISTANCE.pdf" target="_blank">Click here</a></li><br/>
                    <li> 19.BOATS AND STREAMS <a href="pdfs/maths/19.BOATS AND STREAMS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 20. ALLIGATION OR MIXTURE <a href="pdfs/maths/20. ALLIGATION OR MIXTURE.pdf" target="_blank">Click here</a></li><br/>
                    <li>21. SIMPLE INTEREST <a href="pdfs/maths/21. SIMPLE INTEREST.pdf" target="_blank">Click here</a></li><br/>
                    <li> 22.COMPOUND INTEREST <a href="pdfs/maths/22.COMPOUND INTEREST.pdf" target="_blank">Click here</a></li><br/>
                    <li> 23. LOGARITHMS <a href="pdfs/maths/23. LOGARITHMS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 24 .AREA <a href="pdfs/maths/24 .AREA.pdf" target="_blank">Click here</a></li><br/>
                    <li> 25.VOLUME AND SURFACE AREA <a href="pdfs/maths/ 25.VOLUME AND SURFACE AREA.pdf" target="_blank">Click here</a></li><br/>
                    <li> 26. RACES AND GAMES .<a href="pdfs/maths/math1.pdf" target="_blank">Click here</a></li><br/>
                    <li> 27. CALENDAR <a href="pdfs/maths/27. CALENDAR.pdf" target="_blank">Click here</a></li><br/>
                    <li> 28. CLOCKS <a href="pdfs/maths/28. CLOCKS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 29. STOCKS AND SHARES <a href="pdfs/maths/29. STOCKS AND SHARES.pdf" target="_blank">Click here</a></li><br/>
                    <li> 30. PERMUTATIONS AND COMBINATIONS <a href="pdfs/maths/30. PERMUTATIONS AND COMBINATIONS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 31. PROBABILITY <a href="pdfs/maths/31. PROBABILITY.pdf" target="_blank">Click here</a></li><br/>
                    <li> 32. TRUE DISCOUNT <a href="pdfs/maths/32. TRUE DISCOUNT.pdf" target="_blank">Click here</a></li><br/>
                    <li> 33. BANKER'S DISCOUNT <a href="pdfs/maths/33. BANKER'S DISCOUNT.pdf" target="_blank">Click here</a></li><br/>
                    <li> 34. HEIGHTS AND DISTANCES <a href="pdfs/maths/34. HEIGHTS AND DISTANCES.pdf" target="_blank">Click here</a></li><br/>
                    <li> 35. TABULATION <a href="pdfs/maths/35. TABULATION.pdf" target="_blank">Click here</a></li><br/>
                    <li> 36.BAR GRAPHS <a href="pdfs/maths/36.BAR GRAPHS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 37. PIE-CHARTS <a href="pdfs/maths/37. PIE-CHARTS.pdf" target="_blank">Click here</a></li><br/>
                    <li> 38.LINE-GRAPHS <a href="pdfs/maths/38.LINE-GRAPHS.pdf" target="_blank">Click here</a></li><br/>
                    <li> Algebra <a href="pdfs/maths/Algebra.pdf" target="_blank">Click here</a></li><br/>
                    <li> Geometry <a href="pdfs/maths/Geometry.pdf" target="_blank">Click here</a></li><br/>
                    <li> IA-07trigonometric-functions37-40 <a href="pdfs/maths/IA-07trigonometric-functions37-40.pdf" target="_blank">Click here</a></li><br/>
                    <li> IA-15propeties-of-triangles69-78 <a href="pdfs/maths/IA-15propeties-of-triangles69-78.pdf" target="_blank">Click here</a></li><br/>
                    <li> IA-16heights_distances79-85 <a href="pdfs/maths/IA-16heights_distances79-85.pdf" target="_blank">Click here</a></li><br/>
                    <li> Mensuration <a href="pdfs/maths/Mensuratiom.pdf" target="_blank">Click here</a></li><br/>
                    <li> Number System. <a href="pdfs/maths/Number System..pdf" target="_blank">Click here</a></li><br/>
                    <li> Percentage <a href="pdfs/maths/Percentage.pdf" target="_blank">Click here</a></li><br/>
                    <li> Ratio and Proportion <a href="pdfs/maths/Ratio and Proportion.pdf" target="_blank">Click here</a></li><br/>
                    <li> Time & Work <a href="pdfs/maths/Time & Work.pdf" target="_blank">Click here</a></li><br/>
                    <li> trignomnty <a href="pdfs/maths/trignomnty.pdf" target="_blank">Click here</a></li><br/>
                   

           </ul>
        <hr>
        <!--COMMON DOCUMENT-->
         
    <ul>
           <h1 class="display-5 p-2">MISCELLANEOUS</h1>
           <li> Basic Points of Geography <a href="pdfs/common/Basic Points of Geography.pdf" target="_blank">Click here</a></li><br/>
           <li> Blood_relation <a href="pdfs/common/Blood_relation.pdf" target="_blank">Click here</a></li><br/>
           <li> Calander <a href="pdfs/common/Calander.pdf" target="_blank">Click here</a></li><br/>
           <li> Computer_facts <a href="pdfs/common/Computer_facts.pdf" target="_blank">Click here</a></li><br/>
           <li> Computer_notes <a href="pdfs/common/Computer_notes.pdf" target="_blank">Click here</a></li><br/>
           <li> Genral_science (question_answes) <a href="pdfs/common/Genral_science (question_answes).pdf" target="_blank">Click here</a></li><br/>
           <li> GK_1000 _questions <a href="pdfs/common/GK_1000 _questions.pdf" target="_blank">Click here</a></li><br/>
           <li>	 Important Formulaes of AREA  <a href="pdfs/common/Important Formulaes of AREA .pdf" target="_blank">Click here</a></li><br/>
           
           
        </ul>
    </div>
    <br>
<h2 align="center">Railway ExamPapers</h2>
<div class="container-fluid row">
<div class="col-11 col-md-5  container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia;">RRB-NTPC<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li>RRB NTPC Stage-1 All papers(2016) <a href="pdfs/rrb/RRB NTPC Stage1 English All  2016.pdf">Click here</a></li>
<li>RRB-NTPC-28th-March-2016-Shift-1-Hindi(1) <a href="pdfs/rrb/RRB-NTPC-28th-March-2016-Shift-1-Hindi(1)">Click here</a></li>
<li>RRB-NTPC-29th-March-2016-Shift-1-Hindi <a href="pdfs/rrb/RRB-NTPC-29th-March-2016-Shift-1-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-02nd-April-2016-Shift-1-Hindi <a href="pdfs/rrb/RRB-NTPC-02nd-April-2016-Shift-1-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-02nd-April-2016-Shift-2-Hindi(1) <a href="pdfs/rrb/RRB-NTPC-02nd-April-2016-Shift-2-Hindi(1)">Click here</a></li>
<li>RRB-NTPC-04th-April-2016-Shift-1-Hindi(1) <a href="pdfs/rrb/RRB-NTPC-04th-April-2016-Shift-1-Hindi(1)">Click here</a></li>
<li>RRB-NTPC-05th-April-2016-Shift-1-Hindi <a href="pdfs/rrb/RRB-NTPC-05th-April-2016-Shift-1-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-05th-April-2016-Shift-2-Hindi <a href="pdfs/rrb/RRB-NTPC-05th-April-2016-Shift-2-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-05th-April-2016-Shift-3-Hindi <a href="pdfs/rrb/RRB-NTPC-05th-April-2016-Shift-3-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-09th-April-2016-Shift-3-Hindi <a href="pdfs/rrb/RRB-NTPC-09th-April-2016-Shift-3-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-11th-April-2016-Shift-1-Hindi <a href="pdfs/rrb/RRB-NTPC-11th-April-2016-Shift-1-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-11th-April-2016-Shift-2-Hindi <a href="pdfs/rrb/RRB-NTPC-11th-April-2016-Shift-2-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-18th-April-2016-Shift-2-Hindi <a href="pdfs/rrb/RRB-NTPC-18th-April-2016-Shift-2-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-27th-April-2016-Shift-1-Hindi <a href="pdfs/rrb/RRB-NTPC-27th-April-2016-Shift-1-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-28th-April-2016-Shift-1-Hindi <a href="pdfs/rrb/RRB-NTPC-28th-April-2016-Shift-1-Hindi.pdf">Click here</a></li>
<li>RRB-NTPC-mains-paper-jan-shift-1 <a href="pdfs/rrb/RRB-NTPC-mains-paper-jan- shift1.pdf">Click here</a></li>
</ul></div>
</div>

<div class="col-11 col-md-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia;">Group-D<hr></h2>
<div class="container ctn overflow-auto"><ul>
        <h1 class="display-5 text-center">IMP-QUES-2020</h1>
    <li>RRB Group D Questions Part -1.pdf <a href="pdfs/rrb/RRB Group D Questions Part -1.pdf">Click Here<a></li>
<li>RRB Group D Questions Part 2-hindi.pdf <a href="pdfs/rrb/RRB Group D Questions Part 2-hindi.pdf">Click Here<a></li>
<li>RRB Group D Questions Part 3-hindi.pdf <a href="pdfs/rrb/RRB Group D Questions Part 3-hindi.pdf">Click Here<a></li>
<li>RRB-group-d-paper-hindi-4.pdf <a href="pdfs/rrb/RRB-group-d-paper-hindi-4.pdf">Click Here<a></li>
<li>RRB-GROUP-D-PART-5(HINDI).pdf <a href="pdfs/rrb/RRB-GROUP-D-PART-5(HINDI).pdf">Click Here<a></li>
<li>RRB-GROUP-D-PART-6(HINDI).pdf <a href="pdfs/rrb/RRB-GROUP-D-PART-6(HINDI).pdf">Click Here<a></li>
<li>RRB-GROUP-D-PART-7(HINDI).pdf <a href="pdfs/rrb/RRB-GROUP-D-PART-7(HINDI).pdf">Click Here<a></li>
<li>RRB-GROUP-D-PART-8(HINDI).pdf <a href="pdfs/rrb/RRB-GROUP-D-PART-8(HINDI).pdf">Click Here<a></li>
<li>RRB-GROUP-D-PART-9 <a href="pdfs/rrb/RRB-GROUP-D-PART-9(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-10(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-10(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-11(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-11(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-12(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-12(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-13(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-13(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-14(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-14(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-15(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-15(HINDI)">Click Here<a></li>
<li>RRB-GROUP-D-PART-(HINDI) <a href="pdfs/rrb/RRB-GROUP-D-PART-(HINDI)">Click Here<a></li>
    
    
    
    <h1 class="display-5 text-center">2013</h1>

<li>rrb-english-2013 <a href="pdfs/rrb/rrb-english-2013.pdf">Click Here</a></li>
<li>rrc-english-2013(shify-2)-.pdf <a href="pdfs/rrb/rrc-english-2013(shify-2)-.pdf">Click Here</a></li>
<li>RRCGroup-DExamEnglish-24.pdf <a href="pdfs/rrb/RRCGroup-DExamEnglish-24.pdf">Click Here</a></li>
<h1 class="display-5 text-center">2014</h1>
<li>02-Nov-2014-English-Paper-RRB-Group-D.pdf <a href="pdfs/rrb/02-Nov-2014-English-Paper-RRB-Group-D.pdf">Click Here</a></li>
<li> RRC-Group-D-2014-English(shift-2).pdf<a href="pdfs/rrb/RRC-Group-D-2014-English(shift-2).pdf">Click Here<a></li>
<li>RRC-Group-D-Question-Paper-2014-English(shift-3).pdf <a href="pdfs/rrb/RRC-Group-D-Question-Paper-2014-English(shift-3).pdf">Click Here<a></li>
<li>RRC-Group-D-Question-Paper-2014-English(shift-4).pdf <a href="pdfs/rrb/RRC-Group-D-Question-Paper-2014-English(shift-4).pdf">Click Here</a></li>
<li>RRC-Group-D-2014-English(shift-5).pdf <a href="pdfs/rrb/RRC-Group-D-2014-English(shift-5).pdf">Click Here</a></li>
<h1 class="display-5 text-center">2018</h1>
<li> RRB-group-d-17th-sep-2018-shift-1.pdf<a href="pdfs/rrb/RRB-group-d-17th-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB_group-d-28th-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB_group-d-28th-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB-group-d-27-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB-group-d-27-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB-group-d-26-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB-group-d-26-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB-group-d-25-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB-group-d-25-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB-group-d-23-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB-group-d-23-sep-2018-shift-1.pdf">Click Here<a></li>
<li> RRB-group-d-22-sep-2018-shift-1.pdf<a href="pdfs/rrb/RRB-group-d-22-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB-group-d-20-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB-group-d-20-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB_group-d-19-sep-2018-shift-1.pdf <a href="pdfs/rrb/RRB_group-d-19-sep-2018-shift-1.pdf">Click Here<a></li>
<li>RRB-group-d-18-sep-2018-shift-1.PDF <a href="pdfs/rrb/RRB-group-d-18-sep-2018-shift-1.PDF">Click Here<a></li>


</ul></div>
</div>
</div>

        <!--END OF COMMON DOCEMENTS-->
        <!--END OF MATH SECTION-->
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
</body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>