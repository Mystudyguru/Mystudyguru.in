 <?php
include 'Head_Foot/header.html'; 
?>
 <!doctype html>
 <html>
     <head>
    <title>BOOKSTALL|bookstores -mystudyguru</title>
     <meta charset="utf-8">
     <meta name="keywords" content="bookstores,bookstore near me,bookstore online,refurnished bookstore,bookstore online india" >
     <meta name="robots" content="index,follow">
     <meta name="free bookstore in india to sell and buy refurnished books online">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
   <style>

         *{
      margin:0;
      padding:0;
      }
      .alia{
      background-color:white;
      font-family:'Georgia',serif;
      }
      .flip-card {
  background-color: transparent;
  width: 320px;
  height: 410px;
  perspective: 1000px; /* Remove this if you don't want the 3D effect */


}

/* This container is needed to position the front and back side */
.flip-card-inner {
  position: relative;
  width: 100%;
  height: 100%;
  text-align: center;

  transition: transform 0.8s;
  transform-style: preserve-3d;
}

/* Do an horizontal flip when you move the mouse over the flip box container */
.flip-card:hover .flip-card-inner {
  transform: rotateY(540deg);
}

/* Position the front and back side */
.flip-card-front, .flip-card-back {
  position: absolute;
  width: 100%;
  height: 100%;

  -webkit-backface-visibility: hidden; /* Safari */
  backface-visibility: hidden;
}

/* Style the front side (fallback if image is missing) */
.flip-card-front {
  background-color: #bbb;
  color: black;
    border: 10px inset #8b62c7;
  border-radius: 20px;

}

/* Style the back side */
.flip-card-back {
 height:400px;
  background-color: white;
  color: black;
  border: 10px outset red;
  border-radius: 20px;
  transform: rotateY(180deg);
}
      </style>

</head>

<body class="alia">
    <section>
        
          <h1 class="text-center text-capitalize text-white" style="background-color:#8b62c7;">BOOKSTALL</h1>
		 
		
       <hr class="w-25 mx-auto bg-danger"></hr>
    <div class="container-fluid pb-3">
       <div class="row text-center pt-4 " >
           <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book28.jpg " alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name:- Vijay Gupta</p>
      <p>Contact no:<label class="text-primary">+91-7017481901</label></p>
    <p>Place: Chaupla Chauraha Bareilly</p>
       <p>Price: ₹90.</p>
    </div>
  </div>
</div>

               </div>
               
                     <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/jee-physics-book.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name:- ARYAN KUMAR </p>
      <p>Contact no:<label class="text-primary">+91-7644049861</label></p>
      <p>Place: Sampatchak, Patna,Bihar</p>
       <p>Price: ₹250.</p>
    </div>
  </div>
</div>

               </div>
               
               
                   <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book29.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name:- Rohtash Chand</p>
      <p>Contact no:<label class="text-primary">+91-9808330619</label></p>
      <p>Place: Bareilly</p>
       <p>Price: ₹150.</p>
    </div>
  </div>
</div>

               </div>
                   <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book24.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
       <p>Name:- Neeraj Verma</p>
      <p>Contact no:<label class="text-primary">+91-9696376937</label></p>
      <p>Place: Lucknow</p>
       <p>Price: ₹200</p>

    </div>
  </div>
  </div>
  </div>
 



 
           <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book21.jpg" alt="Avatar"style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name :- Gaurav Singh</p>
      <p>Contact no:<label class="text-primary">+91-8923122447</label></p>
    <p>Place: Shubash Nagar(Bareilly)</p>
       <p>Price: ₹80.</p>
    </div>
  </div>
</div>

               </div>
                   <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book23.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name:- Dhirendra Singh</p>
      <p>Contact no:<label class="text-primary">+91-9373661561</label></p>
      <p>Place: 54, Ghatkotra, Mauranipur, Jhansi (UP)</p>
       <p>Price: ₹1650.</p>
    </div>
  </div>
</div>

               </div>
                   <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book1.jpg" alt="Avatar"style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
	  <p>Himanshu Sagar </p>
      <p>Contact no:<label class="text-primary">+91-6396816113</label></p>
      <p>Place: Bareilly(U.P)</p>
       <p>Price: ₹150.</p>

    </div>
  </div>
</div>

               </div>
               </div>
               </div>

 <div class="container-fluid pb-3">
       <div class="row text-center pt-4 " >
           <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book25.jpg" alt="Avatar"style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name :- Akash Patel</p>
      <p>Contact no:<label class="text-primary">+91-8171459671</label></p>
    <p>Place: Bareilly</p>
       <p>Price: ₹100.</p>
    </div>
  </div>
</div>
</div>

			   
 <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book26.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
       <h1>Seller<hr></h1>
      <p>Name :- Akash Patel</p>
      <p>Contact no:<label class="text-primary">+91-8171459671</label></p>
    <p>Place: Bareilly</p>
       <p>Price: ₹300.</p>
    </div>
  </div>
</div>

               </div>
			   
 <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book22.jpg" alt="Avatar"style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
       <p>Name:- Sahabuddin Mansuri</p>
      <p>Contact no:<label class="text-primary">+91-6306282990</label></p>
      <p>Place: Padrauna(U.P)</p>
       <p>Price: ₹250.</p>

    </div>
  </div>
</div>
</div>
</div>
</div>

 <div class="container-fluid pb-3">
       <div class="row text-center pt-4 " >
           <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book10.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name : Harshwardhan</p>
      <p>Contact no:<label class="text-primary">+91- 6396816113</label></p>
    <p>Place: Bareilly</p>
       <p>Price: 75rs.</p>
    </div>
  </div>
</div>

               </div>
                   <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book11.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name: Harshwardhan</p>
      <p>Contact no:<label class="text-primary">+91- 6396816113</label></p>
      <p>Place: Bareilly</p>
       <p>Price: 75rs.</p>
    </div>
  </div>
</div>

               </div>
                   <div class="col-lg-4 col-md-4 col-12">



<div class="flip-card ml-4  mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book12.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
       <p>Name: Harshwardhan</p>
      <p>Contact no:<label class="text-primary">+91- 6396816113</label></p>
      <p>Place: Bareilly</p>
       <p>Price: 75rs.</p>

    </div>
  </div>
</div>

               </div>
               </div>
               </div>


 <div class="container-fluid pb-3">
       <div class="row text-center pt-4 " >
           <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book13.jpg" alt="Avatar"style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name : Harshwardhan</p>
      <p>Contact no:<label class="text-primary">+91- 6396816113</label></p>
    <p>Place: Bareilly</p>
       <p>Price: 75rs.</p>
    </div>
  </div>
</div>

               </div>
<div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book14.jpg" alt="Avatar" style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
      <p>Name: Harshwardhan</p>
      <p>Contact no:<label class="text-primary">+91- 6396816113</label></p>
      <p>Place: Bareilly</p>
       <p>Price: 75rs.</p>
    </div>
  </div>
</div>
 </div>
                   
<div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="images/books/book15.jpg" alt="Avatar"style="width:290px; height:390px;">
    </div>
    <div class="flip-card-back">
      <h1>Seller<hr></h1>
       <p>Name: Harshwardhan</p>
      <p>Contact no:<label class="text-primary">+91- 6396816113</label></p>
      <p>Place: Bareilly</p>
       <p>Price: 75rs.</p>

    </div>
  </div>
</div>
               </div>
               
               
               <div class="col-lg-4 col-md-4 col-12">
<div class="flip-card ml-4 mb-4">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <h1 class="display-4">Upload Your Books!</h1>
    </div>
    <div class="flip-card-back">
      <h1>Hey!<hr></h1>
        <p>books must be relevant</p>
      <p>Do share with your nearby peoples so they reach up you faster </p>
      <a href="https://forms.gle/jHn8eSekZt84pF4F7"><button class="btn btn-info">Upload</button></a>
    </div>
  </div>
</div>
 </div>
               </div>
               </div>




<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5f7e057ce03c971f"></script>


</section>





          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>