<?php
$uname = $_POST['uname'];
$uemail = $_POST['uemail'];

$upass = $_POST['upass'];


$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "insert into user_registration (uname, uemail,upass)
  VALUES ('$uname', '$uemail', '$upass ')";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "New record created successfully";
  header("location:log.php");
  session_destory();
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>