<?php
include 'Head_Foot/header.html'; 
?>
<!DOCTYPE>
<html lang="en" dir="ltr">
<head>
<style>
body{
background:url(pics/audiobook.png) ;
background-size:cover;
}

h3{text-decoration:overline; font-family:'tangerine',serif;
text-shadow: 4px 4px 4px black;}

.cbox{
background-color:#8b62c7;
border-radius:15px;
margin:20px;
padding:20py;
}
.ctn{
height:350px;
background-color:#fff;
}
</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-compatible" content="ie=edge">
<meta name="robots" content="index,follow">
<meta name="keywords" content="AUDIOBOOK,AUDIOBOOK FREE,AUDIOBOOK FOR COMPETITIVE EXAMS,AUDIOBOOK FOR FREE,AUDIOBOOK IN HINDI">
<link rel='stylesheet' type='text/css' media='screen' href='css\bootstrap.min.css'>
<title>AudioBook||mystudyguru</title>
</head>

<div style=" background:#8b62c7;">
<marquee behavior="alternate" direction="left" scrollamount="10" >
<h1  style= "font-family: 'Galada', cursive;" class="text-white"><u>AudioBook</u></h1></marquee></div><br/><br/>
<div class="container-fluid">
<div class="row">
<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">History<hr/></h2>
<div class="container-responsive">
<div class="container ctn overflow-auto"><ul>
<li><a  href="audiobook/HISTORY/history of india.mp3">1.History of india.</a></li>
<li><a href="audiobook/HISTORY/ancient india history.mp3">2.Anicient history.</a></li>
<li><a href="audiobook/HISTORY/2.Pragetihasik kaal.mp3">3.Pragetihasik kaal</a></li>
<li><a href="audiobook/HISTORY/3.Sindhu sabhyata.mp3">4.Sindhu Sabhayati.</a></li>
<li><a href="audiobook/HISTORY/4.Vaidik sabhyata.mp3">5.Vedic sabhayata.</a></li>
<li><a href="audiobook/HISTORY/5.Mahajanpado ka uday">6.Rise of mohanjodaho.</a></li>
<li><a href="audiobook/HISTORY/6.Jain dharam.mp3">7.Jain dharam.</a></li>
<li><a href="audiobook/HISTORY/7.Bhaudh dharam.mp3">8.Bhaudh dharam.</a></li>
<li><a href="audiobook/HISTORY/8.Shaiw dharam.mp3">9.Shaiw dharam.</a></li>
<li><a href="audiobook/HISTORY/9.Vaishanaw dharam.mp3">10.Vaishanaw dharam.</a></li>
<li><a href="audiobook/HISTORY/10.Ishalam dharm.mp3">11.Islam dharam.</a></li>
<li><a href="audiobook/HISTORY/11.Ishai dharm.mp3">12.Ishai dharam.</a></li>
<li><a href="audiobook/HISTORY/12.Magadh rajay ka utkarsh.mp3">13.Magadh rajay ka utkarsh.</a></li>
<li><a href="audiobook/HISTORY/13.Sikandra.mp3">14.Sikandra.</a></li>
<li><a href="audiobook/HISTORY/14.Maurya samarjaya.mp3">15.Maurya Samarjaya.</a></li>
<li><a href="audiobook/HISTORY/15.Barahman samarajaya.mp3">16.Brahmin Samarjaya.</a></li>
<li><a href="audiobook/HISTORY/16.Bharat ke yawan rajaya.mp3">17.Bharat ke yawan rajaya.</a></li>
<li><a href="audiobook/HISTORY/17.Shak.mp3">18.Shak.</a></li>
<li><a href="audiobook/HISTORY/18.Kushan.mp3">19.Kushan.</a></li>
<li><a href="audiobook/HISTORY/19.Gupat samrajaya.mp3">20.Gupta Samarjaya.</a></li>
<li><a href="audiobook/HISTORY/20.Pushaybhuti wansh.mp3">21.Pushayabhuti vansh.</a></li>
<li><a href="audiobook/HISTORY/21.Dakshin bharat ke pramukh rajwansh.mp3">22.Dakshin bharat ke pramukh rajvansh.</a></li>
<li><a href="audiobook/HISTORY/22.Simawarti rajwanso ka abhyuday.mp3">23.Simawarti rajvansho ka abhiuday.</a></li>
<li><a href="audiobook/HISTORY/23.Rajput rajwanso ki utppati.mp3">24.Rajput rajvanso ki utppati.</a></li>
<li><a href="audiobook/HISTORY/24.Bharat par arbo ka aakarman.mp3">25.Bharat pe arab ka attack.</a></li>
<li><a href="audiobook/HISTORY/25.Muhmmad gajni.mp3">26.Mahmud Ghazni.</a></li>
<li><a href="audiobook/HISTORY/26.Muhmmad gauri.mp3">27.Muhammad ghori.</a></li>
<li><a href="audiobook/HISTORY/27.saltanat.mp3">28.Sultanat kaal.</a></li>
<li><a href="audiobook/HISTORY/28.Vijaynagar samrajaya.mp3">29.Vijaynagar samarajaya.</a></li>
<li><a href="audiobook/HISTORY/29.Bahmani rajaya.mp3">30.Bahmani rajaya.</a></li>
<li><a href="audiobook/HISTORY/30.Sawtantra prantiy rajaya.mp3">31.Swantra prantiy rajaya.</a></li>
<li><a href="audiobook/HISTORY/31.Sufi Andolan.mp3">32.Sufi Andolan.</a></li>
<li><a href="audiobook/HISTORY/32.Bhakti aandolan.mp3">33.Bhakti aandolan.</a></li>
<li><a href="audiobook/HISTORY/33.Mugal samrajya.mp3">34.Mugal samrajya.</a></li>
<li><a href="audiobook/HISTORY/34.Mugal sasan wyawstha.mp3">35.Mugal sasan wyawstha.</a></li>
<li><a href="audiobook/HISTORY/35.Maratho ka utkarsh.mp3">36.Maratho ka utkarsh.</a></li>
<li><a href="audiobook/HISTORY/36.Uttarkalin mugal samrath.mp3">37.Uttarkalin mugal samrath.</a></li>
<li><a href="audiobook/HISTORY/37.Bharat me yuropiy wyapari com. Ka agm.mp3">38.Swantra prantiy rajaya.</a></li>
<li><a href="audiobook/HISTORY/38.Bangal par angrejo ka aadhipatya.mp3">39.Swantra prantiy rajaya.</a></li>
<li><a href="audiobook/HISTORY/39.Angrejo ke maisur se sambandhan.mp3">40.Angrejo ke maisur se sambandhan.</a></li>
<li><a href="audiobook/HISTORY/40.Sikkh and angrej .mp3">41.Sikkh and angrej .</a></li>
<li><a href="audiobook/HISTORY/41.Company ke adhin gawrnar janral.mp3">42.Company ke adhin gawrnar janral.</a></li>
<li><a href="audiobook/HISTORY/42.Angreji sasan ke virudh imptnt. Vidroh.mp3">43.Angreji sasan ke virudh imptnt. Vidroh.</a></li>
<li><a href="audiobook/HISTORY/43.1857 ki mahan kranti.mp3">44.1857 ki mahan kranti.</a></li>
<li><a href="audiobook/HISTORY/44.Bharat ka sawtantra sanghars imp.Tathy.mp3">45.Bharat ka sawtantra sanghars imp.Tathy.</a></li>
<li><a href="audiobook/HISTORY/45.1857 ki mahan kranti.mp3">46.1857 ki mahan kranti.</a></li>
<li><a href="audiobook/HISTORY/45.Bharatiy rastriy andolan impt.sngathan.mp3">47.Bharatiy rastriy andolan impt.sngathan</a></li>
<li><a href="audiobook/HISTORY/46.Bhartiy rastriy andolan ke impt.Ghatna.mp3">48.Bhartiy rastriy andolan ke impt.Ghatna.</a></li>
<li><a href="audiobook/HISTORY/47.Bharat ke mahan sahid.mp3">49.Bharat ke mahan sahid.</a></li>
<li><a href="audiobook/HISTORY/48.Bhartiy sawntrata andolan ke impt.Nare.mp3">50.Bhartiy sawntrata andolan ke impt.Nare.</a></li>
<li><a href="audiobook/HISTORY/49.Sawtntrata andoln k impt.Ptr ptrika bk.mp3">51.Sawtntrata andoln k impt.Ptr ptrika bk.</a></li>
<li><a href="audiobook/HISTORY/50.Upadhi,praptkarta and data.mp3">52.Upadhi,praptkarta and data.</a></li>
<li><a href="audiobook/HISTORY/51.Congresh adhiweshan ; kab aur kaha.mp3">53.Congresh adhiweshan ; kab aur kaha.</a></li>
<li><a href="audiobook/HISTORY/52.Bharat ki etihasik ladayiya.mp3">54.Bharat ki etihasik ladayiya.</a></li>
<li><a href="audiobook/HISTORY/53.Prmukh rajwans sansthapak & rajdhani.mp3">55.Prmukh rajwans sansthapak & rajdhani.</a></li>
<li><a href="audiobook/HISTORY/54.Samajik sudhar adhiniyam.mp3">56.Samajik sudhar adhiniyam.</a></li>


</ul></div></div>
</div>
<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">Economics<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><a href="audiobook/ECONOMICS/economics.mp3">1.Economics.</a></li>
<li><a href="audiobook/ECONOMICS/importance of economics.mp3">2.Importance of economics.</a></li>
<li><a href="audiobook/ECONOMICS/economic planning.mp3">3.Economic planning.</a></li>
<li><a href="audiobook/ECONOMICS/economics facts.mp3">4.Economics facts.</a></li>
<li><a href="audiobook/ECONOMICS/finance org in eco.mp3">5.finance org in eco.</a></li>
<li><a href="audiobook/ECONOMICS/bussiness role in eco.mp3">6.Bussiness role in eco.</a></li>
<li><a href="audiobook/ECONOMICS/agriculture eco.mp3">7.Agriculture eco.</a></li>
<li><a href="audiobook/ECONOMICS/industriilization.mp3">8.Industriilization.</a></li>
<li><a href="audiobook/ECONOMICS/rastriy aay.mp3">9.Rastriy aay.</a></li>
<li><a href="audiobook/ECONOMICS/gdp in eco.mp3">10.Gdp in eco.</a></li>
</ul></div>
</div>
<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">Science<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><h5>Physics</h5><a href="audiobook/SCIENCE/phy/00.physics.mp3">Introduction Physics.</a></li>
<li><a href="audiobook/SCIENCE/phy/01.Unite.mp3">1.Units.</a></li>
<li><a href="audiobook/SCIENCE/phy/02.Motion.mp3">2.Motion.</a></li>
<li><a href="audiobook/SCIENCE/phy/03.Work Energy & Power.mp3">3.Work Energy & Power.</a></li>
<li><a href="audiobook/SCIENCE/phy/04.Gravation.mp3">4.Gravation.</a></li>
<li><a href="audiobook/SCIENCE/phy/05.Pressure.mp3">5.Pressure.</a></li>
<li><a href="audiobook/SCIENCE/phy/06.Flotation.mp3">6.Flotation.</a></li>
<li><a href="audiobook/SCIENCE/phy/07.Surface Tantion.mp3">7.Surface Tantion.</a></li>
<li><a href="audiobook/SCIENCE/phy/08.Viscosity.mp3">8.Viscosity.</a></li>
<li><a href="audiobook/SCIENCE/phy/09.Elastisity.mp3">9.Elastisity.</a></li>
<li><a href="audiobook/SCIENCE/phy/10.Simple Harmonic Motion.mp3">10.Simple Harmonic Motion.</a></li>
<li><a href="audiobook/SCIENCE/phy/11.Wave.mp3">11.Wave.</a></li>
<li><a href="audiobook/SCIENCE/phy/12.Sound wave.mp3">12.Sound wave.</a></li>
<li><a href="audiobook/SCIENCE/phy/13.Heat.mp3">13.Heat.</a></li>
<li><a href="audiobook/SCIENCE/phy/14.Light.mp3">14.Light.</a></li>
<li><a href="audiobook/SCIENCE/phy/15.Static Electrocity.mp3">15.Static Electrocity.</a></li>
<li><a href="audiobook/SCIENCE/phy/16.Current Electrocity.mp3">16.Current Electrocity.</a></li>b
<li><a href="audiobook/SCIENCE/phy/18.Atomic physics.mp3">18.Atomic physics.</a></li>
<li><a href="audiobook/SCIENCE/phy/19.Radio Activity.mp3">19.Radio Activity.</a></li>
<li><a href="audiobook/SCIENCE/phy/20.Nuclear fision & fision.mp3">20.Nuclear fision & fision.</a></li>
<li><a href="audiobook/SCIENCE/phy/21.Universe.mp3">21.Universe.</a></li>
<li><a href="audiobook/SCIENCE/phy/22.Scietific Istrument.mp3">22.Scietific Istrument.</a></li>
<li><a href="audiobook/SCIENCE/phy/23.Different mecines.mp3">23.Different mecines.</a></li><br>
<li><h5>Chemistry</h5><a href="AudioBook/SCIENCE/chem/00.Chemistry.mp3">Introduction Chemistry.</a></li>
<li><a href="audiobook/SCIENCE/chem/01.Matter & His Nature.mp3">1.Matter & His Nature.</a></li>
<li><a href="audiobook/SCIENCE/chem/03.Behavour of Gases.mp3">2.Behavour of Gases.</a></li>
<li><a href="audiobook/SCIENCE/chem/04.Periodic classification of elements.mp3">3.Periodic classification of elements.</a></li>
<li><a href="audiobook/SCIENCE/chem/05.Chemical Bonding.mp3">4.Chemical Bonding.</a></li>
<li><a href="audiobook/SCIENCE/chem/06.Oxidation & Redaction.mp3">5.Oxidation & Redaction.</a></li>
<li><a href="audiobook/SCIENCE/chem/07.Acid Base & Salt.mp3">6.Acid Base & Salt.</a></li>
<li><a href="audiobook/SCIENCE/chem/08.Solution.mp3">7.Solution.</a></li>
<li><a href="audiobook/SCIENCE/chem/09.Carbon & Its Coumpound.mp3">8.Carbon & Its Coumpound.</a></li>
<li><a href="audiobook/SCIENCE/chem/10.Fuels.mp3">9.Fuels.</a></li>
<li><a href="audiobook/SCIENCE/chem/11.Metals.mp3">10.Metals.</a></li>
<li><a href="audiobook/SCIENCE/chem/12.Non-metals.mp3">11.Non-metals.</a></li>
<li><a href="audiobook/SCIENCE/chem/13.Man made matarial.mp3">12.Man made matarial.</a></li>
<li><a href="audiobook/SCIENCE/chem/14.Catalysis.mp3">13.Catalysis.</a></li>
</ul></div>
</div>


<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">Indian Polity and Constitution<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><a href="audiobook/polity and constitution/01BHARTIYA.Sanmvidan,ka,itiash.~1.mp3">1.BHARTIYA Samvidhan ka itiash.</a></li>
<li><a href="audiobook/polity and constitution/02.bhartiy sawindhan shabha.mp3">2.Bhartiya samidhan shabha.</a></li>
<li><a href="audiobook/polity and constitution/03BHAR~1.mp3">3.BHARTIYA.</a></li>
<li><a href="audiobook/polity and constitution/04.bhartiy sawindhan ke videsi shrot.mp3">4.Bhartiya samvidhan ke videsi shrotra.</a></li>
<li><a href="audiobook/polity and constitution/05.bhartiy sawindhan ki anusuchi.mp3">5.Bhartiya samvidhan ki anusuchi.</a></lia
<li><a href="audiobook/polity and constitution/06.desi riyasto ka bharat me wilay..mp3">6.Desi riyasto ka bharat me wilay..</a></li>
<li><a href="audiobook/polity and constitution/07.sangh aur uska rajya kshetra.mp3">7.Sangh aur uska rajya kshetra.</a></li>
<li><a href="audiobook/polity and constitution/08.rajyon ka punargathan.mp3">8.Rajyon ka punargathan.</a></li>
<li><a href="audiobook/polity and constitution/09.bhartiy sawindhan ke prmukh bhag.mp3">9.Bhartiya samvidhan ke pramukh bhag.</a></li>
<li><a href="audiobook/polity and constitution/10.bhartiy nagrikta.mp3">10.Bhartiya nagrikta.</a></li>
<li><a href="audiobook/polity and constitution/10.wiwidh tathay.mp3">11.Viwidh tathay.</a></li>
<li><a href="audiobook/polity and constitution/11.maulik adhikar.mp3">12.Maulik adhikar.</a></li>
<li><a href="audiobook/polity and constitution/12.rajya ke niti nirdesak sidhdhanth.mp3">13.Rajya ke niti nirdesak sidhdhanth.</a></li>
<li><a href="audiobook/polity and constitution/13.maulik kartvya.mp3">14.Maulik kartvya.</a></li>
<li><a href="audiobook/polity and constitution/14.sanghiy karypalila.mp3">15.Sanghiya karypalila.</a></li>
<li><a href="audiobook/polity and constitution/15.sanghiy sansadiy.mp3">16.Sanghiya sansadiye.</a></li>
<li><a href="audiobook/polity and constitution/16.bharat ki sanchit nidhiya.mp3">17.Bharat ki sanchit nidhiya.</a></li>
<li><a href="audiobook/polity and constitution/17.bharat ki aakasmikata nidhi.mp3">18.Bharat ki aakasmikata nidhi.</a></li>
<li><a href="audiobook/polity and constitution/19BHAR~1.mp3">BHarat.</a></li>
<li><a href="audiobook/polity and constitution/20.sawindhan me sansodhan.mp3">20.Samvindhan me sansodhan.</a></li>
<li><a href="audiobook/polity and constitution/21.nyaypalika.mp3">21.Nyaypalika.</a></li>
<li><a href="audiobook/polity and constitution/22.rajya ki karypalika.mp3">22.Rajya ki karypalika.</a></li>
<li><a href="audiobook/polity and constitution/24.kendra rajya sambandh.mp3">23.Kendra rajya sambandh.</a></li>
<li><a href="audiobook/polity and constitution/25.antrajaya parishad.mp3">24.Antrajaya parishad.</a></li>
<li><a href="audiobook/polity and constitution/26.yojna aayog.mp3">25.Yojna aayog.</a></li>
<li><a href="audiobook/polity and constitution/27.rastriy vikas parishad.mp3">26.Rastriya vikas parishad.</a></li>
<li><a href="audiobook/polity and constitution/28.witt aayog.mp3">27.Witt aayog.</a></li>
<li><a href="audiobook/polity and constitution/29.lok sewa aayog.mp3">28.Lok sewa aayog.</a></li>
<li><a href="audiobook/polity and constitution/30.nirwachan aayog.mp3">29.Nirwachan aayog.</a></li>
<li><a href="audiobook/polity and constitution/32.rajbhasha.mp3">30.Rajbhasha.</a></li>
<li><a href="audiobook/polity and constitution/33.aapat upbandh.mp3">31.Aapat upbandh.</a></li>
<li><a href="audiobook/polity and constitution/34.bharat ke rastriy chinh.mp3">32.Bharat ke rastriy chinh.</a></li>
<li><a href="audiobook/polity and constitution/35.sansad ki wittiy samitiya.mp3">33.Sansad ki wittiy samitiya.</a></li>
<li><a href="audiobook/polity and constitution/36.panchayti rajya.mp3">34.Panchayti rajya.</a></li>
<li><a href="audiobook/polity and constitution/37.mahtaw shabdawali.mp3">35.Mahtaw shabdawali.</a></li>
<li><a href="audiobook/polity and constitution/38.sawidhan ke khuch Annuchche.mp3">36.Sawidhan ke khuch Annuchche.</a></li>
</ul></div>
</div>

<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">Geography<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><a href="audiobook/geography/00.geography.mp3">Introduction geography.</a></li>
<li><a href="audiobook/geography/01.brahmand.mp3">1.Brahmand.</a></li>
<li><a href="audiobook/geography/02.shaurmandal.mp3">2.Shaurmandal.</a></li>
<li><a href="audiobook/geography/03.earth aur unka shauryik sambandh.mp3">3.Earth aur unka shauryik sambandh.</a></li>
<li><a href="audiobook/geography/04.earth ki antrik sanrachana.mp3">4.Earth ki antrik sanrachana.</a></li>
<li><a href="audiobook/geography/05.sthalmandal.mp3">5.Sthalmandal.</a></li>
<li><a href="audiobook/geography/06.mahaduip.mp3">6.Mahaduip.</a></li>
<li><a href="audiobook/geography/07.jalmandal.mp3">7.Jal mandal.</a></li>
<li><a href="audiobook/geography/08.mahasagriy jaldharaye.mp3">8.Mahasagriya jal dharaye.</a></li>
<li><a href="audiobook/geography/09.wayumandal.mp3">9.Wayu mandal.</a></li>
<li><a href="audiobook/geography/10.world ke prmukh fasle & utpadak desh.mp3">10.World ke prmukh fasle & utpadak desh.</a></li>
<li><a href="audiobook/geography/11.world ke prmukh khanij & utpadak desh.mp3">11.World ke prmukh khanij & utpadak desh.</a></li>
<li><a href="audiobook/geography/12.world ke winirman udhaug.mp3">12.World ke winirman udhaug.</a></li>
<li><a href="audiobook/geography/13.world ke prmukh audogik nagar.mp3">13.World ke prmukh audogik nagar.</a></li>
<li><a href="audiobook/geography/14.world ki prmukh vanaspati.mp3">14.World ki prmukh vanaspati.</a></li>
<li><a href="audiobook/geography/15.world ki prmukh janjatiya.mp3">15.World ki prmukh janjatiya.</a></li>
<li><a href="audiobook/geography/16.kabilayi manwo ke prmukh aawas.mp3">16.Kabilayi manwo ke prmukh aawas.</a></li>
<li><a href="audiobook/geography/17.world ke prmukh bhaugolik upnam.mp3">17.World ke prmukh bhaugolik upnam.</a></li>
<li><a href="audiobook/geography/18.world ke prsiddh sthan..mp3">18.World ke prsiddh sthan..</a></li>
<li><a href="audiobook/geography/19.world ke prmukh bhaugolik khojen.mp3">19.World ke prmukh bhaugolik khojen.</a></li>
<li><a href="audiobook/geography/20.world ke mahasagar.mp3">20.World ke mahasagar.</a></li>
<li><a href="audiobook/geography/21.world ki prmukh nahre.mp3">21.World ki prmukh nahre.</a></li>
<li><a href="audiobook/geography/22.world ki prmukh jalsandhiya.mp3">22.World ki prmukh jalsandhiya.</a></li>
<li><a href="audiobook/geography/23.world ke prmukh jaladdamrumadhy.mp3">23.World ke prmukh jaladdamrumadhy.</a></li>
<li><a href="audiobook/geography/24.world ki prmukh nadiya.mp3">24.World ki prmukh nadiya.</a></li>
<li><a href="audiobook/geography/25.nadiyo ke kinare base world ke Nagar.mp3">25.Nadiyo ke kinare base world ke Nagar.</a></li>
<li><a href="audiobook/geography/26.world ke prmukh jalprapat.mp3">26.World ke prmukh jalprapat.</a></li>
<li><a href="audiobook/geography/27.world ke prmukh jheele.mp3">27.World ke prmukh jheele.</a></li>
<li><a href="audiobook/geography/28.world ke prmukh prwat sikhar.mp3">28.World ke prmukh prwat sikhar.</a></li>
<li><a href="audiobook/geography/29.world ke prmukh diup.mp3">29.World ke prmukh diup.</a></li>
<li><a href="audiobook/geography/30.world ke prmukh pathar.mp3">30.World ke prmukh pathar.</a></li>
<li><a href="audiobook/geography/31.world ke prumkh registan.mp3">31.World ke prumkh registan.</a></li>
<li><a href="audiobook/geography/32.world ke desh rajdhani & mudra.mp3">32.World ke desh rajdhani & mudra.</a></li>
<li><a href="audiobook/geography/33.world ke bhu-aawesthit desh.mp3">33.World ke bhu-aawesthit desh.</a></li>
</ul></div>
</div>

<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">G.K(imp)<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><a href="audiobook/gk/1.Gk.mp3">1.G.k.</a></li>
<li><a href="audiobook/gk/2.bharat ka bhautik swarop.mp3">2.Bharat ka bhautik swarop.</a></li>
<li><a href="audiobook/gk/3.asian games.mp3">3.Asian games.</a></li>
<li><a href="audiobook/gk/04. Highest big tall and high in India.mp3">4.Highest big tall and high in India.</a></li>
<li><a href="audiobook/gk/05. First in world.mp3">5. First in world.</a></li>
<li><a href="audiobook/gk/06.Highest big small tall & high in world.mp3">6.Highest big small tall & high in world.</a></li>
<li><a href="audiobook/gk/07. National smarak of imporatnt country.mp3">7.National smarak of imporatnt country.</a></li>
<li><a href="audiobook/gk/08. National chinh(prtik) of impt.Country.mp3">8.National chinh(prtik) of impt.Country.</a></li>
<li><a href="audiobook/gk/09. International lines.mp3">09.International border lines.</a></li>
<li><a href="audiobook/gk/10. Manchitra lines.mp3">10.Manchitra lines.</a></li>
<li><a href="audiobook/gk/11. News agency of impt. Country..mp3">11.News agency of imp. Country..</a></li>
<li><a href="audiobook/gk/12. Goverment dastawej of impt. Country.mp3">12. Government documentary of imp. Country.</a></li>
<li><a href="audiobook/gk/13. Political dal of impt. Country.mp3">13.Political dal of imp. Country.</a></li>
<li><a href="audiobook/gk/14. Important chinh and pratik.mp3">14.Important chinh and pratik.</a></li>
<li><a href="audiobook/gk/15. National animal of impt. Country.mp3">15.National animal of imp. Country.</a></li>
<li><a href="audiobook/gk/16. World international wiman sewayen..mp3">16.World international wimaan sewayen..</a></li>
<li><a href="audiobook/gk/17. World impt. Newspaper and prkasn plce.mp3">17.World imp. Newspaper and prkasn plce.</a></li>
<li><a href="audiobook/gk/18. World impt. Guptchar sanstha..mp3">18.World imp. Guptchar sanstha..</a></li>
<li><a href="audiobook/gk/19. Different country parliyament..mp3">19.Different country parliament..</a></li>
<li><a href="audiobook/gk/20. Unatid nation organisation.mp3">20.United nation organisation.</a></li>
<li><a href="audiobook/gk/21. World other important organisation.mp3">21.World other important organisation.</a></li>
<li><a href="audiobook/gk/22. World impt. Org. and his headquarter.mp3">22.World imp. Org. and his headquarter.</a></li>
<li><a href="audiobook/gk/23. UNO International dasak.mp3">23.UNO International dasak.</a></li>
<li><a href="audiobook/gk/24. UNO International ydars.mp3">24.UNO International ydars.</a></li>
<li><a href="audiobook/gk/25. UNO International weak.mp3">25.UNO International weak.</a></li>
<li><a href="audiobook/gk/26. Impt. National and International days.mp3">26.Impt. National and International days.</a></li>
<li><a href="audiobook/gk/27. Indian impt. Turist place.mp3">27.Indian imp. Tourist place.</a></li>
<li><a href="audiobook/gk/28. Indian prtiraksha.mp3">28.Indian prtiraksha.</a></li>
<li><a href="audiobook/gk/29. Indian sainik traning sansthane.mp3">29.Indian sainik traning sansthane.</a></li>
<li><a href="audiobook/gk/30. Bharat ki aantrik suraksha.mp3">30.Bharat ki aantrik suraksha.</a></li>
<li><a href="audiobook/gk/31. Prmukh rajyo ke sthapna diwas.mp3">31.Prmukh rajyo ke sthapna diwas.</a></li>
<li><a href="audiobook/gk/32. Bharat ke prmukh sodh sansthan.mp3">32 Bharat ke prmukh sodh sansthan.</a></li>
<li><a href="audiobook/gk/33. Bharat ke prmukh wadhyantr&unke wadak.mp3">33.Bharat ke prmukh wadhyantr&unke wadak.</a></li>
<li><a href="audiobook/gk/34. Impt. dance & his kalakar..mp3">34.Imp. dance & his kalakar..</a></li>
<li><a href="audiobook/gk/35. Bharat ke sanskritik sasthan& sthapna.mp3">35.Bharat ke sanskritik sasthan& sthapna.</a></li>
<li><a href="audiobook/gk/36. Rajyo se sambandhit loknirity.mp3">36.Rajyo se sambandhit loknirity.</a></li>
<li><a href="audiobook/gk/37. Samadhi place.mp3">37.Samadhi place.</a></li>
<li><a href="audiobook/gk/38. Prmukh wayktee ke lokpriy upnaam.mp3">38.Prmukh wayktee ke lokpriy upnaam.</a></li>
<li><a href="audiobook/gk/39. Prmukh wayktiyo se sambandhit place.mp3">39.Prmukh wayktiyo se sambandhit place.</a></li>
<li><a href="audiobook/gk/40. Mahan karyo se sambandhit wayktee.mp3">40.Mahan karyo se sambandhit wayktee.</a></li>
<li><a href="audiobook/gk/41. Prmukh puraskar and samman.mp3">41.Prmukh puraskar and samman.</a></li>
<li><a href="audiobook/gk/42. National prize.mp3">42.National prize.</a></li>
<li><a href="audiobook/gk/43. Bharat ratna se sammanit wayktee.mp3">43.Bharat ratna se sammanit wayktee.</a></li>
<li><a href="audiobook/gk/44. Gyanpeet prize se sammanit sahitykar..mp3">44.Gyanpeet prize se sammanit sahitykar..</a></li>
<li><a href="audiobook/gk/45. Dada saheb falke prize pane wale wykt.mp3">45.Dada saheb falke prize pane wale wykt.</a></li>
<li><a href="audiobook/gk/46. Impt. Writer and his book..mp3">46.Imp. Writer and his book..</a></li>
</ul></div>
</div>

<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">Computer<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><a href="audiobook/COMPUTER/computer.mp3">Basic of computer</a></li>
<li><a href="audiobook/COMPUTER/parts of computer.mp3">Parts of computer</a></li>
<li><a href="audiobook/COMPUTER/facts on computer.mp3">Facts on computer</a></li>
<li><a href="audiobook/COMPUTER/computer related.mp3">Full Forms related to computer</a></li>
</ul></div>
</div>

<div class="col-11 col-lg-5 container cbox border border-primary"><h2 align="center" class="text-white" style="font-family: 'Galada', cursive;">Facts about India<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li><a href="audiobook/indian fact/bhara ki sichayi.mp3">1.Bhara ki sichayi.</a></li>
<li><a href="audiobook/indian fact/bharat ka agricuturer.mp3">2.Bharat ka agricuturer.</a></li>
<li><a href="audiobook/indian fact/bharat ka bhautik.mp3">3.Bharat ka bhautik.</a></li>
<li><a href="audiobook/indian fact/bharat ka uddaug.mp3">4.Bharat ka uddaug.</a></li>
<li><a href="audiobook/indian fact/bharat ke khaij sansadhan.mp3">5.Bharat ke khaij sansadhan.</a></li>
<li><a href="audiobook/indian fact/bharat ke prmukh nadi.mp3">6.Bharat ke prmukh nadi.</a></li>
<li><a href="audiobook/indian fact/bharat ki jalvayu.mp3">7.Bharat ki jalvayu.</a></li>
<li><a href="audiobook/indian fact/bharat ki jangnna 2001.mp3">8.Bharat ki jangnna 2001.</a></li>
<li><a href="audiobook/indian fact/bharat ki mitti.mp3">9.Bharat ki mitti.</a></li>
<li><a href="audiobook/indian fact/bharat ki nadiya.mp3">10.Bharat ki nadiya.</a></li>
<li><a href="audiobook/indian fact/bharat ki prmukh jeail parpat.mp3">11.Bharat ki prmukh jeail parpat.</a></li>
<li><a href="audiobook/indian fact/bharat ki prmukh jeail.mp3">12.Bharat ki prmukh jeail.</a></li>
<li><a href="audiobook/indian fact/bharat me priwahan.mp3">13.Bharat me priwahan.</a></li>
<li><a href="audiobook/indian fact/samanaya jankari.mp3">14.Bamanaya jankari.</a></li>
<li><a href="audiobook/indian fact/15.nadiyo ke kinare base prmukh nagar.mp3">15.Nadiyo ke kinare base prmukh nagar.</a></li>
<li><a href="audiobook/indian fact/16.bharat ke parwatiy nagar.mp3">16.Bharat ke parwatiy nagar.</a></li>
<li><a href="audiobook/indian fact/17.bharat ke prmukh jeev abhyarany &uddan.mp3">17.Bharat ke prmukh jeev abhyarany &uddan.</a></li>
<li><a href="audiobook/indian fact/18.bharat ke prmukh bhaugolik upnam.mp3">18.Bharat ke prmukh bhaugolik upnam.</a></li>
<li><a href="audiobook/indian fact/19.bhartiy rajya & rajdhani.mp3">19.Bhartiy rajya & rajdhani.</a></li>
<li><a href="audiobook/indian fact/20.bhartiy janjatiya.mp3">20.Bhartiy janjatiya.</a></li>

</ul></div>
</div>
</div>
</div>


<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5f7e057ce03c971f"></script>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>