<?php
include 'Head_Foot/header.html'; 
?>
<!DOCTYPE html>
<!-- saved from url=(0091)file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html -->
<html lang="hi" xml:lang="hi">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Required meta tags -->
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="robots" content="index,follow"/>
  <meta name="keywords" content="kids learning,kidzone,kindergaten learning,abacus for kids,vedic maths for kids,games for kids">
  <meta name="description" content="kidzone will surely makes your kids a genius with abacus and vedic maths learning">

    <!-- Bootstrap CSS -->
      <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<link rel='stylesheet' type='text/css' media='screen' href='css\bootstrap.min.css'>
       <title>Crazy KID-ZONE learn with fun</title>


  <style type="text/css">





    body{
  background-color: #F8EBFF;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
 
.height{
  min-height:60vh;
}
.paralax-background{
  background-color: #80ffdb;

}
 
.height-80{
  min-height: 80vh;
}
.cbox{
background-color:#ff3300;
border-radius:15px;
margin:20px;
padding:20py;
}
.ctn{
height:350px;
background-color:#fff;
}
#main-content{
  background-color: #F8EBFF;
}
 
.headings{
  background-color: #8b62c7;
}
  </style>

  </head>
  <body>
     
  <!--MAIN SECTION -->
  <section id="filler" class="">
    
    <img src="images/kid/kid-zone-1.png" alt='KID ZONE' class='img-fluid '>
  </section>
    </div>
  </section>
  <!--END OF AUDIO BOOK SECTION -->

  <!--CONTENT -->
  <section>
    <div class="container-fluid">
      <!--TITLE -->
      <div class="row color-section pt-2 m-0">
        <div class="col text-white ">
          <h1 class="display-5 text-center font" style="font-family: Georgia, serif;">LEARN WITH FUN</h1>
        </div>
      </div>
	    <center> <p style="font-size:100px">&#128522;</p></center>
      <!--TITLE -->
      <!--CONTENT -->
      <div class="container content ban1" id="welcome" style="background-color:#00cc92;">
    <h2 style="font-family:Georgia;" align="center">Play Games</h2>
<a  style="text-decoration:none" href="Games/flappy game.html"><center><button type="button"  class="btn btn-sm btn-light">Flappy Bird Game</button></a>
<a href="Games/ping-pong game.html"><button type="button"  class="btn btn-sm btn-light">Ping-Pong Game</button></a>
	<a href="Games/snake game.html"><button type="button"  class="btn btn-sm btn-light">Snake Game</button></a>
		<a href="Games/tic-toc game.html"><button type="button"  class="btn btn-sm btn-light">Tic-Tac-Toe</button></a></center>
  </div>
      <div class="row">
        <div class="col-sm-6 ">
          <div class="container-responsive py-5 ">
            <div class="ctn container overflow-auto bg-light" id="main-content">

              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>English</u></h1>
                </div>

              </div>

              <ul class="pt-2">
                <li>Alphabets   <a href="pdfs/kid/Alphabets A a B b C c D d E e F f Gg H h I i J j K k L l M m N n O o P p Q q R r S s T t U u V v W w Yy Z z.pdf" class="ml-2">Click here</a></li>
                <li>Animals    <a href="pdfs/kid/ANIMALS-NAME.pdf" class="ml-2">Click here</a></li>
                <li>Days Names  <a href="pdfs/kid/DAYS-NAME.pdf" class="ml-2">Click here</a></li>
                <li>Fruits   <a href="pdfs/kid/Fruits-Name.pdf" class="ml-2">Click here</a></li>
                <li>Months Names   <a href="pdfs/kid/Months-Name .pdf" class="ml-2">Click here</a></li>
                <li>Seasons   <a href="pdfs/kid/Seasons-Name.pdf" class="ml-2">Click here</a></li>
                <li>Insects <a href="#" class="ml-2">Click here</a></li>
                <li>Body Parts   <a href="#" class="ml-2">Click here</a></li>
                <li>Birds  <a href="#" class="ml-2">Click here</a></li>
                <li>Vegetable  <a href="#" class="ml-2">Click here</a></li>
                <li>Tools  <a href="#" class="ml-2">Click here</a></li>
                <li>Playing Things <a href="#" class="ml-2">Click here</a></li>
                <li>Professions <a href="#" class="ml-2">Click here</a></li>
                <li>School Things  <a href="#" class="ml-2">Click here</a></li>
                <li>My Family <a href="#" class="ml-2">Click here</a></li>
                <li>My Introduction <a href="#" class="ml-2">Click here</a></li>
                 <li>Say HI... <a href="#" class="ml-2">Click here</a></li>
                <li>Pronouns<a href="#" class="ml-2">Click here</a></li>
                <li>Helping Verbs<a href="#" class="ml-2">Click here</a></li>
                <li>Use of This/That <a href="#" class="ml-2">Click here</a></li>
                <li>Use of That/Those<a href="#" class="ml-2">Click here</a></li>
                 <li>Opposite Words <a href="#" class="ml-2">Click here</a></li>
                <li>Action Words<a href="#" class="ml-2">Click here</a></li>
                <li>Word Meanings<a href="#" class="ml-2">Click here</a></li>

                
              </ul>

            </div>
          </div>
        </div>
        
        <div class="col-sm-6">
          <div class="container-responsive py-5">
            <div class="ctn container overflow-auto bg-white" id="main-content">

              <!--TITLE -->
              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>Maths</u></h1>
                </div>

              </div>
              <!--TITLE -->
                <ul>
              
                <li>Numbers<a href="#"> Click here</a></li>
				<li>Numbers System<a href="#"> Click here</a></li>
                <li>Tables<a href="#" class="ml-2"> Click here</a></li>
                <li>Units<a href="#" class="ml-2"> Click here</a></li>
                <li>Shapes <a href="#" class="ml-2"> Click here</a></li>
                <li>Symbols <a href="#" class="ml-2"> Click here</a></li>
				<li>Addition <a href="#" class="ml-2"> Click here</a></li>
                <li>Subtraction <a href="#" class="ml-2"> Click here</a></li>
                <li>Multiplication <a href="#" class="ml-2"> Click here</a></li>
                <li>Division <a href="#" class="ml-2"> Click here</a></li>
                <li>Powers<a href="#" class="ml-2"> Click here</a></li>
                <li>Square root <a href="#" class="ml-2"> Click here</a></li>
                <li>Cube root <a href="#" class="ml-2"> Click here</a></li>
                <li>Algebra <a href="#" class="ml-2"> Click here</a></li>
                <li>Percentage <a href="#" class="ml-2"> Click here</a></li>
                              </ul>

            </div>
          </div>
        </div>
        
      </div>
      <div class="row">
        <div class="col-sm-6 ">
          <div class="container-responsive py-5 ">
            <div class="ctn container overflow-auto bg-light" id="main-content">

              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center"><u>हिंदी</u></h1>
                </div>

              </div>

              <ul class="pt-2">
                <li>वर्णमाला<a href="#"> Click here</a></li>
				<li>दो अक्षर शब्द<a href="#"> Click here</a></li>
                <li>तीन अक्षर शब्द<a href="#" class="ml-2"> Click here</a></li>
                <li>बाक्य<a href="#" class="ml-2"> Click here</a></li>
				<li>व्याकरण<a href="#" class="ml-2"> Click here</a></li>
                <li>कहानिया<a href="#" class="ml-2"> Click here</a></li>
                <li>शब्दकोष<a href="#" class="ml-2"> Click here</a></li>
              </ul>

            </div>
          </div>
        </div>
        
        <div class="col-sm-6">
          <div class="container-responsive py-5">
            <div class="ctn container overflow-auto bg-white" id="main-content">

              <!--TITLE -->
              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>Science</u></h1>
                </div>

              </div>
              <!--TITLE -->
                <ul>
              
				<li>Solar planet <a href=" pdfs/kid/Solar-System/solar system.pdf">Click Here</a></li>
                <li>Our Solar System - grades K-3 <a href=" pdfs/kid/Solar-System/Our Solar System - grades K-3.pdf" class="ml-2"> Click here</a></li>
				<li>Our Solar System - grades 2-5 <a href=" pdfs/kid/Solar-System/Our Solar System - grades 2-5.pdf" class="ml-2"> Click here</a></li>
                <li>Human Body <a href="#" class="ml-2"> Click here</a></li>
                <li>Solid,Liquid,Gas <a href="#" class="ml-2"> Click here</a></li>
                <li>Food and Health <a href="#" class="ml-2"> Click here</a></li>
                <li>Natural Resources <a href="#" class="ml-2"> Click here</a></li>
                <li>Water <a href="#" class="ml-2"> Click here</a></li>
                <li>Be Safe <a href="#" class="ml-2"> Click here</a></li>
                <li>Food <a href="#" class="ml-2"> Click here</a></li>
                <li>Air <a href="#" class="ml-2"> Click here</a></li>
              </ul>

            </div>
          </div>
        </div>
        
      </div>
      <div class="row">
        <div class="col-sm-6 ">
          <div class="container-responsive py-5 ">
            <div class="ctn container overflow-auto bg-light" id="main-content">

              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>E.V.S</u></h1>
                </div>

              </div>

              <ul class="pt-2">
                <li>Good Habbits <a href="#" class="ml-2">Click here</a></li>
                <li>Our Environment <a href="#" class="ml-2">Click here</a></li>
                <li>Living & Non-living  <a href="#" class="ml-2">Click here</a></li>
                <li>Our senses <a href="#" class="ml-2">Click here</a></li>
                <li>Communications <a href="#" class="ml-2">Click here</a></li>
                <li>Audiobook-5    <a href="#" class="ml-2">Click here</a></li>
                <li>Audiobook-5    <a href="#" class="ml-2">Click here</a></li>
                <li>Audiobook-5    <a href="#" class="ml-2">Click here</a></li>
                <li>Audiobook-5    <a href="#" class="ml-2">Click here</a></li>
                <li>Audiobook-5    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                
                
              </ul>

            </div>
          </div>
        </div>
        
        <div class="col-sm-6">
          <div class="container-responsive py-5">
            <div class="ctn container overflow-auto bg-white" id="main-content">

              <!--TITLE -->
              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>G.K</u></h1>
                </div>

              </div>
              <!--TITLE -->
                <ul>
              
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                
                
              </ul>

            </div>
          </div>
        </div>
        
      </div>
    </div>
	
	<div class="row">
        <div class="col-sm-6 ">
          <div class="container-responsive py-5 ">
            <div class="ctn container overflow-auto bg-light" id="main-content">

              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>Abacus</u></h1>
                </div>

              </div>

              <ul class="pt-2">
                <li>Introduction <a href="#" class="ml-2">Click here</a></li>
                <li>Tut-1 <a href="#" class="ml-2">Click here</a></li>
                <li>Tut-2 <a href="#" class="ml-2">Click here</a></li>
                <li>Addition <a href="#" class="ml-2">Click here</a></li>
                <li>Subtraction <a href="#" class="ml-2">Click here</a></li>
                <li>Multiplication   <a href="#" class="ml-2">Click here</a></li>
                <li>Division <a href="#" class="ml-2">Click here</a></li>
                <li>Tricks   <a href="#" class="ml-2">Click here</a></li>
                
                
                
              </ul>

            </div>
          </div>
        </div>
        
        <div class="col-sm-6">
          <div class="container-responsive py-5">
            <div class="ctn container overflow-auto bg-white" id="main-content">

              <!--TITLE -->
              <div class="row color-section pt-2 m-2">
                <div class="col text-white ">
                  <h1 class="display-5 text-center font" style="font-family: Georgia, serif;"><u>Vedic Maths</u></h1>
                </div>

              </div>
              <!--TITLE -->
                <ul>
              
                <li>Tut-1 <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-2    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-3    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-4    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-5    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-6    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-7    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Tut-8   <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                       
                
              </ul>

            </div>
          </div>
        </div>
        
      </div>
    </div>
  </section>
 <!--AUDIO BOOK SECTION -->
  <section>
    <div class="container-fluid">
      <!--TITLE -->
      <div class="row color-section pt-2 mt-3">
        <div class="col text-white ">
          <h1 class="display-4 text-center font" style="font-family: Georgia, serif;"><u>AUDIO BOOKS</u></h1>
        </div>

      </div>
      <!--TITLE -->
      <!--CONTENT -->
      
      <div class="row">
        <div class="col-md-11 col-11">
          <div class="container-responsive py-5 ">
            <div class="ctn container overflow-auto bg-light" id="main-content">
                <ul>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                <li>Audiobook-1    <a href="file:///E:/web%20development/Website%20Development/bootstrap-4.5.0-dist/kid-zone-final.html#" class="ml-2">Click here</a></li>
                
              </ul>

            </div>
          </div>
        </div>
 
   
        
      </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
</body></html>
<?php
include 'Head_Foot/footer.html'; 
?>