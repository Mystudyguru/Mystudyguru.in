<?php
include 'Head_Foot/header.html';

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="index,follow">
        <meta name="keywords" content="time management tips,time managemt skills, time management strategy time management benefit">
        <meta name="description" content="Strategies for effective time management with tips from mystudyguru">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>TIPS AND TRICKS FOR TIME MANAGEMENT</title>
    <script>
         var data = document.getElementById('text') ;
        function submit(){
           
            console.log(data);
        }

    </script>
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 40vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: serif;
    font-size:20px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
       
       
       
       .height-40{
           min-height: 50vh;
       }
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
      

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            <div class="row">
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8"> 
                    <h1 class="text-light mt-4 ml-4  ">
                        “For each minute spent in organizing , an hour is earned”

                </h1>
                <p class="text-light mt-4 ml-4"> Time Management</p>
                </div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-light m-4"><h4>by Chesta Sagar -  21/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3">TIME MANAGEMENT?</h1>
                   <p class="paragraph"> <b> </b> Do you ever desire, there is ne'er enough time in whole day? Or as if you can’t realize, wherever did you spent your day? aren't these thoughts strikes you whereas getting ready for an exam?
                   </p>
                    
                    
                    
            
                    
                       <p class="paragraph"> While, pursuading your goal, time management is that the key to success. To crack any kind of examination, 
                           your beginning must be creating executing and corporal punishment the strategy. 
                           though the preparation is another vital task that must be accomplished. 
                           One who earns the control oer time, earns success.  
                        .</p>
                    
                    
                            <div class="container"  id="filler-1">
                                <div class="row height-60">
                                    <div class="col"> 
                                        <img src="images/blog/time-management-techniques.jpg" alt="time management techniques" class="img-fluid">
        
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mb-2 mt-3"> TIPS </h2>
                    <p class="paragraph"> <ul> 
                        <li class="paragraph">
                            Generate a sensible time-table<br>
Make a timetable that includes of daily possible targets. Don’t create a strict one. Remember, you would like to follow it daily. Hence, set a goal and check out to manage time in terms of day, week, and a month.

<br> <br> </li> 
                    <li class="paragraph"> Divide your information as per your time-table<br>
                        Here, you wish to divide your subjects in step with their weightage, time taken to review them and their issue. ne'er commit the error of keeping all the simpler topics for the Doomsday. As they're easier, try and cowl them as early as attainable. try and maintain a balance between simple and tough subjects. it's kindly suggested to divide lager 
                        topics into sub-topics then, learn them in components<br> <br></li>
                    <li class="paragraph"> Create notes<br>
                    Now, creating notes could appear a effortful work. But, whenever you study the chapter for the primary time, try and create notes because it can assist you throughout your revision time.
                    <br> <br></li>
                    <li class="paragraph">Take a Break!<br>
                        From long hours of study,one doesn’t mean continuous study. One ought to take tiny breaks whenever one feels that the potency has reduced. Remember, you wish to own a recent mind to grab things for a extended time. But yes, breaks mustn't be long enough that disturb your daily schedule.
                        <br> <br> </li> 
                    <li class="paragraph">sleep in gift<br>
                        Instead of coming up with concerning everything you're reaching to do when you succeed, it’s perpetually higher to think about this. Also, don’t waste time in considering the results and their implications on your future.Have confidence in yourself and tame your nervousness and stress level.
                        <br> <br></li>  
                    <li class="paragraph"> Arrange execution on the day of examination<br>
                    Finally, the day that you have been getting ready and arduous arrives. So, keep in mind time management should be followed while giving examination too. ne'er follow a selected question for too long. Also, read each question properly. Don’t be in a hurry to complete the examination that you just begin committing mistakes. Because, finally you won’t be judged for finishing the paper, rather you may be judged on the idea of your marks.
                    <br> <br> </li></ul>
                    
                </ul> </p> 
                        <div class="container"  id="filler-2">
                            <div class="row height-60">
                                <div class="col"> 
                                    <img src="images/blog/TIME-MANAGEMENT-TECHNIQUES.jpg" alt="TIME MANAGEMENT TECHNIQUES" class="img-fluid">
                                    
                                </div>
                            </div>
                        </div>
                
                      <h1 class="display-5 mt-5">Be Motivated</h1>
                      <p class="paragraph">Every minute counts when you are getting ready for any examination. confine mind that if you're unable to complete your course of study on time, then, insecurity and self-doubts can mechanically arise, creating you under-confident. Manage time with wisdom so you stay assured, determined, centered and relaxed throughout the examination preparation.


                      </p>

                </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col"> <h2 class="  display-5 mb-4"> </h2>
                    <p class="paragraph">

                        <div class="container mb-5"  id="filler-3">
                            <div class="row height-60">
                                <div class="col"> 
                                    <img src="images/blog/time-management-strategies.jpg" alt="time management strategies"class="img-fluid">
    
                                </div>
                            </div>
                        </div>
                         
                        
                        
                        
                        
                                <h2 class="  display-5 my-4"> </h2>
                                    <h2 class="  display-5 my-4">WORDS FROM AUTHOR! </h2>
                         
                        <h2 class="  display-5 my-4">   </h2>
                       
                         
                        
                        
                        </p>
                        <h1 class="display-5"> </h1>  
                        At last , competitive exams are nothing however a race, not simply against different competitors, however also against the clock. So, ace time management to extend your
                         productivity and win your goals .Learn to be the master of your minutes….GOOD LUCK!!!
                        
                        
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>
<?php
include 'bl/commententry.php';
?>


   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 





<?php
include 'bl/section.html';

?>
        
        
<?php
include 'bl/commentshow.php';

?>                 
         
    
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
      </body>
    </html>
<?php
include 'Head_Foot/footer.html';

?>