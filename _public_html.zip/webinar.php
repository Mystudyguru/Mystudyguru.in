<?php
include 'Head_Foot/header.html';

?>
<!doctype html>
<html>
<head>
<style>
.ctn{
height:700px;
background:linear-gradient(to bottom,#8b62c7 0%,#33ddff 100%);
	box-shadow: 5px 11px 35px 2px rgba(84, 104, 145, 1.84);
}
</style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>html-css-bootstrap-webinar|mystudyguru</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<center><img src="images/webinar.gif" class="img-fluid"></center>
<center>
<iframe class="container-fluid ctn col-md-11 col-12 overflow" src="https://docs.google.com/forms/d/e/1FAIpQLSdSrf9JiZznjNSCJvxXvB22LvSvscY0Ic4wsj7M1IM-DmEJXQ/viewform?embedded=true">Loading</iframe>
</center>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
</body>
</html>
<?php
include 'Head_Foot/footer.html';

?>