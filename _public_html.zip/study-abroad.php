<?php
include 'Head_Foot/header.html';

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="robots" content="index,follow">
<meta name="keywords" content="studying abroad high-school,studying abroad experience,studying abroad for free,how studying abroad from india,studying abroad colleges,studying abroad">
<meta name="description" content="how to study abroad for Indian students from scholarship, and in which college. ">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>studying abroad essay|studying abroad highschool|mystudyguru</title>
  
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 40vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: serif;
    font-size:20px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
       v 
      
     
      
       .height-40{
           min-height: 50vh;
       }
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
     
       

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            <div class="row">
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8"> 
                    <h1 class="text-light mt-4 ml-4  ">
                        Studying abroad-Still a dream?

                </h1>
                <p class="text-light mt-4 ml-4">DREAM!</p></div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-light m-4"><h4>by Chesta Sagar -  21/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3">WHO NOT WANTS TO STUDY ABROAD! </h1>
                   <p class="paragraph"> <b> </b>According to the QS World University Rankings, 
                    Republic of India is that the second country after China with highest variety of candidates 
                    for foreign education. Where as learning abroad may be a dream for several students,
                    it have been become a reality for several aspirants.<br> And once Republic of India holds 
                    this record of getting immense variety of scholars seeking foreign education, it's a clear
                     question that why students are opting learning overseas.
                   </p>
                    
                    
                    
            
                    
                      
                    
                    
                            <div class="container"  id="filler-1">
                                <div class="row height-60">
                                    <div class="col"> 
        
                                        <img src="images/blog/studying-abroad-still-a-dream.jpg" alt="studying abroad still a dream"class="img-fluid">
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mb-2 mt-3"> </h2>
                    <p class="paragraph"> Indian education system and therefore 
                        the admission criteria ar extremely competitive. Approx eight lakh 
                        students register for the Union Public Service Commission (UPSC)
                         Civil Services (Preliminary) examination per annum, of which, 
                         cream only cream qualify for the Main exam .To secure admission
                          in prestigious Indian institutes like IITs (Indian Institute of Technology),
                          IIMs(Indian Institute of Management),AIIMS(All Republic of India Institute 
                          Of Medical Sciences) etc aspirants had to face through a throat cutting competition.<br>
                           To surpass in these competitive exams, 
                           a student has got to place in an exceedingly ton of toil,
                            intelligence, intense study level and a decent level of preparation.<br> 
                            Not each student gets admission in such institutes, so, several bright minds of the country
                             register for learning abroad in countries like USA, UK, New Seeland
                            , North American country etc that supply wonderful education.

                     .</p>
                    <p class="paragraph"> Another reason is their admission criteria. A student with smart educational record, proficiency in West Germanic language (evaluated through exams like Sat, IELTS , TOEFL) and affirmative, enough budget will simply get admission in universities overseas.

                    </p> 
                        <div class="container"  id="filler-2">
                            <div class="row height-60">
                                <div class="col"> 
    
                                            <img src="images/blog/study-in-canada.jpg" alt="study-abroad-scholarship"class="img-fluid">

                                </div>
                            </div>
                        </div>
                
                      <h1 class="display-5 mt-5">Be Motivated</h1>
                      <p class="paragraph">In India, the well-known institutes principally supply degrees in STEM (Science, Technology, Engineering and Mathematics) etc as these are the roads additional cosmopolitan by .Now, each student has totally different dreams and aspirations. Courses like fashion planning, building management, film and direction, filming, animation etc are less valued or don't seem to be offered in our country. And if they're offered too, then, the Indian Universities don't give world category education in these areas .So, such aspirants usually go abroad to pursue their interest that provides a ocean of opportunities to decide on from.</p>

                </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col"> <h2 class="  display-5 mb-4"> </h2>
                    <p class="paragraph">

                        <div class="container mb-5"  id="filler-3">
                            <div class="row height-60">
                                <div class="col"> 
                                            <img src="images/blog/TIPS-AND-TRICKS-FOR-ABROAD-STUDY.jpg" alt="TIPS AND TRICKS FOR ABROAD STUDY" class="img-fluid">

    
                                </div>
                            </div>
                        </div>
                         
                        
                        
                        
                        
                                <h2 class="  display-5 my-4"> </h2>
                                Moreover, an international degree from a supposed university may be
                                 a feather additional to your cap. it's nice worth each in our country 
                                 likewise as in international market. It makes your resume stand out from
                                  the remainder. So, each penny invested with in seeking foreign education
                                   is worthwhile because it enhances your data, temperament and skills.<br>
                                   Students learning abroad get exposure to 
                                   {a totally different|a special|a unique|a distinct} 
                                   culture and bear a replacement and different learning method.<br>
                                    Being removed from their country brings them out of their temperature, 
                                    creating them additional freelance and accountable. They get opportunities to explore 
                                    the new surroundings, adapt themselves and thus, improve their temperament.
                                     Also, they get to fulfill new folks round the globe and grow their network.<br>
                                     So, altogether, learning abroad makes them a valuable plus for his or her country 
                                   likewise as for the planet.

                                 
                         
                        
                        
                        </p>
                        <h1 class="display-5">Words from Author!</h1>  
                        Hence, whether or not you are taking a road less travelled by or additional travelled by, if learning abroad is your childhood dream, then, you ought to modification it into reality. Education isn't the educational of facts, however the coaching of the mind to assume. And learning abroad will certainly provides a boost to your education and career. a good learning expertise awaits you!!!
                        
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>

<?php
include 'bl/commententry.php';

?>

<!--form class="container">
    <div class="form-group">
      <label for="email ">Email address</label>
      <input type="email" class="form-control" id="email text" placeholder="name@mystudyguru.in">
    </div>
    
     
    <div class="form-group">
      <label for="data">Comment/Complement</label>
      <textarea class="form-control" id="data" rows="3" placeholder="The work by the blogger is really great and I appreciate his/her work."></textarea>
    </div>
    
    <button class="btn btn-primary btn1 m-3 px-5" >Submit it!</button>
  </form-->



   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 
<?php
include 'bl/section.html';

?>
        
<?php
include 'bl/commentshow.php';

?>                 
         
    
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
      </body>
    </html>
    
<?php
include 'Head_Foot/footer.html';

?>    