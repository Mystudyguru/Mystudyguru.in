<!DOCTYPE html>
<html>
<head>
<title>Forum</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body{
background:linear-gradient(to bottom, #8b62c7 0%, #4B0082 100%);
}
@media (max-width: 600px) {
        .main {
            border-radius: 1.5em;
			width:100%;
        }
		.body{
			width:100%;
		
		.table{
			width:100%;
		}
		.tr{
			width:100%;
		}
		.td{
			width:100%;
		}
		.p{
			width:100%;
		}
		.h5{
			width:100%;
			left:85%;
		}
		.img{
			width:100%;
		}
		}
		
		
}
.ctn{
      background-color:white;
       border:15px inset #00cc92;
}
.checked {
  color: orange;
}
</style>
</head>
<body>
<div align="center" class="display-4 text-white" >Query Forum</div>
<center><img src="Quiz-logo.gif" class="img-fluid" alt="forum"></center>
<div class="container">
<div class="row">
<form class="container" action="\connect/forum-q.php" method="POST">
<div class="form-group">
<label class="text-white">Post your questions or queries to get it resolved.</label><br>
<label for="email" class="text-white">Username</label>
<input type="text" name="username" class="form-control" id="email text" placeholder="mystudyguru@99">
</div>
<div class="form-group">
<label for="data" class="text-white">Your Question</label>
<textarea class="form-control" name="question" id="data" rows="3" placeholder="Ask your queries "></textarea>
</div>
<button class="btn btn-light btn1 m-3 px-5">Submit it!</button>
</form>
</div></div>
<div class="container-fluid">
<span class=" shadow p-2 mb-4 rounded">
<div class="card-body ctn">
<h5 style="position:absolute;" class=" float-left  ">Your Question:-<font style="background-color:white" class="text-primary">how to start prepara for upsc exam</font></h5></hr>
<br>
</div>
</span>
 
<br><br/><label class="position-absolute float-center text-white">Answers</label>
<br>
<table class="table table-bordered table-condensed">
<thead>
</thead>
<tbody>

<div class="card ">
<span class="border rounded shadow p-2 mb-4  rounded">
<div class="card-body">
<h5 style="position:absolute;" class=" float-left  ">Name-<font style="background-color:white" class="text-primary"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="cca1a3a4a5b88caba1ada5a0e2afa3a1">[email&#160;protected]</a></font></h5></hr>
<br><br>
<h5 style="position:absolute;" class="position-absolute float-left text-danger">Answer-<font style="background-color:white" class="text-primary">this is best site for upsc </font></h5>
<br>
</div>
</span>
</div>
</tbody>
</table>
</div>
<div align="center" class="message"><h3 style="color:white " data-toggle="collapse" data-target="#content" >Post your answer</h3></div>
 <div class="collapse  text-dark" id="content"><div class="container alertmsg"><p style="font-size:40px">
 
 <form action="\connect/forum-a.php" method="POST">
<div class="form-group">
<label class="text-white">Post your Answer</label><br>
<label for="email" class="text-white">Username</label>
<input type="text" name="ausername" class="form-control" id="email text" placeholder="mystudyguru@99">
</div>
<div class="form-group">
<label for="data" class="text-white">Your Answer</label>
<textarea class="form-control" name="answer" id="data" rows="3" placeholder=" try to give genunine solution "></textarea>
</div>
<button name="insert" class="btn btn-light btn1 m-3 px-5">Submit it!</button>
</form>
 </div></div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script></body>
</html>
