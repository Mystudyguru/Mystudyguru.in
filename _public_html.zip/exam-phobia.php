<?php
include 'Head_Foot/header.html';

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="robots" content="index,follow">
<meta name="keywords" content="fear of failure in upsc,what should i do after fail in upsc">
<meta name="description" content="Dont worry about failure in upsc exam mystudyguru help you out">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>Exam phobia blog -mystudyguru</title>
    <script>
         var data = document.getElementById('text') ;
        function submit(){
           
            console.log(data);
        }

    </script>
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 40vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: serif;
    font-size:20px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
      
      
       #filler-1{
           background:url('UPSC-COMPETITIVE-EXAM.jpg')center/cover no-repeat;
       border:4px solid grey;
       box-shadow: 0 10 10 125 rgba(0,0,0,0.7);
       }
       
       .height-40{
           min-height: 40vh;
       }
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
     
      

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            <div class="row">
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8"> 
                    <h1 class="text-light mt-4 ml-4 display ">
                        Does competitive exam scares you?
                </h1>
                <p class="text-light mt-4 ml-4">COMPETITVE EXAMS</p></div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-light m-4"><h4>by Chesta Sagar-  21/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3"> PHOBIA OF COMPETITVE EXAMS?</h1>
                   <p class="paragraph"> <b> </b>You gave your first exam to get admitted in your school and since then, you have been giving exams till now. With exams, comes a fear of failure or a hope for success. If you ask youself after each day, are you the same person as you were day before? This question may sounds illogical, but one can answer it at ease.
                    .</p>
                    
                    
                    
            
                    
                       <p class="paragraph"> Introspect yourself,. You learned a lot to pass the exam.
                            Is your knowledge ia as same as it was earlier? You were under stress during this entire
                             time. Haven’t you learned handling all these stress situations now? <br>
                             When you were struggling to find the answer to a question during your test ,
                              did you notice that you were mastering the skill of problem solving and decision 
                              making?<br> Now, there are endless questions that you can ask from yourself after any
                               exam. And the answers to these questions will make you feel confident and enthuiastic.
                                All you need to do is look for personality development rather than focusing on 
                                outcomes.
                        .</p>
                    
                    
                            <div class="container"  id="fille1">
                                <img src="images/blog/UPSC-COMPETITIVE-EXAM.jpg" class="img-fluid">
                                <div class="row height-0">
                                    <div class="col"> 
                                         
        
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mb-2 mt-3"> </h2>
                    <p class="paragraph"> Celebrate, if you succeed, 
                        but don’t forget to do the same if you somehow get failed. Because difficulties
                         in your life do not come to destroy you, but to realize your hidden potential and power.<br>
                          More than success, rejection teaches you a lot more. So,
                           instead of getting disheartened from failure, start analyzing and learning from it .
                           Remember, you only fail when you stop trying.
                    </p> 
                       
                
                      <h1 class="display-5 mt-5">Be Motivated</h1>
                      <p class="paragraph">The entire preparation process transforms you into a person with
                           better understanding and deeper perspective. It teaches you some life-changing lessons 
                           that no book can ever teach you. The spirit of never giving up and learning from your failures 
                           motivate you in all spells of life. You start knowing the worth of time, discipline, sincerity
                            and patience. You develop a positive attitude towards life. Knowledge and hard work never go in vain.<br>
                             Similarly, these lessons you learn whilst the preparation of exams help you to achieve success in 
                             whatever you do. Because at times of hardships, they will motivate you to stay positive in life. 


                      </p>

                </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col"> <h2 class="  display-5 mb-4"> </h2>
                    <p class="paragraph">

                        <div class="container mb-5"  id="filler-3">
                            <div class="row height-60">
                                <div class="col"> 
    
                                    <img src="images/blog/FEMALE-SUCCESS.jpg" class="img-fluid">
                                </div>
                            </div>
                        </div>
                         
                        
                        
                        
                        
                                <h2 class="  display-5 my-4"> </h2>
                                So, all the aspirants out there, you are warriors fighting day and night to achieve your goal. Whether you emerge out as a winner or not, you will still be a warrior who has struggled through all difficulties to become the best version of yourself! Exam time may appear to you as the following lines by Robert Frost:
                         <h2 class="  display-5 my-4"> BEST PRACTICES</h2>
                         
                        <h2 class="  display-5 my-4">   </h2>
                       
                         
                        
                        
                        </p>
                        <h1 class="display-5">Quote:</h1>  
                        “I have been one acquainted with the night,<br>
                        I have walked out in rain and back in rain.<br>
                        I have out walked the furthest city light,<br>
                        I have looked down the saddest city lane………”<br>
                        But it is actually an opportunity to know and develop yourself. <br>Explore your INFINITE POTENTIAL……Happy Learning!!!!!!

                        
                        
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>
<?php
include 'bl/commententry.php';

?>




   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 


<?php
include 'bl/section.html';

?>
<?php
include 'bl/commentshow.php';

?>                     
             
        
            <!-- Optional JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
          </body>
        </html>
        
<?php
include 'Head_Foot/footer.html';

?>