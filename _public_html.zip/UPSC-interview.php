<?php
include 'Head_Foot/header.html';

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="robots" content="index,follow">
        <meta name="keywords" content="UPSC INTERVIEW QUESTIONS OF TOPPER, UPSC TOPPERS INTERVIEW, IAS UPSC INTERVIEW QUESTIONS 2018 IN HINDI">
        <meta name="description" content="How to crack UPSC-CSE interview? Learn from toppers.">


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>IAS INTERVIEW</title>
    <script>
         var data = document.getElementById('text') ;
        function submit(){
           
            console.log(data);
        }

    </script>
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 35vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: serif;
    font-size:25px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
      
        
       
       .height-40{
           min-height: 40vh;
       }
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
     
      

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            <div class="row">
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8">
                    <h1 class="text-light mt-4 ml-4 display ">
                        “All about IAS interview”

                </h1>
                 <h1 class="text-light mt-4 ml-4">Interview</h1></div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-light m-4"><h4>by Chesta Sagar-  21/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3">UPSC- dreams of millions</h1>
                   <p class="paragraph"> <b> </b> UPSC exam is divided in three different stages. First the candidate have to give Prelims and Mains examinations.
                  <br> After qualifying prelims and mains candidate have to give an Interview which is also known as Personality test. The total marks of the Interview  is 275. Candidates are selected on the basis of marks obtained in Mains and Interview. So the Interview is consider very important for a UPSC aspirant.
                </p>
                    
                    
                    
            
                    
                       <p class="paragraph">In UPSC Interview, interview panel is consists of 5 members
                             among them one is Board chairman. The interview is conducted to test the  
                             pesonality  and temperament of a Candidate.  <br>The interview has no fixed format 
                             or pattern. At the starting of the interview questions  are  generally asked based on candidate’s  DAF( Detailed Application form) like Education, hobbies, work , culture, interests of the candidate . Current affairs are  also asked in  the interview. The interviewers generally check whether the candidate have the traits and qualities to be a good Officer. They check how the candidate response to a particular problem and ask opinions regarding any political and religious issues. They check honesty , trustworthy and whether candidate have any religious or culture baises.

                        .</p>
                    
                    
                            <div class="container"  id="filler-1">
                                <div class="row height-60">
                                    <div class="col"> 
                                        <img src="images/blog/UPSC-INTERVIEW-PREPRATION.jpg"alt="UPSC INTERVIEW PREPRATION" class="img-fluid">
        
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mb-2 mt-3"> TIPS </h2>
                    <p class="paragraph"> So here are some important
                         points which one should keep in their mind before appearing in the UPSC interview:<ul> 
                        <li class="paragraph">
                            Generate a sensible time-table<br>
Make a timetable that includes of daily possible targets. Don’t create a strict one. Remember, you would like to follow it daily. Hence, set a goal and check out to manage time in terms of day, week, and a month.

<br> <br> </li> 
                    <li class="paragraph"> This interview is mainly conducted to test your personality not knowledge. One should have to be psychologically prepared . Prepare yourself to reflect your personality in a manner that would be appreciated by Board members.
                        <br><br></li>
                    <li class="paragraph">  
                        Treat the Board  members with respect.  <br> <br></li>
                    <li class="paragraph">Be honest while answering the questions .The  Board Members have 20-30 years experience , so they can easily catch a lie .  <br> <br> </li> 
                    <li class="paragraph">You must give answer in short ,so that there is less scope for supplementary questions.<br> <br></li>  
                    <li class="paragraph"> You should have a clear opinion regarding any issue. Your answer should not be diplomatic. You have to take a side of any issue.
                        <br> <br> </li>
                        <li class="paragraph">Take your  time to frame answers in your mind ,so that you can answer clearly.

                            <br><br></li>
                        <li class="paragraph">Your attitude will define you success more in the interview more  than your aptitude.
                                <br><br></li>
                       
                </ul> </p> 
                        <div class="container"  id="filler-2">
                            <div class="row height-60">
                                <div class="col"> 
                                    <img src="images/blog/UPSC-INTERVIEW-QUESTIONS.jpg" alt="UPSC INTERVIEW QUESTIONS" class="img-fluid">
    
                                </div>
                            </div>
                        </div>
                
                      <h1 class="display-5 mt-5"> </h1>
                      <p class="paragraph">These are some common questions that can asked ,you have to find out the answers by yourself. :

                     
                     <br><br> 1-Why you want to join civil services ?<br><br>
                      2-What changes would  you like to  bring after becoming a IAS/IPS/IFS/IRS Officer ?<br><br>
                      3-Convincing reason behind the selection of a particular optional subject.<br><br>
                      4-Which service you want to select and why?<br><br>

                    </p>
                </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col"> <h2 class="  display-5 mb-4"> </h2>
                    <p class="paragraph">

                        <div class="container mb-5"  id="filler-3">
                            <div class="row height-60">
                                <div class="col"> 
                                    <img src="images/blog/UPSC-INTERVIEW-TOPPER.jpg" alt="UPSC-INTERVIEW-TOPPER" class="img-fluid">
    
                                </div>
                            </div>
                        </div>
                         
                        
                        
                        
                        
                                <h2 class="  display-5 my-4"> </h2>
                                    <h2 class="  display-5 my-4">WORDS FROM AUTHOR! </h2>
                         
                        <h2 class="  display-5 my-4">   </h2>
                       
                         
                        
                        
                        </p>
                        <h1 class="display-5"> </h1>  
                        At last , competitive exams are nothing however a race, not simply against different competitors, however also against the clock. So, ace time management to extend your
                         productivity and win your goals .Learn to be the master of your minutes….GOOD LUCK!!!
                        
                        
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>
<?php
include 'bl/commententry.php';
?>


   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 

<?php
include 'bl/section.html';

?>
<?php
include 'bl/commentshow.php';

?>    
             
     

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>
<?php
include 'Head_Foot/footer.html';

?>