<?php
include 'Head_Foot/header.html'; 
?>
<!DOCTYPE>
<html>
<head>
<style>
.ac{
background-color:#8b62c7;

}
a{ font-family:georgia;
 
}
a:hover{ 
       font-size:21px;
	   text-decoration:
}
.as{
    background-color:#D0D3D4;
	height:500px;
}
li{font-size:20px;
  text-shadow:1px 1px 1px black;
}
</style>
 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="robots" content="index,follow">
<meta name="keywords" content="current affairs,current affairs 2020,current affairs magzine,todays current affairs">
<meta name="description" content="latest current affairs  and stay updated from what new with mystudyguru ">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


<title>Current-Affairs|mystudyguru</title>
</head>
<body style="background-color:#F8EBFF;">


<div class="container-fluid border border-info  ac">
<div class="row color-section pt-2 m-0">
        <div class="col text-white ">
<h1 class="display-5"  align="center"; style="font-family:georgia, serif; color:white; "> <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-book" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M3.214 1.072C4.813.752 6.916.71 8.354 2.146A.5.5 0 0 1 8.5 2.5v11a.5.5 0 0 1-.854.354c-.843-.844-2.115-1.059-3.47-.92-1.344.14-2.66.617-3.452 1.013A.5.5 0 0 1 0 13.5v-11a.5.5 0 0 1 .276-.447L.5 2.5l-.224-.447.002-.001.004-.002.013-.006a5.017 5.017 0 0 1 .22-.103 12.958 12.958 0 0 1 2.7-.869zM1 2.82v9.908c.846-.343 1.944-.672 3.074-.788 1.143-.118 2.387-.023 3.426.56V2.718c-1.063-.929-2.631-.956-4.09-.664A11.958 11.958 0 0 0 1 2.82z"/>
  <path fill-rule="evenodd" d="M12.786 1.072C11.188.752 9.084.71 7.646 2.146A.5.5 0 0 0 7.5 2.5v11a.5.5 0 0 0 .854.354c.843-.844 2.115-1.059 3.47-.92 1.344.14 2.66.617 3.452 1.013A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.276-.447L15.5 2.5l.224-.447-.002-.001-.004-.002-.013-.006-.047-.023a12.582 12.582 0 0 0-.799-.34 12.96 12.96 0 0 0-2.073-.609zM15 2.82v9.908c-.846-.343-1.944-.672-3.074-.788-1.143-.118-2.387-.023-3.426.56V2.718c1.063-.929 2.631-.956 4.09-.664A11.956 11.956 0 0 1 15 2.82z"/>
</svg><br/>Current-Affairs</</h2></br>
</div>
</div>
</div>
<div class="container as overflow-auto ">
<br>
<ul>
    <li>COVID-19 CURRENT AFFAIRS(V-IMP)<a href="pdfs/ca/covid-19-important-current-affairs-2020.pdf" target="_blank" >Click-here</a></li><br/>

<li>1) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 1.pdf" target="_blank" >Click-here</a></li><br/>
<li>2) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 2.pdf" target="_blank" >Click-here</a></li><br/>
<li>3) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 3.pdf" target="_blank"> Click-here</a></li><br/>
<li>4) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 4.pdf" target="_blank" >Click-here</a></li><br/>
<li>5) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 5.pdf" target="_blank" >Click-here</a></li><br/>
<li>6) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 6.pdf" target="_blank">Click-here</a></li><br/>
<li>7) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 7.pdf" target="_blank" >Click-here</a></li><br/>
<li>8) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 8.pdf" target="_blank" >Click-here</a></li><br/>
<li>9) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 9.pdf" target="_blank">Click-here</a></li><br/>
<li>10) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 10.pdf" target="_blank">Click-here</a></li><br/>
<li>11) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 11.pdf" target="_blank">Click-here</a></li><br/>
<li>12) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 12.pdf" target="_blank">Click-here</a></li><br/>
<li>13) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 13.pdf" target="_blank">Click-here</a></li><br/>
<li>14) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 14.pdf" target="_blank">Click-here</a></li><br/>
<li>15) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 15.pdf" target="_blank" >Click-here</a></li><br/>
<li>16) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 16.pdf" target="_blank" >Click-here </a></li><br/>
<li>17) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 17.pdf" target="_blank" >Click-here</a></li><br/>
<li>18) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 18.pdf" target="_blank" >Click-here</a></li><br/>
<li>19) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 19.pdf" target="_blank" >Click-here </a></li><br/>
<li>20) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 20.pdf" target="_blank" >Click-here</a></li><br/>
<li>21) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 21.pdf" target="_blank">Click-here</a></li><br/>
<li>22) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 22.pdf" target="_blank">Clicca/k-here</a></li><br/>
<li>23) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 23.pdf" target="_blank">Clicca/k-here</a></li><br/>
<li>24) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 24.pdf" target="_blank">Clicca/k-here</a></li><br/>
<li>25) Latest_Current_Affairs(2020):-<a href="pdfs/ca/Latest_current_affairs 25.pdf" target="_blank">Clickca/-here</a></li><br/>
<li>26) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-1.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>27) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-2.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>28) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-3.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>29) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-4.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>30) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-5.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>31) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-6.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>32) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-7.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>33) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-8.pdf" target="_blaca/nk">Click-here</a></li><br/>
<li>34) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-9.pdf" target="ca/_blank">Click-here</a></li><br/>
<li>35) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-10.pdf" target=ca/"_blank">Click-here</a></li><br/>
<li>36) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-11.pdf" target=ca/"_blank">Click-here</a></li><br/>
<li>37) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-12.pdf" target=ca/"_blank">Click-here</a></li><br/>
<li>38) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-13.pdf" target=ca/"_blank">Click-here</a></li><br/>
<li>39) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-14.pdf" target=ca/"_blank">Click-here</a></li><br/>
<li>40) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-15.pdf" target=ca/"_blank">Click-here</a></li><br/>
<li>41) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-16.pdf" target="_blank">Click-here</a></li><br/>
<li>42) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-17.pdf" target="_blank">Click-here</a></li><br/>
<li>43) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-18.pdf" target="_blank">Click-here</a></li><br/>
<li>44) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-19.pdf" target="_blank">Click-here</a></li><br/>
<li>45) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-20.pdf" target="_blank">Click-here</a></li><br/>
<li>46) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-21.pdf" target="_blank">Click-here</a></li><br/>
<li>47) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-22.pdf" target="_blank">Click-here</a></li><br/>
<li>48) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-23.pdf" target="_blank">Click-here</a></li><br/>
<li>49) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-24.pdf" target="_blank">Click-here</a></li><br/>
<li>50) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-25.pdf" target="_blank">Click-here</a></li><br/>
<li>51) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-26.pdf" target="_blank">Click-here</a></li><br/>
<li>52) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-27.pdf" target="_blank">Click-here</a></li><br/>
<li>53) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-28.pdf" target="_blank">Click-here</a></li><br/>
<li>54) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-29.pdf" target="_blank">Click-here</a></li><br/>
<li>55) Current-Affairs-Pdf-Download-:-<a href="pdfs/ca/Current-Affairs-Pdf-Download-30.pdf" target="_blank">Click-here</a></li><br/>

<li>56) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-1.pdf" target="_blank">Click-here</a></li><br/>
<li>57) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-2.pdf" target="_blank">Click-here</a></li><br/>
<li>58) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-3.pdf" target="_blank">Click-here</a></li><br/>
<li>59) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-4.pdf" target="_blank">Click-here</a></li><br/>
<li>60) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-5.pdf" target="_blank">Click-here</a></li><br/>
<li>61) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-6.pdf" target="_blank">Click-here</a></li><br/>

<li>62) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-7.pdf" target="_blank">Click-here</a></li><br/><li>55) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-8.pdf" target="_blank">Click-here</a></li><br/>
<li>63) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-9.pdf" target="_blank">Click-here</a></li><br/>
<li>64) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-10.pdf" target="_blank">Click-here</a></li><br/>
<li>65) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-11.pdf" target="_blank">Click-here</a></li><br/>
<li>66) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-12.pdf" target="_blank">Click-here</a></li><br/>
<li>67) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-13.pdf" target="_blank">Click-here</a></li><br/>
<li>68) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-14.pdf" target="_blank">Click-here</a></li><br/>
<li>69) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-15.pdf" target="_blank">Click-here</a></li><br/>
<li>70) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-16.pdf" target="_blank">Click-here</a></li><br/>
<li>71) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-17.pdf" target="_blank">Click-here</a></li><br/>
<li>72) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-18.pdf" target="_blank">Click-here</a></li><br/>
<li>73) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-19.pdf" target="_blank">Click-here</a></li><br/>
<li>74) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-20.pdf" target="_blank">Click-here</a></li><br/>
<li>75) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-21.pdf" target="_blank">Click-here</a></li><br/>
<li>76) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-22.pdf" target="_blank">Click-here</a></li><br/>
<li>77) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-23.pdf" target="_blank">Click-here</a></li><br/>
<li>78) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-24.pdf" target="_blank">Click-here</a></li><br/>
<li>79) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-25.pdf" target="_blank">Click-here</a></li><br/>
<li>80) Best-Free-Current Affairs-pdf-download-for-all-exams :-<a href="pdfs/ca/Best-Free-Current Affairs-pdf-download-for-all-exams-26.pdf" target="_blank">Click-here</a></li><br/>

</ul></div>
  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
</body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>