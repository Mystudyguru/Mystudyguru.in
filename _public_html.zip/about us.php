
<!doctype html>
<html lang="en">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="decription" content=" content="Prepare for competitive examinations for any courses from various topics on mystudyguru free online learning for all >
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css"> 
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!--Font Awesome -->
    <link rel="canonical"  href="https://mystudyguru.in" />
    <script type="text/javascript" src=" ./js/all.js">  </script>
    <!--Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Galada&display=swap" rel="stylesheet">

    <title>ABOUT Mystudyguru.in -MSG</title>
    <style type="text/css">
      body{
        background-color: white;
      }
      #section_{
        background:#8b62c7;
      }
      .heading{
        font-family: Georgia, serif;
      }
      
      .height-80{
        min-height: 80vh;
      }
      .height-60{
        min-height: 60vh;
      }
    </style>
    </head>

    <body>
        <!--HEADING -->
        <section id="section_" class="py-2">
          <div class="container-fluid">
            <div class="row">
              <div class="col">
                <h1 class="display-4 heading text-center text-white"><u>My Study Guru</u></h1>
              </div>
            </div>
          </div>
        </section>
        <!--END OF HEADING -->
 
        <!-- FILLER SECTION -->
        <img src="images/about-us.jpg" class="img-fluid container-fluid" alt="My Study Guru" style="max-widht:60%">

      <!--END OF FILLER SECTION -->

      <div class="container-fluid p-5">
        <div class="row">
            <div class="col pl-5">
                <p class="text-left " style="color:#1D1408; font-size:20px">
                    Welcome to the best destination for self-study platform that aims at whirling hard work 
                    and dedication into booming success!<br>
                    The Idea is dedicated to my father,<label class="text-danger"> Late Shri. Ajay Pal [Harshvarshan Siddhartha]</label> Founder.<br>
                    In the today's world of competition where the world Is growing at an unexpected rate and the only to be successful is only growing through competition. In countries like INDIA where the supply of opportunity is comparatively lower than the supply of demands as results aspirants needs to face more and more challenges. So as to face these challenge aspirants seeks different website for the sake of fulfillment of their needs as a result aspirant get confused and waste a lot of time in finding the right material.<br>
                    So, we here at mystudyguru works all around for finding best study material, creating content, quizzes, certification based competitions so the complete need of an aspirant could be match at his/her fingertip.<br>
                    WE mystudyguru.in is a team of 3-4 members focused at finding the right study material for the aspirants.</p>
                        <h1 class="text-center">
                            <a href="https://mystudyguru.in"> MyStudyGuru.in <br><button class="btn btn-primary">Get Home</button></a></h1>
                     <p class="text-left " style="color:#1D1408; font-size:20px">
                    Magnificent study material<br>
                    Youthful content<br>
                    Studious <br>
                    Teamwork<br>
                    Understanding<br>
                    Dedicated<br>
                    Year long <br>
                    Genuine<br>
                    Uniqueness<br>
                    Righteous<br>
                    User friendly<br>
                    India<br><br>
                     Aspirants can access <a href="https://mystudyguru.in" >mystudyguru.in </a> either on mobile or laptop making it education more easily available at their fingertip and can also get real time alert on various topic and can enhance their skills through various program being organized on daily basis. <br><br>
                        Regards:<br>
                            <label class="text-danger">Team mystudyguru.in</label>



                </p>
            </div>
        </div>
          
      </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/jquery-3.5.1.js "></script>
  <!--Bootstrap Refrence -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  </body>
</html>
