<?php
include 'Head_Foot/header.html'; 
?>
<!doctype html>
<html lang="en">
  <head>
  <style>
	  h3{ font-family:'tangerine',serif;
text-shadow: 4px 4px 4px black;}

.cbox{
background-color:#8b62c7;
border-radius:5px;
margin:20px;
}
.ctn{
height:250px;
padding:20px;
background-color:#D0D3D4;
border-radius:5px;
}
.ac{

background-color:#8b62c7;
}
a{
    padding-left:15px;
}
a:hover{ 
       font-size:21px;
	   text-decoration:
}
li{font-size:20px;
padding-left:10px;
}
 </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Syllabus for all exam</title>
  </head>
  <body style="background-color:#F8EBFF;">
  <div class="container-fluid head"> 
<h3 align="center" style="color:white; background-color:#8b62c7;  font-size:45px;"><u>My Study Guru</u></h3>
</div>
<br>
<br>
<br>
<div class="container-fluid border border-dark">
<div class="jumbotron jumbotron-fluid">
 <p style="font-family:'Galada',Cursive; font-size:20px">IT's time to check your preparation. So let get started with some previuos year papers. Set up your stopwatch and solve  each paper in a fixed time.
 Here are some papers related to UPSC,SSC,Banking and many more. </p>
<center> <b><p style="font-family:georgia; font-size:28px">ALL THE BEST  <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-hand-thumbs-up" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M6.956 1.745C7.021.81 7.908.087 8.864.325l.261.066c.463.116.874.456 1.012.965.22.816.533 2.511.062 4.51a9.84 9.84 0 0 1 .443-.051c.713-.065 1.669-.072 2.516.21.518.173.994.681 1.2 1.273.184.532.16 1.162-.234 1.733.058.119.103.242.138.363.077.27.113.567.113.856 0 .289-.036.586-.113.856-.039.135-.09.273-.16.404.169.387.107.819-.003 1.148a3.163 3.163 0 0 1-.488.901c.054.152.076.312.076.465 0 .305-.089.625-.253.912C13.1 15.522 12.437 16 11.5 16v-1c.563 0 .901-.272 1.066-.56a.865.865 0 0 0 .121-.416c0-.12-.035-.165-.04-.17l-.354-.354.353-.354c.202-.201.407-.511.505-.804.104-.312.043-.441-.005-.488l-.353-.354.353-.354c.043-.042.105-.14.154-.315.048-.167.075-.37.075-.581 0-.211-.027-.414-.075-.581-.05-.174-.111-.273-.154-.315L12.793 9l.353-.354c.353-.352.373-.713.267-1.02-.122-.35-.396-.593-.571-.652-.653-.217-1.447-.224-2.11-.164a8.907 8.907 0 0 0-1.094.171l-.014.003-.003.001a.5.5 0 0 1-.595-.643 8.34 8.34 0 0 0 .145-4.726c-.03-.111-.128-.215-.288-.255l-.262-.065c-.306-.077-.642.156-.667.518-.075 1.082-.239 2.15-.482 2.85-.174.502-.603 1.268-1.238 1.977-.637.712-1.519 1.41-2.614 1.708-.394.108-.62.396-.62.65v4.002c0 .26.22.515.553.55 1.293.137 1.936.53 2.491.868l.04.025c.27.164.495.296.776.393.277.095.63.163 1.14.163h3.5v1H8c-.605 0-1.07-.081-1.466-.218a4.82 4.82 0 0 1-.97-.484l-.048-.03c-.504-.307-.999-.609-2.068-.722C2.682 14.464 2 13.846 2 13V9c0-.85.685-1.432 1.357-1.615.849-.232 1.574-.787 2.132-1.41.56-.627.914-1.28 1.039-1.639.199-.575.356-1.539.428-2.59z"/>
</svg></p></b></center>
</div>
</div>
 
   <div class="container-fluid border border-dark ac"> <h1 class="display-5"  align="left"  style="color:white; font-family:'georgia', serif;"><center><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-file-earmark" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path d="M4 1h5v1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V6h1v7a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2z"/>
  <path d="M9 4.5V1l5 5h-3.5A1.5 1.5 0 0 1 9 4.5z"/></svg>
  <br/>Syllabus for all Competitive-Exams
</center></h1>
   </div>  
   
	<div class="container-fluid">
<div class="row">
<div class="col-11 col-lg-5 container cbox border border-dark"><h2  class="text-white"align="center" style="font-family:georgia;">UPSC<hr></h2>
<div class="container-responsive">
<div class="container ctn overflow-auto"><ul>
<li>PCS-syllabus-2020 <a href="pdfs/syllabus/upsc/PCS-syllabus-2020.pdf">Click here</a></li>
<li>IAS-Syllabus-in-Hindi.pdf<a href="pdfs/syllabus/upsc/IAS-Syllabus-in-Hindi.pdf">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>
<li>pStay Connected! Uploaded Soon. <a href="pdfs/syllabus/upsc/">Click here</a></li>

</ul></div></div>
</div>
<div class="col-11 col-lg-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia;">SSC<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li>SSC_(10+2)_Syllabus <a href="pdfs/syllabus/ssc/SSC-10+2-syllabus.pdf">Click here</a></li>
<li>SSC_CHSL(Eng)_Syllabus <a href="pdfs/syllabus/ssc/SSC-chsl(english).pdf">Click here</a></li>
<li>SSC_CHSL(Hindi)_Syllabus <a href="pdfs/syllabus/ssc/SSC-chsl(hindi).pdf">Click here</a></li>
<li>SSC_CGL_Tier-1_Syllabus <a href="pdfs/syllabus/ssc/SSC-Cgl-TIER-1.pdf">Click here</a></li>
<li>SSC_CGL_Tier-2_Syllabus <a href="pdfs/syllabus/ssc/SSC-Cgl-TIER-2.pdf">Click here</a></li>
<li>SSC_GD_Syllabus <a href="pdfs/syllabus/ssc/SSC-GD.pdf">Click here</a></li>
<li>SSC_Combined_Syllabus <a href="pdfs/syllabus/ssc/SSC-combined-tier-1&tier-2-syllabus.pdf">Click here</a></li>
<li>UPSSC-_J.E-syllabus <a href="pdfs/syllabus/ssc/UPSSC-_J.E-syllabus.pdf">Click here</a></li>
<li>UPSSC-chakbandi <a href="pdfs/syllabus/ssc/UPSSC-chakbandi.pdf">Click here</a></li>
<li>pStay Connected! Uploaded Soon. <a href="pdfs/syllabus/ssc/">Click here</a></li>
</ul></div></div>
<div class="col-11 col-lg-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia;">RRB<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li>RRB-GROUP-D <a href="pdfs/syllabus/rrb/RRB-GROUP-D.pdf">Click here</a></li>
<li>RRB-ntpc <a href="pdfs/syllabus/rrb/RRB-ntpc.pdf">Click here</a></li>
<li>RRB-SYLLAB <a href="pdfs/syllabus/rrb/RRB-SYLLAB.pdf">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
<li>pStay Connected! Uploaded Soon. <a href="pdfs/syllabus/rrb/">Click here</a></li>
</ul></div>
</div>


<div class="col-11 col-lg-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia; ">TET's<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li>CTET-syllabus <a href="pdfs/syllabus/tet/CTET-syllabus.pdf">Click here</a></li>
<li>SUPER-TET <a href="pdfs/syllabus/tet/supertet.pdf">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>pStay Connected! Uploaded Soon. <a href="">Click here</a></li>
</ul></div>
</div>

<!--<div class="col-11 col-lg-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia;">STET<hr></h2>-->
<!--<div class="container ctn overflow-auto"><ul>-->
<!--<li>paper 1 <a href="">Click here</a></li>-->
<!--<li>paper 2 <a href="">Click here</a></li>-->
<!--<li>paper 3 <a href="">Click here</a></li>-->
<!--<li>paper 4 <a href="">Click here</a></li>-->
<!--<li>paper 5 <a href="">Click here</a></li>-->
<!--<li>paper 6 <a href="">Click here</a></li>-->
<!--<li>paper 7 <a href="">Click here</a></li>-->
<!--<li>paper 8 <a href="">Click here</a></li>-->
<!--<li>paper 9 <a href="">Click here</a></li>-->
<!--<li>paper 10 <a href="">Click here</a></li>-->
<!--</ul></div>-->
<!--</div>-->

<!--<div class="col-11 col-lg-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:georgia;">UPTET<hr></h2>-->
<!--<div class="container ctn overflow-auto"><ul>-->
<!--<li>paper 1 <a href="">Click here</a></li>-->
<!--<li>paper 2 <a href="">Click here</a></li>-->
<!--<li>paper 3 <a href="">Click here</a></li>-->
<!--<li>paper 4 <a href="">Click here</a></li>-->
<!--<li>paper 5 <a href="">Click here</a></li>-->
<!--<li>paper 6 <a href="">Click here</a></li>-->
<!--<li>paper 7 <a href="">Click here</a></li>-->
<!--<li>paper 8 <a href="">Click here</a></li>-->
<!--<li>paper 9 <a href="">Click here</a></li>-->
<!--<li>paper 10 <a href="">Click here</a></li>-->
<!--</ul></div>-->
<!--</div>-->

<div class="col-11 col-lg-5 container cbox border border-dark"><h2  class="text-white" align="center"style="font-family:georgia;">BANKING<hr></h2>
<div class="container ctn overflow-auto"><ul>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>pStay Connected! Uploaded Soon. <a href="">Click here</a></li>
</ul></div>
</div>

<div class="col-11 col-lg-5 container cbox border border-dark"><h2 class="text-white" align="center" style="font-family:'tangerine',serif;">Others <hr></h2>
<div class="container ctn overflow-auto"><ul>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>Stay Connected! Uploaded Soon. <a href="">Click here</a></li>
<li>pStay Connected! Uploaded Soon. <a href="">Click here</a></li>

</ul></div>
</div>
</div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
  
  </body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>