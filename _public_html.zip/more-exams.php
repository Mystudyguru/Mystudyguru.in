<?php
include 'Head_Foot/header.html'; 
?>
<!doctype html>
<html lang="en">
  <head>
  <style>
	  h3{ font-family:'tangerine',serif;
text-shadow: 4px 4px 4px black;}

.cbox{
background-color:#8b62c7;
border-radius:5px;
margin:20px;
}
.ctn{
height:400px;
padding:20px;
background-color:#D0D3D4;
border-radius:5px;
}
.ac{

background-color:#8b62c7;
}
a:hover{ 
       font-size:21px;
}
li{font-size:20px;
}
 </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="robots" content="index,follow"/>
<meta name="keywords" content="banking exams,banking exam syllabus,banking previous year papers,sbi bank po exam">
<meta name="descrition" content="mystudyguru provides you free studymaterial for banking,railway,police  army and all state level exams ">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Banking|police|army|state exam</title>
  </head>
  <body style="background-color:#F8EBFF;">
<br>
   <div class="container-fluid border border-dark ac"> <h1 class="display-5"  align="center"  style="color:white; font-family:'georgia', serif;">
  <br/>All State level exams</h1>
   </div>  
   
	<div class="container-fluid">
<div class="col-12 col-md-8 container cbox border border-dark"><h1  class="text-white" align="center"style="font-family:georgia;">BANKING<hr></h1>
<div class="container ctn overflow-auto"><ul>
<li>1999+ Compute Knowledge MCQs  <a href="pdfs/bank/COMPUTER KNOWLEDGE - 2000 MCQs.pdf" class="text-primary"> Click here</a></li>
<li>Data Integration <a href="pdfs/bank/Data interepretation.pdf" class="text-primary"> Click here</a></li>
<li>Maths Tricks for Banking shortcut <a href="pdfs/bank/AVERAGE-SHORT-CUT-TRICKS-FOR-BANKING.pdf" class="text-primary"> Click here</a></li>
<li>Maths Tips for banking  <a href="pdfs/bank/AVERAGE-SHORT-CUT-TRICKS-TIPS-FOR-BANKING.pdf" class="text-primary"> Click here</a></li>
<li>Banking Booster <a href="pdfs/bank/Bank-Clerk-booster-Hindi-1.pdf" class="text-primary"> Click here</a></li>
<li>Imp DS+DA+DI for bank <a href="pdfs/bank/DS + DA + DI-for-banking.pdf" class="text-primary"> Click here</a></li>
<li>DATA SUFFICIENCY <a href="pdfs/bank/DS-for-banking.pdf" class="text-primary"> Click here</a></li>
<li>Expected Question for bank <a href="pdfs/bank/expected-questions-for-bank.pdf" class="text-primary"> Click here</a></li>
<li>Power capsule for SBI-Clerk <a href="pdfs/bank/gk_power_capsule_sbi_clerk_2020.pdf" class="text-primary"> Click here</a></li>
<li>IBPS CS <a href="pdfs/bank/IBPS-Computer-Knowledge-Paper-I.pdf" class="text-primary"> Click here</a></li>
<li>SBI-Clerk Marketing Capsule <a href="pdfs/bank/marketing_capsule_for_sbi_clerk.pdf" class="text-primary"> Click here</a></li>
<li>Platinum point for Banking <a href="pdfs/bank/platinum-point-for-banking.pdf" class="text-primary"> Click here</a></li>
<li>Banking Puzzles <a href="pdfs/bank/Puzzles-for-bank.pdf" class="text-primary"> Click here</a></li>
<li>Reasoning <a href="pdfs/bank/Reasoning-Solved-Paper-for-banking.pdf" class="text-primary"> Click here</a></li>
<li>SBI-Po associative <a href="pdfs/bank/sbi-associate-po-hindi.pdf" class="text-primary"> Click here</a></li>
<li>Top most asked interview questions <a href="pdfs/bank/top-inteview-question-for-bank.pdf" class="text-primary"> Click here</a></li>
</ul></div>
</div>

<!--<div class="col-12 col-md-8 container cbox border border-dark"><h1 class="text-white" align="center" style="font-family:'tangerine',serif;">Junior Engineers<hr></h1>-->
<!--<div class="container ctn overflow-auto"><ul>-->
<!--<li>paper 1 <a href="">coming soon</a></li>-->
<!--<li>paper 2 <a href="">coming soon</a></li>-->
<!--<li>paper 3 <a href="">coming soon</a></li>-->
<!--<li>paper 4 <a href="">coming soon</a></li>-->
<!--<li>paper 5 <a href="">coming soon</a></li>-->
<!--<li>paper 6 <a href="">coming soon</a></li>-->
<!--<li>paper 7 <a href="">coming soon</a></li>-->
<!--<li>paper 8 <a href="">coming soon</a></li>-->
<!--<li>paper 9 <a href="">coming soon</a></li>-->
<!--<li>paper 10 <a href="">coming soon</a></li>-->

<!--</ul></div>-->
<!--</div>-->
<!--<div class="col-12 col-md-8 container cbox border border-dark"><h1 class="text-white" align="center" style="font-family:'tangerine',serif;">POLICE || ARMY<hr></h1>-->
<!--<div class="container ctn overflow-auto"><ul>-->
<!--<li>paper 1 <a href="">coming soon</a></li>-->
<!--<li>paper 2 <a href="">Click here</a></li>-->
<!--<li>paper 3 <a href="">Click here</a></li>-->
<!--<li>paper 4 <a href="">Click here</a></li>-->
<!--<li>paper 5 <a href="">Click here</a></li>-->
<!--<li>paper 6 <a href="">Click here</a></li>-->
<!--<li>paper 7 <a href="">Click here</a></li>-->
<!--<li>paper 8 <a href="">Click here</a></li>-->
<!--<li>paper 9 <a href="">Click here</a></li>-->
<!--<li>paper 10 <a href="">Click here</a></li>-->

<!--</ul></div>-->
</div>
</div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  
  
  </body>
</html>
<?php
include 'Head_Foot/footer.html'; 
?>