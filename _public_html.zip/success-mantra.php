<?php
include 'Head_Foot/header.html';

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="robots" content="index,follow">
        <meta name="keywords" content="Success, success factor,succession, successfully ,success motivational quotes">
        <meta name="description" content="Learn how they get successful in acheiving their aim with mystudyguru.">


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>SUCCESS MANTRA</title>
    <script>
         var data = document.getElementById('text') ;
        function submit(){
           
            console.log(data);
        }

    </script>
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 40vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: Arial, Helvetica, sans-serif;
    font-size:22px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
       .height-60{
           min-height: 60vh;
       }
       #filler{
           background:url('images/blog/success-mantra.jpg')center/cover no-repeat;
       }
       
       
       #filler-3{
        border:4px solid  grey;
       box-shadow: 0 10 10 125 rgba(0,0,0,0.7);
           background:url('https://cdn.archive.siasat.com/wp-content/uploads/2019/04/junaid-ahmad-1280x720.jpg')right no-repeat;
            
       }
       .height-60{
           min-height:55vh;
      
       }
        
       .height-40{
           min-height: 50vh;
           
       }
       
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
     
      

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            <div class="row">
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8">
                    <h1 class="text-danger mr-5 mt-5  mr-4 text-left" style="font-weight:700;">
                        How to prepare for UPSC-CSE/<h1>
                        <p>Be inspired and be an inspiration.
                </p>
                 <p class="text-dark mt-4 ml-4 text-uppercase text-right" style="font-weight:800;">Know their Success Mantra!! 
                </p></div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-primary m-4"><h4><a href="..." class="text-primary">by Chesta Sagar</a> -  21/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3 text-uppercase"> Success Mantra!</h1>
                   <p class="paragraph"> <i><b> “The civil services allow you to use your knowledge and learning to do something for the nation ,to give back to the society. 
                       So, I worked hard for it.” </i></b> These are the lines quoted by <b>Srushti Jayant Deshmukh(Rank 5 ,CSE-2018).</b>
                    </p>
                    
                    
                    
            
                    
                       <p class="paragraph">  Another lines come from IAS topper(CSE 2015)- <b>Tina Dabi  :
                          <i> ”I think if you put in requisite amount of hardwork and dedication, then, it doesn’t
                            matter if you are from science or an arts background. I am from an arts background 
                            and I have proved that hard work pays off”</i></b>. Now, they never <i>
                                “expected to emerge as the
                             topper”</i>-as stated by IAS topper <b>Kanishak Kataria(Rank-1 CSE(2018))</b>,but they eventually,
                              landed up becoming role models of all the IAS aspirants.
                        <br></p>
                       
                    
                    
                            <div class="container"  id="filler-1">
                                <div class="row height-60">
                                    <div class="col"> 
        
                                        <img src="images/blog/COMPETITVE-EXAMS.jpg" alt="COMPETITVE EXAMS IAS/PCS" class="img-fluid" style="width:100%; height:100vh;">
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mb-2 mt-5 diplay-4"> TIPS BY IAS!</h2>
                    <p class="paragraph"> 
                       
                            <h2 class="text-left mb-2 mt-5 display-5"> Shruti Jayant Deshmukh:</h2>
                            <p class="paragraph mt-4">  So, here we bring to you the preparation strategy used by some of the IAS toppers,
                             so that you can learn from their mistakes , 
                             follow their tips and hence, plan a strategy for yourself.
                        </p> <ul class="paragraph">
                        <li>While talking about her journey, <b> Shruti Jayant Deshmukh </b>  ,
                            the women topper of 2018, shared her success mantra:</li>
                    </ul> </p>
                    
                    <p class="paragraph  "> As all  the successful people do,
                         she focused on utilizing her time productively, 
                         ensuring that she uses every minute efficiently be it reading newspaper thoroughly
                          while commuting between home and college or avoiding social gatherings or parties.
                    </p> 
                    <div class="container"  id="filler-2">
                        <div class="row height-60">
                            <div class="col"> 
                                <img src="images/blog/Personality-development-tips.jpg.jpg" alt="IAS/PCS INTERVIEW" class="img-fluid">

                            </div>
                        </div>
                    </div><p class="paragraph mt-5">She believes that reading and analyzing current affairs was the first pillar 
                        of her preparation. Now, reading newspaper does not mean a 5-minute affair. 
                        She used to read the newspaper, make notes of those current affairs and then,
                         analyzed each one from various aspects like political, geographical, economical etc.<br>For current affairs, she not only depended on newspapers, but also watched Rajya Sabha programmes , read government advisories, reports and documents etc.</p>
                        <p class="paragraph">Apart from this, she ensured effective answer writing because she
                             believes that when everyone is studying from same books and study material,
                              then, it is the way of writing and presenting the answers that can help you in gaining marks. <br>For this, she wrote answers of 3-4 questions daily. Apart from the normal format of introduction, body and conclusion, she tried to include flowcharts, indices, data and diagrams to substantiate them.</p>
                            <p class="paragraph">She considers the practice of giving lot of mock test as the thing that proved to be most beneficial to her.
                                 As through mock tests, she was able to know that how much she knows, 
                                 what topics her mind could not retain and which subjects require more efforts.</p>
                                 <p class="paragraph">Therefore, with planning and consistency comes the taste of success and this women topper proved it right.
                                </p>
                    
                      <h1 class="display-5 mt-5"> Junaid Ahmed(AIR 3,CSE(2018)) </h1>
                      <p class="paragraph"> <i>“I seriously thought about it during my graduation days, 
                          after finishing my graduation ,I concentrated on UPSC exam,
                           the initial year of failure did not defer me. The aim was clear and I kept TRYING”</i>
                           -words by another  IAS topper <b>Junaid Ahmed(AIR 3,CSE(2018))</b>,who reached this milestone of success in his fifth attempt.
                           <p class="paragraph">He had been preparing for UPSC since 2014, and throughout his whole journey, he regards his failure as the best part. His preparation strategy focuses on three qualities-hard work, patience and perseverance He believes that the reason behind IAS preparation should work as daily motivation.</p>
                   
                           <div class="container mb-5"  id="filler-3">
                            <div class="row height-60">
                                <div class="col"> 
    
    
                                </div>
                            </div>
                        </div>
                         
                    </p>
                     <p class="paragraph">He thinks that before preparing for this exam, study the exam itself like its syllabus, what it demands and the best way to do that is previous year question papers.IAS exam demands only a common man understanding on the topics in the syllabus and doesn’t expect you to be an expert on all the topics.</p>
                    <p class="paragraph">Choosing Geography as the optional subject, he thinks that it is solely your interest that should be the reason of selecting your optional subject</p>
                    <p class="paragraph">He believes that a minimum two year strategy is required to clear this exam. The initial months should consist of reading NCERTs and reference books thoroughly. The second phase comprises of reading current affairs as much as you can.<br>While in the next phase, you should start giving a second reading to your text books and should start focusing on answer and essay writing.</p>
                    <p class="paragraph">One of the key point that he stresses upon is note making. He did not prepare any notes in his first attempt and later on learned from his mistake. Notes should be such that they contain all the data and facts and they should keep updating the notes from newspaper as and when required.  </p>
                </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col">  
                    <p class="paragraph">

                       
                        
                        
                        
    
                                 
                        
                         
                          
                        <h2 class="  display-5 my-4">    </h2>
                         
                        
                        
                        
                        </p>
                        <h1 class="display-5">Quote:</h1> 
                        <p class="paragraph"> So, the success story of this IAS topper teaches us that:
                        </p>
                        <p class="paragraph">”You try, you fail,<br>
                             You try, you fail,<br>
                            The real failure is when you stop trying!”<br>  
                            -quote by: team@mystudyguru.in
                            </p>


                     <br>
                          
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>
<?php
include 'bl/commententry.php';
?>



   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 

    
<?php
include 'bl/section.html';

?>
            
            
<?php
include 'bl/commentshow.php';

?>                     
             
        
            <!-- Optional JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
          </body>
        </html>
        
        
<?php
include 'Head_Foot/footer.html';

?>