<?php
 session_start();
 $servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";
  
 try {
  $connect = new PDO("mysql:host=$servername;dbname=$dbname;port=3306", $username, $password);
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if(isset($_POST["login"]))
	
    {
      if(empty($_POST["uemail"])  || empty($_POST["upass"]))
     {
      $message = '<label>All field is required</lable>';
     }
     else
	 {
       $query = "SELECT * FROM user_registration WHERE uemail = :uemail AND upass = :upass";
       $statement = $connect->prepare($query);
       $statement->execute(
              array(

                     'uemail'   =>   $_POST["uemail"],

                     'upass'   =>    $_POST["upass"]

                     )

          );

          $count = $statement->rowCount();

          if($count > 0)

          {

              $_SESSION["uemail"] = $_POST["uemail"];
			  
              header("location:service.php");
              
			 
  
    

          }

          else
             {

            $message = '<label>Email id OR Password is wrong</label>';
			 }
	 }
	}
  }
  catch(PDOException $error)
    {
		$message =$error->getMessage();
 }
?>
 <!DOCTYPE html>
<html>
<head>
<style>
.btn1{
background-color: #8b62c7;
}
.ctn{
    background:url("images/tree_Logo.gif");
           
        width: auto;
        height: auto;
        margin: 7em auto;
        border-radius: 1.5em;
        box-shadow: 5px 11px 35px 2px rgba(84, 104, 145, 1.84);
}
.ctn1{
    border-radius: 10px;
    padding-top: 10px;
    background-color: rgb(216, 216, 212);
    /* background-image: linear-gradient(120deg, #c4eba4, #1fd47a); */
    height: fit-content;
    margin-bottom: 15px;
}
body{
background:linear-gradient(to bottom, #8b62c7 0%,#fff 50%, #8b62c7 100%);
}
  .un {
    width:90%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 22px;
    color:red;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 4px outset #809fff;
    margin-bottom: 50px;
    margin-left: 0px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
</style>
<title>log_in|sign_up|mystudyguru.in</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>

<!--?php
if(isset($message))
{
	 echo '<label class="text-danger">'.$message.'</label>';
}
 ?--> 
 <div class="container-fluid bdr">
<div class="container  col-12 col-md-8 ctn"> 
<center><a href=""><img src="images/avtar.png" class="img-fluid"></a></center>

<?php
//include 'login_g.php';
include 'glogin.php';

?><br/>
<center>
<form method="post">
    
<input type="email" class="un" name="uemail" class="form-control" placeholder="Enter E-mail" />
<br />

<input type="password" class="un"  name="upass" class="form-control" placeholder="Enter Password" /><br/>

<input type="submit" name="login" class="btn btn-primary btn1" value="Login" />
 </form><br><br>
 <div ><center><p><font size="5px">Create an Account? <a href="#" data-toggle="modal" data-target="#exampleModal">SignUp</a></font></p></center></div>
 </center>
</div>

 </div>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
<div class="container-fluid">
<div class="container ctn1 rounded">
 <h1 align="center" style="font-family:Georgia;">Join Us</h1>
<form action="insertdata.php" method="post">
 <div class="form-group">
    <label for="exampleInputPassword1">Username</label>
    <input type="text" name="uname" class="form-control" id="exampleInputPassword1" placeholder="Username">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" name="uemail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="upass" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" name="insert" class="btn btn-primary">SignUp</button>
 <div class="spinner-grow" role="status">
  <span class="sr-only">Loading...</span>
</div>
  </form>
</div>

		</div></div></div></div>
 
 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
 </html>

