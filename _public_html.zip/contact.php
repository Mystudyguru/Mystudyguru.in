
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="index,folow">
    <meta name="description" content="for any competitive exam related problem contact mystudyguru">
    <script type="text/javascript" src=" ./js/all.js">  </script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Contact Us -mystudyguru</title>
    


  <style type="text/css">





    body{
  background-color: white;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
 
.link-color{
  color: #ef476f;
}
 
 

.cbox{
background-color:#ff3300;
border-radius:15px;
margin:20px;
padding:20py;
}
.ctn{
height:350px;
background-color:#fff;
}
#main-content{
  background-color: #F8EBFF;
}


.headings{
  background-color: #8b62c7;
}
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@700&display=swap" rel="stylesheet">
  </head>
  <body>
    <!--HEADER SECTION -->
  <section class="color-section p-2 d-none d-md-block">
    <div class="container-fluid">
      <div class="row">
        <div class="col text-white">
          <h1 class="display-4 text-center font" style="font-family: Georgia, serif;"><u>My Study Guru</u></h1>
        </div>
      </div>
    </div>
  </section>
  <!--END HEADER SECTION -->


 


   
  <div class="container-fluid m-3 mt-5 height-80" id="filler">
    <div class="row text-center">
      <div class="col">
        <h1 class="display-4" style="font-family: Georgia, serif;">CONTACT-US </h1>
        <p class="lead"> we 'ld love to hear from you </p>
        <div style="border:2px dotted grey" class="m-2"></div>
        <div class="row bg-dark m-5">
          <div class="col-md-1"></div>
          <div class="col-md-6 mr-1 bg-dark">
            

            
            
            <form action="connect/contact.php" method="POST">
              <div class="form-group mt-3">
                
                <input type="text" name="name" class="form-control" id="FormControlInput1" placeholder="Name: Mystudyguru">
              </div>
              <div class="form-group mt-4">
                 
                <input type="email" name="email" class="form-control" id="FormControlInput2" placeholder="email: abc@mystudyguru.in">
              </div>
               
              <div class="form-group mt-4">
                
                <textarea class="form-control" name="message" id="exampleFormControlTextarea3" rows="5"
                placeholder="Message: We would love to hear from you."></textarea>
              </div>
              <div class="form-group mt-4">
              <button name="insert" class="btn btn-secondary btn-lg btn-block my-5"  onclick="alertMessage();">Lock my suggestion</button>
              </div>
              
            </form>
          </div>
          <div class="col-md-4 mt-1 bg-dark text-light">
            <p class="lead text-left"> We are here 24/7 for providing you the best course material.<br>
              In the message box you can send your request for inclusion of particular topics. The team of mystugyguru focusses on providing best study material for all round complete prepration of government examinations. With your support and love we are growing.<br><big>Thanks for choosing us!</big></p>
              
              <h1 class="display-6 text-left">Team Mystudyguru!</h1>
			  <p><span class="glyphicon glyphicon-home"></span>E-mail us: <a href="#">contact@mystudyguru.in</a><br/><a href="#">info@mystudyguru.in</a></p>
			    
              <a href="#"><i class="fab fa-instagram fa-3x m-3 mx-3 text-danger"></i></a>
              <a href="#"><i class="fab fa-facebook fa-3x m-3 mx-3 "></i></a>
              <a href="#"><i class="fas fa-home fa-3x m-3 mx-3 text-light"></i></a>

          </div>
        </div>
         
      </div>
      
    </div>
  </div>

 <h1 class="text-center">   <a href="https://mystudyguru.in"> MyStudyGuru.in <br><button class="btn btn-primary">Get Home</button></a></h1>


 

    <script type="text/javascript" src="js/jquery-3.5.1.js "></script>
    <!--Bootstrap Refrence -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
 
 <script>
    
        function alertMessage(){
            
            alert("THANK YOU! YOU FEEDBACK HAS BEEN RECORDED!");
        }
    </script>
  </body>
</html>
