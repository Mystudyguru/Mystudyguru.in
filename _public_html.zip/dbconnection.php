<?php
session_start();
session_regenerate_id(true);
// change the information according to your database
$dbconnection = mysqli_connect("localhost","u635919262_mystudyguru99","Mystudyguru@123","u635919262_mystudyguru","3306");
//echo "Connected";
// CHECK DATABASE CONNECTION
if(mysqli_connect_errno()){
    echo "Connection Failed".mysqli_connect_error();
    exit;
}