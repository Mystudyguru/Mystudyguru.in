<?php
include 'Head_Foot/header.html';

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="e-learning,e learning for kids,online study,free e-learning india">
<meta name="description" content="e-learning or online study for students and kids for free on mystudyguru">
<meta name="robots" content="index,follow">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <title>e-learning|online study|mystudyguru</title>
    <script>
         var data = document.getElementById('text') ;
        function submit(){
           
            console.log(data);
        }

    </script>
    <style>
          body{
  background-color: whitesmoke;


  

}

.color-section{
  background-color:#8b62c7;
}
.font{
  font-family: 'Galada', cursive;
}
#nav-color{
  background-color:#F8EBFF;
}
.link-color{
  color: #ef476f;
}
#topic{
    font-weight: 900%;
    font-size: ;
}
#filler{
    background:#6930c3;
}
.height{
    min-height: 40vh;
}
.display{
    font-size:25px;
}
.img-responsive{
    height:70px;
}
.paragraph{
    font-family: serif;
    font-size:20px;
}
*{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      font-family:'Georgia',serif;
      }

       .Abh{
          border:5px solid rgba(200,50,40);
       border-radius : 20px;
       }
     
      
    
       
       .height-40{
           min-height: 50vh;
       }
        
.btn1{
background-color:#8b62c7;
}

 
    </style>
  </head>
  <body>
     
       

      <!-- TOPIC HEADING -->
       
        <div class="contianer  height-40" id="filler">
            <div class="row">
                 
                <div class="col-md-1 d-none d-md-block">
                </div>
                <div class="col-md-8"> <h1 class="text-light mt-4 ml-4"> </h1>
                    <h1 class="text-light mt-4 ml-4 ">
                    Introduction to the concept of Digital Education</h1>
                   <p> / Why to switch to Home Schooling?
                </p></div>
                <div class="col-md-3 d-none d-md-block">
                    
                </div>
                <div class="col-md-3 ">
                   
                </div>
                <div class="col-md-6 text-light m-4"><h4>by Achal Gupta -  21/Mar/2021</h4></div>
            </div>
        </div>

        <!-- BLOG SECTION -1-->
        <div class="container">
            <div class="row">
                <div class="col"> 


                   


                   <h1 class="display-5 text-center m-3"> WHAT IS E-LEARNING?</h1>
                   <p class="paragraph"> <b>E learning</b> generally referred as e- education or electronic learning is an act of sharing
                     info through electronic media based totally setup throughout that lecturers and student
                      fanciful at distant secluded from each other but the intentions are to create atmosphere 
                      an surroundings of education. In easier words e-learning is that replacement of primary 
                      available technique of education. Typically, e-learning takes place with the help of web,
                       where the scholar can access to material needed and anytime. the foremost used technique 
                       of e-learning area unit through webonline courses and videos.</p>
                    
                    
                    
            
                    
                       <p class="paragraph"> As we all know the earth is laid low with world pandemic and
                            countries are from slump, economic condition of business sectors is poor and but
                             at an equivalent time e-learning is that the platform that's reshaping and growing 
                                    apace.<br>
                            From the very initial day of announcement of Lock down the nationwide usage of internet
                            has exaggerated by forty seven
                            % during the amount, it's clear that people have become heaps of reliable over internet,
                            instead of fancying televisions enjoy likes to look at Netflix and so-on.<br>
                            Since, it fully wasn't potential to continue with the conventional technique of
                            education throughout the worldwide pandemic, a new-form of teaching came into
                            existence or tons of clearly people interacts with the new style of education 
                            that's "E-learning".</p>
                    
                    
                            <div class="container"  id="filler-1">
                                <div class="row height-60">
                                    <div class="col"> 
        
                                        <img src="images/blog/E-LEARNING.jpg" class="img-fluid" ALT="E-LEARNING.jpg">
                                    </div>
                                </div>
                            </div>
                    
                    <h2 class="text-left mb-2 mt-3"> Why E-learning?</h2>
                    <p class="paragraph"> Since world pandemic is that the foundation of digital education 
                    but this might not only be the reason to remain up e-learning </p>
                    
                    <p class="paragraph"> Maximize info Retention: is one amongst the foremost profitable blessings of e-Learning. 
                    In step with Brandon Hall (2001 and Rosenberg 2001),
                     e-Learning can increase info retention rate by 25-60%, the following are the benefits listed below.
                     </p><ul class="paragraph">

                    <li><b>Better Understanding</b>: e-learning may be a platform for the easy and better understanding 
                    of the topics.</li>
                    <li><b>Simplified information</b>: e-learning involves animations and videos that serves in providing 
                    information in an simplifies manner and easy means that of understanding.</li>
                    <li><b>Availability of material</b>: plenty of study material is accessible, merely google a stuff and 
                    you will notice material quite enough.</li>
                    <li><b>Increase Productivity</b>: Self-paced on-line learning finishes up during a ton of upper productivity
                     since employees can train reception, then specialize in their core tasks whereas at work.</li>
                    <li><b>Cost Reduction</b>: is typically the foremost reason why firms switch from ancient classroom-based
                     coaching job to e-Learning. In-house coaching job tends to be terribly dear, primarily due to 
                     the requirement for an knowledgeable trainer who will deliver it and who will facilitate employees improve their info and skills.
                        </li></ul>
                        <div class="container"  id="fill">
                            <div class="row height-60">
                                <div class="col"> 
                                    <img src="images/blog/E-LEARNING-ADVANTAGES.jpg" alt="E-LEARNING-ADVANTAGES" class="img-fluid">
    
                                </div>
                            </div>
                        </div>
                
                      <h1 class="display-5 mt-5">Future look of E-Learning</h1>
                      <p class="paragraph">Though world pandemic is that the predominant factor in sustaining e-learning, plenty of 
                    institute have recognized the potential. the end of the day of on-line education is growing
                     exponentially, plenty of e-learning platform have taken birth providing higher quality learning
                      and education.
                    However, we should always not get prior to ourselves. While the world of on-line education is
                      undoubtedly  an exciting world to be 
                     in, many student are uncomfortable with internet learning and still prefers ancient 
                     model of learning.</p>

                </div>  
            </div>
        </div>











        <div class="container mt-5">
            <div class="row">
                <div class="col"> <h2 class="  display-5 mb-4">Problems faced in E-learning</h2>
                    <p class="paragraph">

                        <div class="container mb-5"  id="fil r ">
                            <div class="row height-60">
                                <div class="col"> 
    
                                    <img src="images/blog/FUTURE-ONLINE-CLASSES.jpg" alt="FUTURE-E-LEARNING" class="img-fluid">
                                </div>
                            </div>
                        </div>
                         
                        
                        
                        
                        
                        Although in Republic of India web is offered to everybody and cost- economical too however because of mounted mind-set, plenty of lecturers did not deliver verity education, the common issues are listed below.
                        <ul class="paragraph">
                        <li><b>  Lack of Awareness</b> - by this i do not mean that lecturers lack information in subject material however they do not apprehend what are the technologies accessible within the market thus to deliver their subject material in a good manner.</li>
                        <li><b>  Poor Video Quality</b> - though lecturers aren't skilled camera persons, the recording done is in terribly poor quality as they use poor resolution settings in their mobile.A lot of skillful technologies are accessible however because of lesser data and in-sufficient sum a lecturer could not afford them.</li>
                            <li><b>  mounted subject material</b> -When you'll not simply exchange front of your category and teach, you've got to admit resources to try and do the work for you though the topic matter accessible to teacher is sweet however is in-effective in stealing the eye of learner, therefore creating the lectures boring and uninteresting.</li>
                                <li><b> uninteresting setting atmosphere</b> - Students aren’t the sole ones whom may feel diminished answerableness during a distance education setting. It is a struggle for lecturers too. Since lecturers are not habitual for are area settings, they felt awkward in recording the lectures and sharing them or taking online-live categories.</li>
                        
                        </ul>
                                <h2 class="  display-5 my-4">Teaching Online:</h2>
                        In this section I'm aiming to remark a way to teach using online techniques, 
                        there would be some tips and tricks that may assist you to spice up your on-line course
                         and teaching.
                        
                         <h2 class="  display-5 my-4"> BEST PRACTICES</h2>
                         <ul class="paragraph">
                        <li><b>Organize</b>- the simplest task a lecturer will do is to arrange the subject logically and consecutive, it'll create it straightforward for college students to grasp lecture simply and might access lectures simply for revision purpose.</li>
                        
                        <li><b> Making content Engaging</b>- By this I mean, rather than recording a straight lecture for continious for an hour or 2 try and insert animations and videos in lecture to form it additional fascinating and interesting, if you google the things you'll notice heaps of videos associated with your topics.</li>
                        
                         <li><b>Be curt</b> - attempt solely to incorporate the topics that are vital for a student to be known , pay a touch attention over minor details and conclude a subject among five - ten minute.</li>
                        
                         <li><b>Stay targeted </b>- Once you begin explaining a subject try and stay targeted, discuss one major topic per lecture, and target providing enough detail, thus on forestall content overloading.</li>
                        
                         <li><b>Present Visually </b>- instead of recording a lecture, a lecturer should target finding the right visuals of text and lecture, if you may substitute for the video section, by some sort of image/animation/meme this might be the simplest practice.</li>
                        </ul>
                        <h2 class="  display-5 my-4"> TIPS </h2>
                        <div class="container mb-5"  id="fill 4">
                            <div class="row h ">
                                <div class="col"> 
                                    <img src="images/blog/TIPS-AND-TRICKS-FOR-ONLINE-CLASSES.jpg" alt="TIPS-AND-TRICKS-FOR-ONLINE-CLASSES" class="img-fluid height-60">
                                    
    
                                </div>
                            </div>
                        </div>
                         
                        
                        <b class="paragraph">Delivering on-line coaching is a small amount overwhelming if you're unsure of wherever to start. you'll have a good on-line platform for your course, however would like facilitate making some interactive, relevant course material. So, we've place here some tips which may assist you .</b>
                        <ul class="paragraph m-2"> 
                        <li>  Know about your E-learning Platform.</li>
                        <li>  Teach students to use the E-learning platform.</li>
                        <li>  notice technology that helps you – Apps & Services</li>
                        <li> notice technology that helps – package</li>
                        <li>  Get the proper instrumentality</li>
                        <li> Backups & Contingency Plans</li>
                        <li> produce selection (videos, images, PDFs, texts etc)</li>
                        
                        </p>
                        <h1 class="display-5">Quote:</h1>  
                    
                        "Online learning is apace turning into one of the foremost economical ways in which 
                        to educate the world’s speedily increasing workforce."<br>
                        Jack Messman, former chief executive officer at Novell   
                </div>
            </div>
        </div>
<!-- COMMENT SECTION -->
<div class="container mt-5">
    <div class="row">
        <div class="col"><h1>Leave a Comment!</h1></div>
    </div>
</div>
<?php
include 'bl/commententry.php';

?>



   <div class="container">
       <div class="row">
           <div class="col">
               <div id="comment-section"></div>
           </div>
       </div>
   </div>
          

         

            </div>
        </div>
 
          
<?php
include 'bl/section.html';

?>
        
<?php
include 'bl/commentshow.php';

?>
                 
         
    
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
      </body>
    </html>
    
<?php
include 'Head_Foot/footer.html';

?>