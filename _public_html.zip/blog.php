 <?php
include 'Head_Foot/header.html'; 
?>


<!doctype html>
 <html>
     <head>
    <title>BLOG -mystudyguru</title>
     <meta charset="utf-8">
     <meta name="keywords" content="blogs,blog for free,blogs in hindi,blog for problem solving,blog on education">
     <meta name="robots" content="index,follow">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
     <style>

         *{
      margin:0;
      padding:0;
      }
      .abhi{
      background-color:white;
      
      }

       .Abh{
          border:5px solid red;
       border-radius : 20px;
       }
       .collapse{
           border:5px solid #8b62c7;
       border-radius : 20px;
       }
.btn1{
background-color:#8b62c7;
}

         </style>

    </head>

    <body class="abhi">
     
                <section >
            <div class="mt-2 pt-2">
            <h1 class="text-center text-capitalize text-white" style="background-color:#8b62c7;"> blogs</h1>
              <hr class="w-25 mx-auto bg-danger"></hr>
               </div>
			   <center><p style="font-size:100px">&#128578;</p></center>
            <div class="container-fluid mt-3 mb-3">
                <div class="row text-center ml-3 mr-3" >

              <div class="col-lg-4 col-md-4 col-12 mb-4">

                   <div class="Abh">
  <img class="card-img-top " src="images/blog/Studying abroad-Still a dream.gif" alt="Studying abroad-Still a dream">
  <div class="card-body  bg-white">
     <hr><h4 class="card-title pb-4">Studying abroad-Still a dream ?</h4><p>By:- Cheshta Sagar</p>

<a href="study-abroad.php"><button class="btn btn1 mb-1 text-white" >Read the full article</button></a>
  </div>
</div>
</div>

 <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh">

  <img class="card-img-top " src="images/blog/Preparation for UPSC Interview .gif"   alt="How to Prepare for UPSC interview">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">"Preparation for UPSC Interview  "</h4><p>By:- Abhishek Bage</p>
    <a href="UPSC-interview.php"><button class="btn btn1 text-white" >Read the full article</button></a>
    </div>
    </div>
    </div>
    
    <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh">

  <img class="card-img-top" src="images/blog/E-Learning.gif" alt="E-Learning">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">E-Learning "Switch to digital learning"</h4><p>By:- Achal Gupta</p>
    <a href="E-learning.php"><button class="btn btn1 text-white"  >Read the full article</button></a>
    </div>
    </div>
    </div>
    
    
                   <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh">

  <img class="card-img-top" src="images/blog/Choose  Career.gif" alt="How and Why Choose  Career">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">How & Why Choose  Career ?</h4><p>By:- Mohit Gupta</p>
    <a href="choose-a-career.php"><button class="btn btn1 text-white" >Read the full article</button></a>
    </div>
    </div>
    </div>
    
<div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh">

  <img class="card-img-top " src="images/blog/How to Prepare for UPSC Exam.gif"   alt="How to Prepare for UPSC Exam">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">"How to Prepare for UPSC Exam"</h4><p>By:- Pragya Sharma</p>
    <a href="UPSC-interview-preparation.php"><button class="btn btn1 text-white" data-toggle="collapse"  >Read the full article</button></a>
    </div>
    </div>
    </div>
                   <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh">

  <img class="card-img-top " src="images/blog/time management.gif"   alt="time management">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">"For every minute spent in organizing , an hour is earned"</h4><p>By:- Cheshta Sagar</p>
    <a href="time-management.php"><button class="btn btn1 text-white"  >Read the full article</button></a>
    </div>
    </div>
    </div>
    

                   <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh">

  <img class="card-img-top" src="images/blog/Do competitive exams scare you.gif" alt="Do competitive exams scare you">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">Do competitive exams scare you ?</h4><p>By:- Cheshta Sagar</p>
    <a href="exam-phobia.php"><button class="btn btn1 text-white"  >Read the full article</button></a>
    </div>
    </div>
    </div>

    
            <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh mt-4">

  <img class="card-img-top " src="images/blog/Know their Success Mantra.gif"   alt="Know their Success Mantra">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">"Know their Success Mantra!!"</h4><p>By:- Cheshta Sagar</p>
    <a href="success-mantra.php"><button class="btn btn1 text-white" >Read the full article</button></a>
       </div>
          </div>
             </div>
    
 <div class="col-lg-4 col-md-4 col-12 mb-4">
                       <div class="Abh mt-4">

  <img class="card-img-top " src="images/blog/Personality-development.gif"   alt="Personality-development">
  <div class="card-body bg-white">
    <hr><h4 class="card-title">Personality Development</h4><p>By:- Achal Gupta</p>
    <a href="PD-skill.php"><button class="btn btn1 text-white" >Read the full article</button></a>
       </div>
          </div>
             </div>
    


    
                    </div>
                </div>

        </section>

          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>


    </body>

 </html>

<?php
include 'Head_Foot/footer.html'; 
?>