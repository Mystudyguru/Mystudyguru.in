<?php
session_start();

?>

<?php
include 'Head_Foot/header.html';

?>
<!DOCTYPE html>
<html lang="en">
<head>
      
	 <style>
	 .ban{
	background:linear-gradient(to bottom,#8b62c7 0%,#33ddff 100%);
	box-shadow: 5px 11px 35px 2px rgba(84, 104, 145, 1.84);
	 }
	 </style>
  <meta charset='utf-8'>
 <meta name="description" content="Get free best study material and audiobook for UPSC,SSC,RRB,ctet, super tet uptet and all other competitive exams|also buy and sell old books free.">
<meta name="keywords" content="free upsc coaching ,upsc exam pattern ,upsc syllabus ,railway ntpc exam ,groupD exam ,RRB exam date ">
<meta name="author" content="Harshvardhan Siddhartha">
<meta name="robots" content="index, follow"/>
<meta name="googlebot" content="index, follow"/>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <title>online study|latest current affairs 2020|mystudyguru.in</title>
 <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
  <link rel='stylesheet' type='text/css' media='screen' href='css\glyphicons.css'>
  <link rel='stylesheet' type='text/css' media='screen' href='css\bootstrap.min.css'>
  <link rel='stylesheet' type='text/css' media='screen' href='css\styles.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@700&display=swap" rel="stylesheet">
</head>

<body onload="myFunction()">

  <!-- Preloader -->
  <div class="loader-pencil-content" id="loader">
    <div class="btn">
      <svg id="loader-pencil" xmlns="http://www.w3.org/2000/svg" width="667" height="182" viewBox="0 0 677.34762 182.15429">
        <g>
          <path id="body-pencil" d="M128.273 0l-3.9 2.77L0 91.078l128.273 91.076 549.075-.006V.008L128.273 0zm20.852 30l498.223.006V152.15l-498.223.007V30zm-25 9.74v102.678l-49.033-34.813-.578-32.64 49.61-35.225z">
          </path>
          <path id="line" d="M134.482 157.147v25l518.57.008.002-25-518.572-.008z">
          </path>
        </g>
      </svg>
    </div>
  </div>
  <!-- Preloader end -->
  

  <!-- Carousel -->
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="images/home post.gif" alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/home post2.gif" alt="Second slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="images/home post3.gif" alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  
  <!-- Carousel end -->

  <!-- Welcome -->
  <div class="container-fluid content" id="welcome">
  
    <!-- <h2 style="font-family: Arial, Helvetica, sans-serif;"> -->
    <h2 style="font-family:Georgia;">  
      <marquee behavior="alternate" direction="left" scrollamount="5" >
        Welcome to My Study Guru!
      </marquee>
    </h2>
	<center><canvas id="canvas" class="rounded-circle clock" width="170" height="170" style="background-color:#8b62c7"></canvas><p style=" animation: blinker 1s infinite linear; " class="text1">Time is valuabale</p></center><br/>
		<?php
	if(isset($_SESSION['uemail']) || ($_SESSION['login_id'])) {
	}
	else{
	echo '<button type="button" class="btn btn-outline-info  active glyphicon glyphicon-hand-right" data-toggle="modal" data-target="#exampleModal"> Get Registered</button>
    ';
}
?>
	
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
<div class="container-fluid">
<div class="container ctn rounded">
 <h1 align="center" style="font-family:Georgia;">Join Us</h1>
 <?php
include 'glogin.php';

?>
<form action="insertdata.php" method="post">
 <div class="form-group">
    <label for="exampleInputPassword1">Username</label>
    <input type="text" name="uname" class="form-control" id="exampleInputPassword1" placeholder="Username">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" name="uemail" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="upass" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" name="insert" class="btn btn-primary">SignUp</button>
 <div class="spinner-grow" role="status">
  <span class="sr-only">Loading...</span>
</div>
  </form>
</div>

		</div></div></div></div>
	<br/><h1 class="text-justify lead dplay-5 " style="font-family: serif, 'Nimbus Roman No9 L', 'Century Schoolbook L', serif; color:#8b62c7; font-style:cursive;">Here,you can get the best Free Study Material,Audiobook,Syllabus,Past Years ExamPapers,Current Affairs,G.K tricks and Quizes for Competetion Exam preparations like:-UPSC,SSC,RRB,TET/C-TET/S-TET,BANK,POLICE,ARMY and other state level exams.<br>Also, now you can SELL and BUY Books. Moreover,you can DONATE Books for the needy.</h1>
  </div><br>
  <!-- Welcome end -->

<!--NEWS-->
 <div class="container-fluid content" id="welcome">
    <!-- <h2 style="font-family: Arial, Helvetica, sans-serif;"> -->
    <h2 style="font-family:Georgia;">  
      <marquee behavior="alternate" direction="left" scrollamount="5" >
        Whats New!
      </marquee>
      <h1 style=" animation: blinker 1s infinite linear; " align="center"><a href="webinar.php">Join Webinar</a></h1>
    </h2>
	 <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
     <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item">
      <img src="images/stone.png" class="d-block w-52 img-fluid" alt="stone">
     
    </div>
    <div class="carousel-item">
      <img src="images/kidzone.png" class="d-block w-52 img-fluid" alt="kidzone">
      <div class="carousel-caption d-none d-md-block">
        <h5>Kidzone </h5>
        <h4>Play and Learn With Fun.</h4>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/bookaudio.png" class="d-block w-52 img-fluid" alt="bookaudio">
      <div class="carousel-caption d-none d-md-block">
        <h5>Listen & Learn</h5>
        <p>Best Way to Learn in less time and never forget.</p>
      </div>
    </div>
      <div class="carousel-item active">
      <img src="images/RRB-NTPC & Group-D Exams.jpg" class="d-block w-52 img-fluid" alt="bookaudio">
      <div class="carousel-caption d-none d-md-block">
        <a href="https://mystudyguru.in/rrb.php"><h5>Get into express</h5></a>
        <p>Upcoming Railway exams .</p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>  
	   <p class="text-justify text-wrap " style="font-family:Garamond;">Latest and updated News here!.</p>
  </div><br><br>
  <!-- Services -->
  <div class="container-fluid cf">
    <div class="row">
    <div class="col-md-5 col-lg-5 col-sm-5 col-10 container-fluid ctn"><h3 class="text-center" style="font-family:Georgia;">STUDY MATERIAL</h3>
    <div><a style="text-decoration:none" href="upsc.php"><button type="button" class="btn btn-outline-warning btn-block">UPSC</button></a></div><br>
    <div><a style="text-decoration:none" href="ssc.php"><button type="button" class="btn btn-outline-warning btn-block">SSC</button></a></div><br>
    <?php
	if(isset($_SESSION['uemail']) || ($_SESSION['login_id'])) {
	    echo '<div><a style="text-decoration:none" href="rrb.php"><button type="button" class="btn btn-outline-warning btn-block">RRB</button></a></div><br>';
	}
	else{
	echo '<div><a style="text-decoration:none" href="#"><button type="button" class="btn btn-outline-warning btn-block" onclick="notify()">RRB</button></a></div><br>';

}
?>
    
    <div><a style="text-decoration:none" href="best_TET.php"><button type="button" class="btn btn-outline-warning btn-block">UP-CTET/S-TET</button></a></div><br>
     <div><a style="text-decoration:none" href="more-exams.php"><button type="button" class="btn btn-outline-warning btn-block">BANKING</button></a></div><br>
    <div><a style="text-decoration:none" href="current-affairs.php"><button type="button" class="btn btn-outline-warning btn-block">CURRENT AFFAIRS</button></a></div><br>
     <div><a style="text-decoration:none" href="Gktricks.php"><button type="button" class="btn btn-outline-warning btn-block">G.K TRICKS</button></a></div><br>
    	<?php
	if(isset($_SESSION['uemail']) || ($_SESSION['login_id'])) {
	    echo '<div><a style="text-decoration:none" href="quiz.php"><button type="button" class="btn btn-outline-warning btn-block">QUIZ!</button></a></div><br>';
	}
	else{
	echo '<div><a style="text-decoration:none" href="#"><button type="button" class="btn btn-outline-warning btn-block" onclick="notify()">QUIZ!</button></a></div><br>
    ';

}
?>
    
    <div><a style="text-decoration:none" href="kidzone.php"><button type="button" class="btn btn-outline-warning btn-block">KIDS ZONE</button></a></div><br>
    </div>
    <br>
    <div class="container col-md-5 col-lg-5 col-sm-5 col-10 ban">
  
		    <div style="padding: 0 10px 5px 10px;"><h1 class="text-center text-white"style="font-family:Georgia;">BLOGS</h1><hr>
		   <center><img src="images/people_Logo.gif" class="img-fliud  rounded-bottom" height="200px" width="260px" alt="people_Logo"/></center>
		  <h2 class="text-white">Hope You like to Read Blog </h2>
		  <ul class="text-white">
		  <li>Improve Vocab and learn new words</li>
		  <li>Reading improve your English skills</li>
		  <li>100% Organic and understandable content</li>
		  </ul>
		 <div><a style="text-decoration:none" href="blog.php"><button type="button" class="btn btn-light">Read Free Blogs!</button></a></div>
		  </div>
      <br><br>
    </div>
    </div>
    </div>
  </div><br><br/>
  <!-- <section> -->
          <?php
	if(isset($_SESSION['uemail']) || ($_SESSION['login_id'])) {
	    echo '<div class="container col-11 col-md-10 ban">';
		echo '<h3 class="text-white">Quiz</h3><hr>';
		echo '<img src="images/Quiz.gif" class="img-fliud float-right rounded-bottom" height="200px" width="280px" alt="book_lady"/>';
		 echo '<h2 class="text-white">Explore the worlds of Knowledge</h2>';
		 echo '<ul class="text-white">';
		  echo '<li>Feel free to Explore.</li>';
		  echo '<li>Do Quiz</li>';
		  echo '<li>Paperless Practice for better Knowledge</li>';
		  echo '</ul>
		  <a href="quiz.php"><button class="btn btn-light">Use it for free</button></a><br>
		  <center class="text-white">Learn Free | Earn Free</center>
		  </div>';
	    
	}
	else{

}
?>
          <br>
          <div class="container col-11 col-md-10 ban">
		  <h3 class="text-white">WRITTING BOARD</h3><hr>
		   <img src="images/tree_Logo.gif" class="img-fliud float-right rounded-bottom" alt="tree_Logo" height="200px" width="280px"/>
		  <h2 class="text-white">Discover the world's research</h2>
		  <ul class="text-white">
		  <li>Feel free to write.</li>
		  <li>Make Notes</li>
		  <li>Paperless Practice for Easy and Maths</li>
		  </ul>
		  <a href="writtingpad.php"><button class="btn btn-light">Use it for free</button></a><br>
		  <center class="text-white">Save Paper | Save Trees</center>
		  </div>
		  <br><br/>
		  <div class="container col-11 col-md-10 ban">
		  <h3 class="text-white">BOOKSTALL</h3><hr>
		   <img src="images/book_lady.gif" class="img-fliud float-right rounded-bottom" alt="book_lady" height="200px" width="280px"/>
		  <h2 class="text-white">Discover the Earning</h2>
		  <ul class="text-white">
		  <li>Buy & Sell your old  books.</li>
		  <li>upload your books free</li>
		  <li>We take care of your earning in this pandemic situation</li>
		  </ul>
		  <a href="bookstall.php"><button class="btn btn-light">Use it for free</button></a><br>
		  <center class="text-white">Learn Free | Earn Free</center>
		  </div>
		  <br><br/>
		  
		  	<?php
	if(isset($_SESSION['uemail']) || ($_SESSION['login_id'])) {
	    echo '<div class="container col-11 col-md-10 ban">
		  <h3 class="text-white">AUDIOBOOK</h3><hr>
		   <img src="images/Audio_Logo.gif" class="img-fliud float-right rounded-bottom" alt="Audio_Logo" height="200px" width="280px"/>
		  <h2 class="text-white">Discover the New Learning</h2>
		  <ul class="text-white">
		  <li>Easy and fast learning.</li>
		  <li>Learning by listensing</li>
		  <li>Easy and Understable Concepts</li>
		  </ul>
		  <a href="audiobook.php"><button class="btn btn-light">Use it for free</button></a><br>
		  <center class="text-white">Save Time | Save Future </center>
		  </div>';
	}
	else{
	echo '<div class="container col-11 col-md-10 ban">
		  <h3 class="text-white">AUDIOBOOK</h3><hr>
		   <img src="images/Audio_Logo.gif" class="img-fliud float-right rounded-bottom" alt="Audio_Logo" height="200px" width="280px"/>
		  <h2 class="text-white">Discover the New Learning</h2>
		  <ul class="text-white">
		  <li>Easy and fast learning.</li>
		  <li>Learning by listensing</li>
		  <li>Easy and Understable Concepts</li>
		  </ul>
		  <a href="#"><button class="btn btn-light" onclick="notify()">Use it for free</button></a><br>
		  <center class="text-white">Save Time | Save Future </center>
		  </div>
    ';

}
?>
		  
		  		
		  
  
  
  <!-- <section> -->
  <!-- Services end -->

  
  <!--study routine-->
 <div class="container content ban1" id="welcome" style="background-color:#00cc92;">
    <!-- <h2 style="font-family: Arial, Helvetica, sans-serif;"> -->
    <h2 style="font-family:Georgia;">  
      <marquee behavior="alternate" direction="left" scrollamount="5" class="text-white">
        Want to Make Your Daily Study Routine
      </marquee>
    </h2>
	<a  style="text-decoration:none" href="images/Daily-study-timetable.jpg"><center><button type="button"  class="btn btn-light  glyphicon glyphicon-download-alt"> Download-Now</button></center></a>
    <p class="text-justify text-wrap text-white text-center" style="font-family:Garamond;">We help you to make your study routine as per your daily working day </p>
  </div>
<!--Interview-->
 <div class="container content ban1" id="welcome" style="background-color: #00cc92; ">
    <!-- <h2 style="font-family: Arial, Helvetica, sans-serif;"> -->
    <h2 style="font-family:Georgia;">  
      <marquee behavior="alternate" direction="left" scrollamount="5" class="text-white" >
        What you Need when you go for Interview!
      </marquee>
    </h2>
	<a  style="text-decoration:none" href="pdfs/Interview Tips.pdf"><center><button type="button"  class="btn btn-sm btn-light glyphicon glyphicon-download-alt"> Download-Asked-Questions?</button></a>
	<a href="pdfs/Documents Required in UPSC Interview.pdf"><button type="button"  class="btn btn-sm btn-light glyphicon glyphicon-download-alt"> Check for your Documents</button></a></center>
    <p class="text-justify text-wrap text-white text-center" style="font-family:Garamond;">What you Need when you go for Interview!.</p>
  </div><br/>
<div class="container col-12"><center><iframe width="auto" height="auto" src="https://www.youtube.com/embed/7eX9T4IXs6M" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center></div>
  <!-- Some info -->
  <div class="container-fluid border-warning ctn2 col-12 w-100 col-md-10 col-lg-10 text-light" style="background-color:#6F2DBD ">
    
    
    
    <h1 class="display-5 text-warning">ABOUT US</h1>
<p class="lead text-center">MyStudyGuru.in is an interated platform to provide you the best and filtered study material for all level government and non-government competitve examinations.
The best part about us, we provide the best study material and that's for absolutelty free which makes us unique.</p>
<hr>
<h1 class="display-5 text-warning">WHY US?</h1>

<p class="lead text-center">To be succesful at any stage of life the most important person is the taceher/Guru that shapes the student  <b></b>In the world of competition where the competition is growing exponentially, mystudyguru platform act as e-guru for all your preparations.</p>

 <p class="lead text-center">Aspirants can access <a href="https://mystudyguru.in" >mystudyguru.in </a> either on mobile or laptop making it education more easily available at their fingertip and can also get real time alert on various topic and can enhance their skills through various program being organized on daily basis. <br><br></p>

<p class="lead text-center">We at MYSTUDYGURU'S work all-around for providing students the best study material. We have study material for students across ages and grades:</p>

<ul>
<li>Maths, Physics, Chemistry and Biology for CBSE and ISC (KID-ZONE)</li>
<li>Competitive Exams- UPSC-CSE, SSC, RRB Study Material.</li>
</ul>
<hr>

<h5 class="text-center text-warning">PILLARS OF MYSTUDYGURU </h5>
<p class="lead text-center">

  The pillars lies in our name itself:

 
                     <p class="text-left lead pl-5" >
                    <label class="text-danger h4">M</label>agnificent study material<br>
                    <label class="text-danger h4">Y</label>outhful content<br>
                    <label class="text-danger h4">S</label>tudious <br>
                    <label class="text-danger h4">T</label>eamwork<br>
                    <label class="text-danger h4">U</label>nderstanding<br>
                    <label class="text-danger h4">D</label>edicated<br>
                    <label class="text-danger h4">Y</label>ear long <br>
                    <label class="text-danger h4">G</label>enuine<br>
                    <label class="text-danger h4">U</label>niqueness<br>
                    <label class="text-danger h4">R</label>ighteous<br>
                    <label class="text-danger h4">U</label>ser friendly<br>
                    <label class="text-danger h4">In</label>dia<br><br>
                     Aspirants can access <a href="https://mystudyguru.in" >mystudyguru.in </a> either on mobile or laptop making it education more easily available at their fingertip and can also get real time alert on various topic and can enhance their skills through various program being organized on daily basis. <br><br>
                        Regards:<br>
                            Team mystudyguru.in
                            <br>

</p>



                </p>

  </div>

  </br>
  
  <!-- Some info end -->
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5f7e057ce03c971f"></script>
 <div align="center" class="message float-right"><h3 class=" glyphicon glyphicon-bell"  style=" animation: blinker 1s infinite linear; color:#8b62c7; " data-toggle="collapse" data-target="#content" ></h3></div><div class="collapse  text-dark" id="content"><div class="container alertmsg"><p style="font-size:40px">&#128578;<br>Smile Whole Day Keeps Tension Away! Keep Smiling </p>Hello! here we will help you out</div></div><br/><br/>
  
 
  <!-- JS files -->

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script>
    var preloader=document.getElementById('loader');

    function myFunction(){
      preloader.style.display='none';
    }
  </script>
 
  <!-- JS files end -->
<script>
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var radius = canvas.height / 2;
ctx.translate(radius, radius);
radius = radius * 0.90
drawClock();

function drawClock() {
  ctx.arc(0, 0, radius, 0 , 2 * Math.PI);
  ctx.fillStyle = "white";
  ctx.fill();
}

function notify()
{
    alert("First You have to Login\nTo Enable Features");
}

function drawClock() {
  drawFace(ctx, radius);
}

function drawFace(ctx, radius) {
  var grad;

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, 2 * Math.PI);
  ctx.fillStyle = 'white';
  ctx.fill();

  grad = ctx.createRadialGradient(0, 0 ,radius * 0.95, 0, 0, radius * 1.05);
  grad.addColorStop(0, '#333');
  grad.addColorStop(0.5, 'white');
  grad.addColorStop(1, '#333');
  ctx.strokeStyle = grad;
  ctx.lineWidth = radius*0.1;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.1, 0, 2 * Math.PI);
  ctx.fillStyle = '#333';
  ctx.fill();
}

function drawClock() {
  drawFace(ctx, radius);
  drawNumbers(ctx, radius);
}

function drawNumbers(ctx, radius) {
  var ang;
  var num;
  ctx.font = radius * 0.15 + "px arial";
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";
  for(num = 1; num < 13; num++){
    ang = num * Math.PI / 6;
    ctx.rotate(ang);
    ctx.translate(0, -radius * 0.85);
    ctx.rotate(-ang);
    ctx.fillText(num.toString(), 0, 0);
    ctx.rotate(ang);
    ctx.translate(0, radius * 0.85);
    ctx.rotate(-ang);
  }
}
function drawClock() {
  drawFace(ctx, radius);
  drawNumbers(ctx, radius);
  drawTime(ctx, radius);
}

function drawTime(ctx, radius){
  var now = new Date();
  var hour = now.getHours();
  var minute = now.getMinutes();
  var second = now.getSeconds();
  //hour
  hour = hour%12;
  hour = (hour*Math.PI/6)+(minute*Math.PI/(6*60))+(second*Math.PI/(360*60));
  drawHand(ctx, hour, radius*0.5, radius*0.07);
  //minute
  minute = (minute*Math.PI/30)+(second*Math.PI/(30*60));
  drawHand(ctx, minute, radius*0.8, radius*0.07);
  // second
  second = (second*Math.PI/30);
  drawHand(ctx, second, radius*0.9, radius*0.02);
}

function drawHand(ctx, pos, length, width) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.moveTo(0,0);
  ctx.rotate(pos);
  ctx.lineTo(0, -length);
  ctx.stroke();
  ctx.rotate(-pos);
}

//drawClock();
setInterval(drawClock, 1000);
</script>
</body>

</html>
<?php
include 'Head_Foot/footer.html';

?>