<!--form action="connect/contact.php" method="POST">
              <div class="form-group mt-3">
                
                <input type="text" name="name" class="form-control" id="FormControlInput1" placeholder="Name: Mystudyguru">
              </div>
              <div class="form-group mt-4">
                 
                <input type="email" name="email" class="form-control" id="FormControlInput2" placeholder="email: abc@mystudyguru.in">
              </div>
               
              <div class="form-group mt-4">
                
                <textarea class="form-control" name="message" id="exampleFormControlTextarea3" rows="5"
                placeholder="Message: We would love to hear from you."></textarea>
              </div>
              <div class="form-group mt-4">
              <button name="insert" class="btn btn-secondary btn-lg btn-block my-5"  onclick="alertMessage();">Lock my suggestion</button>
              </div>
              
            </form-->
            
            
            
<form class="container" action="\connect/comment.php" method="POST">
    <div class="form-group">
      <label for="email ">Username</label>
      <input type="text" name="email" class="form-control" id="email text" placeholder="mystudyguru.in">
    </div>
    
     
    <div class="form-group">
      <label for="data">Comment/Complement</label>
      <textarea class="form-control" name="complement" id="data" rows="3" placeholder="The work by the blogger is really great and I appreciate his/her work."></textarea>
    </div>
     
    <button class="btn btn-primary btn1 m-3 px-5" >Submit it!</button>
  </form>
            