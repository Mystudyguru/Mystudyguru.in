<!--This Code is to show doctor details to the Patient so that patient can book Prescription Online-->
<?php

$servername = "localhost";
$username = "u635919262_mystudyguru99";
$password = "Mystudyguru@123";
$dbname = "u635919262_mystudyguru";


// this is used in Login_success.php page
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

   $sql = 'SELECT id,
                    email,
					complement
               FROM comment_detail
              ORDER BY id';

    $q = $pdo->query($sql);
    $q->setFetchMode(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Could not connect to the database $dbname :" . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>PHP MySQL Query Data Demo</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--style>
td {
  text-align: center;
  top:88%;
  height: 20px;
  vertical-align: bottom;
  padding: 55px;
}
</style-->
<style>
@media (max-width: 600px) {
        .main {
            border-radius: 1.5em;
			width:100%;
        }
		.body{
			width:100%;
		
		.table{
			width:100%;
		}
		.tr{
			width:100%;
		}
		.td{
			width:100%;
		}
		.p{
			width:100%;
		}
		.h5{
			width:100%;
			left:85%;
		}
		.img{
			width:100%;
		}
		}
		
		
}
.ctn1{
      background-color:#8b62c7;
       border:15px inset #00cc92;
}
.checked {
  color: orange;
}
</style>
    </head>
    <body>
        
        <div class="container-fluid">
            <label class="position-absolute float-center text-primary">All Comments</label>
            <br>
                           <span class="heading">User Rating</span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
           <br>
           <br>
              <h1>
                  
              </h1>
            <table class="table table-bordered table-condensed">
                <thead>
                   
                </thead>
                <tbody>
                    <?php while ($row = $q->fetch()): ?>
					
					<div class="card " >
					
					<span class="border rounded shadow p-2 mb-4 ctn  rounded">

                    <div class="card-body">
         
                    <h5 style="position:absolute;" class=" float-left  ">Name-<font style="background-color:white" class="text-primary"><?php echo htmlspecialchars($row['email']); ?></font></h5></hr>
					<br><br>
					<h5 style="position:absolute;" class="position-absolute float-left text-danger">Messages-<font style="background-color:white" class="text-primary"><?php echo htmlspecialchars($row['complement']); ?></font></h5>
					<br>
                    </div>
					</span>
                    </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
  
           </div>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>

</html>